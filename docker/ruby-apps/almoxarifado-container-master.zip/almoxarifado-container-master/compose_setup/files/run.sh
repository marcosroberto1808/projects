#!/bin/bash

#Criar o arquivo database.yml
/bin/bash -l -c "rm -f /app/config/database.yml"
cat << EOF > /app/config/database.yml
$RAILS_ENV:
  adapter: postgresql
  encoding: unicode
  database: $DB_NAME
  pool: 5
  timeout: 5000
  username: $DB_USER
  password: $DB_PASS
  host: $DB_HOST

colaboradores_$RAILS_ENV:
  adapter: postgresql
  encoding: unicode
  database: $COLABORADORES_DB_NAME
  pool: 5
  timeout: 5000
  username: $COLABORADORES_DB_USER
  password: $COLABORADORES_DB_PASS
  host: $COLABORADORES_DB_HOST
  schema_search_path: $COLABORADORES_DB_SCHEMA

cfue_$RAILS_ENV:
  adapter: postgresql
  encoding: unicode
  database: $COL_FUNCAO_UNIDADE_EXERCICIO_DB_NAME
  pool: 5
  timeout: 5000
  username: $COL_FUNCAO_UNIDADE_EXERCICIO_DB_USER
  password: $COL_FUNCAO_UNIDADE_EXERCICIO_DB_PASS
  host: $COL_FUNCAO_UNIDADE_EXERCICIO_DB_HOST
  schema_search_path: $COL_FUNCAO_UNIDADE_EXERCICIO_DB_SCHEMA
EOF

# Iniciar o passenger
/bin/bash -l -c "bundle exec passenger start -p 3000 -e $RAILS_ENV --pid-file /tmp/passenger.3000.pid"
