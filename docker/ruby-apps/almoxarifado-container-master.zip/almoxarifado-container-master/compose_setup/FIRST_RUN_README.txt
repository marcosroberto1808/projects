# Remove all containers and all images from local repositories (OPTIONAL)
docker rm @(docker ps -aq) ; docker rmi @(docker images -aq) --force  # WINDOWS POWERSHELL
docker rm $(docker ps -aq) ; docker rmi $(docker images -aq) --force  # LINUX TERMINAL

# Starting all services in daemon mode:
docker-compose up -d

# Copy database dumps to folder "database_dumps" in uper_level of the project.
# Restore database dumps after 1st docker-compose start with the commands below:
docker-compose exec almoxarifado-db pg_restore -U postgres -v -d almoxarifado /backups/almoxarifado_full.backup
docker-compose exec almoxarifado-db pg_restore -U postgres -v -d db_portal_digital /backups/db_portal_digital_ALMOXARIFADO_SCHEMAS.backup
docker-compose exec almoxarifado-db psql -U postgres -v -d db_portal_digital -a -f /backups/update_colaborador.sql

