class Fechamento < ActiveRecord::Base
	def checa_fechamento
		year = data_fechamento.year
		month = data_fechamento.month
		prev_month = (data_fechamento - 1.month).month
		#Checa se o periodo anterior está fechado;
		periodo_anterior = Fechamento.find_by_data_fechamento(Date.civil(year,prev_month,-1))
		if periodo_anterior != nil
			periodo_anterior = periodo_anterior.processado
		end
		#Checa se este é o primeiro periodo do sistema, ou seja, não existe periodo anteior;
		if (MovimentacaoMaterial.first.created_at.year == year and MovimentacaoMaterial.first.created_at.month == month)
			periodo_anterior = true
		end		
		entradas = Entrada.where(data_entrada: Date.civil(year,month,1)..Date.civil(year,month,-1), fechado: false)
		requisicoes = Requisicao.where(data_requisicao: Date.civil(year,month,1)..Date.civil(year,month,-1), fechado: false)
		saidas = Saida.where(data_saida: Date.civil(year,month,1)..Date.civil(year,month,-1), fechado: false)
		inventarios = Inventario.where(data_inventario: Date.civil(year,month,1)..Date.civil(year,month,-1), fechado: false)
		((entradas.empty? and requisicoes.empty? and saidas.empty? and inventarios.empty?) and (periodo_anterior != nil and periodo_anterior))
	end
end
