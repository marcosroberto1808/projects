class EntradaItem < ActiveRecord::Base
  validates_presence_of :material_id, message: ": O campo tem que ser preenchido."
  validates_presence_of :valor_unitario_fornecimento, :fator_multiplicador, :quantidade_fornecimento, message: ": O campo tem que ser preenchido.",  if: :not_tipo_devolucao?
  validates_uniqueness_of :material_id, scope: :entrada_id, message: ": Este tipo de material já foi adicionado."
  belongs_to :entrada, class_name: 'Entrada', foreign_key: :entrada_id
  belongs_to :material, class_name: 'Material', foreign_key: :material_id
  has_many :movimentacao_materiais

  #retorna true se não atingir o limite maximo e false se atingir/passar do limite maximo
  def valida_max_material
  	valor = self.material.get_saldo + self.quantidade
  	return valor < self.material.limite_maximo
  end

  def not_tipo_devolucao?
  	(self.entrada.tipo_entrada.id != 2)
  end

  def valida_devolucao_item(params, index)
    valido = true
    saida = Saida.find_by_id(params["saida_id"].to_i)
    saida_item = saida.saida_item.find_by(material_id: material_id)
    requisicao_item = saida_item.requisicao_item

    if requisicao_item.qde_devolvida
      #se entrada_item já existe
      #Calcula a quantidade permitida para não ser devolvido uma quantidade maior do que foi requisitado
      #Calculo: qtde_permitida = (Qtde que foi dado saída) - (qtde que já foi devolvida daquela requisição)
      quantidade_devolucao_permitida = saida_item.quantidade - (requisicao_item.qde_devolvida)
    else
      #Calculo: qtde_permitida = quantidade que foi requisitada (ou seja, ainda não foi criada nenhuma entrada para tal requisição))
      quantidade_devolucao_permitida = saida_item.quantidade
    end

    quantidade_devolver = params["qde_devolver"][index].to_f
    quantidade_devolver = 0.0 if quantidade_devolver.nil? or params["qde_devolver"][index].empty?

    #Se a quantidade que está tentando ser devolvida for maior que a quantidade permitida
    if quantidade_devolver > quantidade_devolucao_permitida
      valido = false
    end

    response = {valido: valido, erros: "Quantidade devolvida de "+material.descricao+" está maior que a quantidade de saída."}
  end
end
