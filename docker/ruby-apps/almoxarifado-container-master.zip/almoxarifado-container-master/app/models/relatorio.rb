class Relatorio < ActiveRecord::Base

	#Usado no Relatorio de Saida Atraves de um helper
	def self.get_movimentacoes_por_setor(setor, material, data_inicio, data_fim)
		saidas = Saida.joins(:requisicao).where('area = ?', setor)
		#Filtro Data
		saidas_ids = saidas.where(data_saida: data_inicio..data_fim).pluck(:id)
		saidas_itens = SaidaItem.where("saida_id in (?)", saidas_ids).pluck(:id)
		if material == ""
			movimentacoes = MovimentacaoMaterial.where("saida_item_id in (?)", saidas_itens).order('created_at DESC')
		else
			material_id = Material.find_by_descricao(material).id
			movimentacoes = MovimentacaoMaterial.where("saida_item_id in (?) and material_id = ?", saidas_itens, material_id).order('created_at DESC')
		end
	end

	#Usado nos Relatorios de Saida
	def self.get_movimentacoes_saida_ajuste_estoque(material, data_inicio, data_fim)
		if material == ""
			movimentacoes = MovimentacaoMaterial.where(data_movimento: data_inicio..data_fim).order('created_at DESC')
			movimentacoes = movimentacoes.where("inventario_item_id is not null and quantidade < 0")
		else
			material_id = Material.find_by_descricao(material).id
			movimentacoes = MovimentacaoMaterial.where(data_movimento: data_inicio..data_fim, material_id: material_id).order('created_at DESC')
			movimentacoes = movimentacoes.where("inventario_item_id is not null and quantidade < 0")
		end
	end

	#Usado no Relatorio de Entrada
	def self.get_movimentacoes_por_fornecedor(fornecedor, despesa, material, data_inicio, data_fim, nota_fiscal, nota_empenho)
		id_fornecedor = Fornecedor.where(nome_fantasia: fornecedor).pluck(:id)
		id_despesa_item = ItemDespesa.where(descricao: despesa).pluck(:id)
		ids_materias_despesas = Material.where(item_despesa_id: id_despesa_item).pluck(:id)
		#Recupera todas as entrada deste fornecedor
		entradas = Entrada.where(fornecedor_id: id_fornecedor, fechado: true, data_entrada: data_inicio..data_fim)
		#Filtrando por nota fiscal
		if nota_fiscal != ""
			entradas = entradas.where(nota_fiscal: nota_fiscal)
		end
		#Filtrando por nota empenho
		if nota_empenho != ""
			entradas = entradas.where(nota_empenho: nota_empenho)
		end
		entradas = entradas.pluck(:id)
		entrada_itens = EntradaItem.where("entrada_id in (?)", entradas)
		#Filtrando por despesa item
		if despesa != ""
			entrada_itens = entrada_itens.where("material_id in (?)", ids_materias_despesas).pluck(:id)
		else
			entrada_itens = entrada_itens.pluck(:id)
		end
		#filtrando por material
		if material == ""
			movimentacoes = MovimentacaoMaterial.where("entrada_item_id in (?)", entrada_itens).order('data_movimento ASC')
		else
			material_id = Material.find_by_descricao(material).id
			movimentacoes = MovimentacaoMaterial.where("entrada_item_id in (?) and material_id = ?", entrada_itens, material_id).order('data_movimento ASC')
		end
	end

	#Usado no Relatorio de Entrada X Saida
	def self.get_movimentacoes_por_item_despesa(despesa, material, data_inicio, data_fim)
		id_despesa_item = ItemDespesa.where(descricao: despesa).pluck(:id)
		ids_materias_despesas = Material.where(item_despesa_id: id_despesa_item).pluck(:id)
		#Filtranda Data
		saidas_ids = Saida.where(data_saida: data_inicio..data_fim).pluck(:id)
		entradas_ids = Entrada.where(data_entrada: data_inicio..data_fim).pluck(:id)
		inventarios_ids = Inventario.where(data_inventario: data_inicio..data_fim).pluck(:id)
		itens = Array.new
		#Filtrando por despesa item
		if !despesa.empty?
			entrada_itens = EntradaItem.where("material_id in (?) and entrada_id in (?)", ids_materias_despesas, entradas_ids).pluck(:id)
			saida_itens = SaidaItem.where("material_id in (?) and saida_id in (?)", ids_materias_despesas, saidas_ids).pluck(:id)
			inventario_itens = InventarioItem.where("material_id in (?) and inventario_id in (?)", ids_materias_despesas, inventarios_ids).pluck(:id)
		else
			entrada_itens = EntradaItem.where("entrada_id in (?)", entradas_ids).pluck(:id)
			saida_itens = SaidaItem.where("saida_id in (?)", saidas_ids).pluck(:id)
			inventario_itens = InventarioItem.where("inventario_id in (?)", inventarios_ids).pluck(:id)
		end

		#filtrando por material
		if material == ""
			movimentacoes = MovimentacaoMaterial.where("(entrada_item_id in (?) or saida_item_id in (?) or inventario_item_id in (?))", entrada_itens, saida_itens, inventario_itens)
		else
			material_id = Material.find_by_descricao(material).id
			movimentacoes = MovimentacaoMaterial.where("(entrada_item_id in (?) or saida_item_id in (?) or inventario_item_id in (?)) and material_id = ?", entrada_itens, saida_itens, inventario_itens, material_id)
		end
		movimentacoes = movimentacoes.order('created_at ASC')
	end

	#Usado no Relatorio de Posição
	def self.get_movimentacoes_por_item_despesa_em_posicao(despesa, material, data_fim)
		id_despesa_item = ItemDespesa.where(descricao: despesa).pluck(:id)
		ids_materias_despesas = Material.where(item_despesa_id: id_despesa_item[0]).pluck(:id)
		data_inicio = Date.new(1900,1,1)

		movimentacoes = Array.new
		if ids_materias_despesas != nil
			ids_materias_despesas.each do |id_mat|
				movimentacao_temp = MovimentacaoMaterial.where(data_movimento: data_inicio..data_fim, material_id: id_mat)
				movimentacao_temp = movimentacao_temp.order('data_movimento ASC')
				movimentacoes << movimentacao_temp.last
			end
		else
			movimentacoes = nil
		end

		#Filtro Material
		if material != ""
	 		material_id = Material.find_by_descricao(material).id
	 		movimentacoes.delete_if {|x| x.material_id != material_id }
	 	end
		#-End filtro
		movimentacoes = nil if (movimentacoes.empty?)
		return movimentacoes
	end

	def self.get_movimentacoes_entrada_devolucao_doacao(devolucao_doacao, material, data_inicio, data_fim)
		entradas_ids = TipoEntrada.find_by_descricao(devolucao_doacao).entradas.where(data_entrada: data_inicio..data_fim).order(data_entrada: :asc).ids

		entradas_itens_ids = EntradaItem.where("entrada_id in (?)", entradas_ids).pluck(:id)
		#Filtro Material
		if material == ""
			movimentacoes = MovimentacaoMaterial.where("(entrada_item_id in (?))", entradas_itens_ids)
		else
			material_id = Material.find_by_descricao(material).id
			movimentacoes = MovimentacaoMaterial.where("entrada_item_id in (?) and movimentacao_materiais.material_id = ?", entradas_itens_ids, material_id)
		end
		movimentacoes.joins(:entradas).order('entradas.data_entrada ASC')
	end

	def self.get_materiais_por_item_despesa(item_despesa)
		item_despesa_id = ItemDespesa.find_by_descricao(item_despesa)
		materias_do_item_despesa = Material.find_all_by_item_despesa_id(item_despesa_id)
	end

	def self.get_materiais_por_item_despesa_ano(item_despesa, ano)
		item_despesa_id = ItemDespesa.find_by_descricao(item_despesa)
		materias_do_item_despesa = Material.where(item_despesa_id: item_despesa_id).order(descricao: :asc)
	end

	def self.get_materiais_ressuprimento_por_item_despesa(item_despesa, material_id)
		materias_do_item_despesa = material_id.present? ? Material.where(id: material_id, item_despesa_id: item_despesa).order(descricao: :asc) :
		Material.where(item_despesa_id: item_despesa).order(descricao: :asc)
	  	materias_do_item_despesa.delete_if {|x| x.get_data_ressuprimento == nil }
	  	materias_do_item_despesa.delete_if {|x| x.get_saldo > x.limite_minimo }
	end

	def self.get_materiais_ressuprimento_por_item_despesa_ano(item_despesa, ano)
		item_despesa_id = ItemDespesa.find_by_descricao(item_despesa)
		materias_do_item_despesa = Material.find_all_by_item_despesa_id(item_despesa_id)
	  materias_do_item_despesa.delete_if {|x| x.get_data_ressuprimento == nil }
	  materias_do_item_despesa.delete_if {|x| x.get_saldo > x.limite_minimo }
	end

end
