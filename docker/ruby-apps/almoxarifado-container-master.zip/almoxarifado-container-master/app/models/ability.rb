class Ability
  include CanCan::Ability

  def initialize(user)
		funcoes = Cfue.where(["pessoa_fisica_cpf = ? and ativo = ?", user.pessoa_fisica_cpf, true]).pluck(:funcao_descricao)
		#Remove todos os poderes para ir adicionando baseado no tipo de usuário
		cannot :manage, :all

		#REQUISITANTE
		if funcoes.include? 'Requisitante' or funcoes.include? 'Defensor Público'
			can :json_autocomplete_material, Material
			can :autocomplete_material_check, Material
			can :json_autocomplete_material_requisicao, Material
			can :manage, Requisicao
			can :manage, RequisicaoItem
		end

		#ALMOXARIFE
		if funcoes.include? 'Almoxarife'
			can :manage, Relatorio
			can :manage, Saida
			can :manage, SaidaItem
			can :json_autocomplete_material, Material
			can :autocomplete_material_check, Material
		end

		#SUPERVISOR DE ALMOXARIFADO
		if funcoes.include? 'Supervisor de Almoxarifado'
			#cadastro
			can :manage, Fornecedor
			can :manage, Material
			can :manage, UnidadeMedida

			#movimentacoes
			can :json_autocomplete_material, Material
			can :autocomplete_material_check, Material
			can :json_autocomplete_material_requisicao, Material
			can :manage, Requisicao
			can :manage, RequisicaoItem
			can :manage, Entrada
			can :manage, EntradaItem
			can :manage, Saida
			can :manage, SaidaItem
			can :manage, Fechamento

			#inventario
			can :manage, InventarioItem
			can :read, Inventario
			can :index, Inventario
			can :show, Inventario
			can :new, Inventario
			can :create, Inventario
			can :edit, Inventario
			can :update, Inventario

			#relatorio
			can :manage, Relatorio
		end

		#GESTOR DE COMPRAS
		if funcoes.include? 'Gestor de Compras'	
			can :manage, Inventario
			can :manage, InventarioItem
			can :manage, Relatorio
		end

		#RELATORIO
		if funcoes.include? 'Relatório'
			can :manage, Relatorio
		end	

		#DEBUG ACCESS
		if user.pessoa_fisica_cpf == "02210439345" or user.pessoa_fisica_cpf == "00744652367"
			#cannot :manage, :all
			can :manage, :all
		end	
	end
end
