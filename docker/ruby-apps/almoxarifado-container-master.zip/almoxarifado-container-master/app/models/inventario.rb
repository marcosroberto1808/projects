class Inventario < ActiveRecord::Base
	validates :data_inventario, :observacao, presence: {message: ": O campo tem que ser preenchido."}
	has_many	 :inventario_item, dependent: :delete_all

  validate	 :inventario_aberto?, :on => :create

	def inventario_aberto?
		if Inventario.find_by_fechado(false) != nil
      errors.add(:base, "Já existe um inventário em aberto, conclua este antes de iniciar outro.")
    end    
	end
end