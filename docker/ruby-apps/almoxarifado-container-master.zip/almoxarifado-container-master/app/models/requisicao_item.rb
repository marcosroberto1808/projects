class RequisicaoItem < ActiveRecord::Base
  belongs_to :requisicao, class_name: 'Requisicao', foreign_key: :requisicao_id
  belongs_to :material, class_name: 'Material', foreign_key: :material_id
  has_many :saida_item

  validates :material_id, :quantidade, presence: true
  validates :material_id, uniqueness: { scope: :requisicao_id, message: ": Este tipo de material já foi adicionado." }

  validate	 :estoque?

  def estoque?
  	if (Material.find(material_id).get_saldo <= 0)
      errors[:base] << "Material em falta."
  	end	
  end	
end