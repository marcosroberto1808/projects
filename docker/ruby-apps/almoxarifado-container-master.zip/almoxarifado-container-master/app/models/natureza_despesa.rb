class NaturezaDespesa < ActiveRecord::Base
	  has_many :item_despesa

  def get_saldo_no_mes(mes)
  	itens_despesa_ids = ItemDespesa.where(natureza_despesa_id: id).pluck(:id)
  	material_ids = Material.where("item_despesa_id in (?)", itens_despesa_ids).pluck(:id)
  	movimentacoes = MovimentacaoMaterial.where("material_id in (?)", material_ids)
  	data_inicio = Date.new(Date.today.year,mes.to_i,1)
  	data_fim = Date.new(Date.today.year,mes.to_i,-1)
  	movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_ate_mes(mes)
  	itens_despesa_ids = ItemDespesa.where(natureza_despesa_id: id).pluck(:id)
  	material_ids = Material.where("item_despesa_id in (?)", itens_despesa_ids).pluck(:id)
  	movimentacoes = MovimentacaoMaterial.where("material_id in (?)", material_ids)
  	data_inicio = Date.new(Date.today.year,1,1)
  	data_fim = Date.new(Date.today.year,mes.to_i,-1)
  	movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_saida_no_mes(mes)
    itens_despesa_ids = ItemDespesa.where(natureza_despesa_id: id).pluck(:id)
    material_ids = Material.where("item_despesa_id in (?)", itens_despesa_ids).pluck(:id)
    movimentacoes = MovimentacaoMaterial.where("material_id in (?) and (saida_item_id IS NOT NULL or (inventario_item_id IS NOT NULL and quantidade < 0))", material_ids)
    data_inicio = Date.new(Date.today.year,mes.to_i,1)
    data_fim = Date.new(Date.today.year,mes.to_i,-1)
    movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_saida_no_mes_e_ano(mes, ano)
	ano = ano.to_i
	mes = mes.to_i
	itens_despesa_ids = ItemDespesa.where(natureza_despesa_id: id).pluck(:id)
	material_ids = Material.where("item_despesa_id in (?)", itens_despesa_ids).pluck(:id)
	movimentacoes = MovimentacaoMaterial.where(material_id: material_ids).where.not(saida_item_id: nil)
	data_inicio = Date.new(ano,mes,1)
	data_fim = Date.new(ano,mes,-1)
	movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_saida_ate_mes(mes)
    itens_despesa_ids = ItemDespesa.where(natureza_despesa_id: id).pluck(:id)
    material_ids = Material.where("item_despesa_id in (?)", itens_despesa_ids).pluck(:id)
    movimentacoes = MovimentacaoMaterial.where("material_id in (?) and (saida_item_id IS NOT NULL or (inventario_item_id IS NOT NULL and quantidade < 0))", material_ids)
    data_inicio = Date.new(Date.today.year,1,1)
    data_fim = Date.new(Date.today.year,mes.to_i,-1)
    movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_saida_ate_mes_e_ano(mes, ano)
	ano = ano.to_i
	mes = mes.to_i
	itens_despesa_ids = ItemDespesa.where(natureza_despesa_id: id).pluck(:id)
	material_ids = Material.where("item_despesa_id in (?)", itens_despesa_ids).pluck(:id)
	movimentacoes = MovimentacaoMaterial.where(material_id: material_ids).where.not(saida_item_id: nil)
	data_inicio = Date.new(ano,1,1)
	data_fim = Date.new(ano,mes,-1)
	movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_entrada_ate_mes_e_ano(mes, ano)
	ano = ano.to_i
	mes = mes.to_i
	itens_despesa_ids = ItemDespesa.where(natureza_despesa_id: id).pluck(:id)
	material_ids = Material.where("item_despesa_id in (?)", itens_despesa_ids).pluck(:id)
	movimentacoes = MovimentacaoMaterial.where(material_id: material_ids).where.not(entrada_item_id: nil)
	data_inicio = Date.new(ano,1,1)
	data_fim = Date.new(ano,mes,-1)
	movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_entrada_no_mes_e_ano(mes, ano)
   ano = ano.to_i
   mes = mes.to_i
   itens_despesa_ids = ItemDespesa.where(natureza_despesa_id: id).pluck(:id)
   material_ids = Material.where("item_despesa_id in (?)", itens_despesa_ids).pluck(:id)
   movimentacoes = MovimentacaoMaterial.where(material_id: material_ids).where.not(entrada_item_id: nil)
   data_inicio = Date.new(ano,mes,1)
   data_fim = Date.new(ano,mes,-1)
   movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end
end
