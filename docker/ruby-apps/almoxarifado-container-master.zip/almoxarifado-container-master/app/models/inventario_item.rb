class InventarioItem < ActiveRecord::Base
	validates :inventario_id, :material_id, :quantidade, presence: {message: ": O campo tem que ser preenchido."}
	validates :quantidade, numericality: { only_decimal: true, message: ": Aceito apenas decimais (ex: 23.1002)." }, :allow_nil => true
	validates_uniqueness_of :material_id, scope: :inventario_id, message: ": Este tipo de material já foi adicionado."
  belongs_to :inventario
  belongs_to :material
end
