class Saida < ActiveRecord::Base
  belongs_to :situacao
  belongs_to :tipo_saida
  belongs_to :requisicao
  has_many	 :saida_item, dependent: :destroy

	validates_uniqueness_of :requisicao_id, :message => "Já existe uma saída gerada para esta requisição"

  def get_total_saida
  	SaidaItem.sum(:quantidade, :conditions => {:saida_id => id})
  end	  

  def inventario_pendente?
  	inventario = Inventario.find_by_fechado(false)
  	material_conflitante = false

    if inventario.present?
      if self.saida_item.present? and self.saida_item.size > 0
        self.saida_item.each do |item_saida|
          inventario.inventario_item.each do |item_inventario|
            if item_saida.material_id == item_inventario.material_id
              material_conflitante = true
            end
          end
        end
      end
    end

    return material_conflitante
  end

  def devolucao_associada?
    if fechado
      self.requisicao.requisicao_item.map{ |ri| (return false) if (ri.qde_devolvida.nil? or ri.qde_devolvida == 0) }
      return true
    end
    return false
  end

  def get_devolucoes_ids
    entradas_ids = Entrada.where("requisicao_id = ? AND tipo_entrada_id = ? AND fechado = ?", self.requisicao_id, 3, true).pluck(:id)
    entradas_ids = entradas_ids.sort_by{|ids| ids}
  end


end
