class Material < ActiveRecord::Base
  validates :unidade_medida_consumo_id, :unidade_medida_fornecimento_id, :descricao, :codigo, :limite_minimo, :limite_maximo, presence: {message: ": O campo tem que ser preenchido."}
  validates :limite_maximo, :limite_minimo, numericality: { only_decimal: true, message: ": Aceito apenas decimais (ex: 23.1002)." }, :allow_nil => true
  validates :descricao, uniqueness: { message: " já existe." }
  validate :codigo_existe

  belongs_to :unidade_medida_consumo, class_name: 'UnidadeMedida', foreign_key: :unidade_medida_consumo_id
  belongs_to :unidade_medida_fornecimento, class_name: 'UnidadeMedida', foreign_key: :unidade_medida_fornecimento_id
  belongs_to :item_despesa, class_name: 'ItemDespesa', foreign_key: :item_despesa_id

  has_many :movimentacao_materiais


  def get_saldo
    MovimentacaoMaterial.where(material_id: id).sum(:quantidade)
  end

  def get_saldo_entrada
    MovimentacaoMaterial.where(material_id: id).where("entrada_item_id IS NOT NULL or (inventario_item_id IS NOT NULL and quantidade > 0)").sum(:quantidade)
  end

  def get_saldo_saida
    MovimentacaoMaterial.where(material_id: id).where("saida_item_id IS NOT NULL or (inventario_item_id IS NOT NULL and quantidade > 0)").sum(:quantidade)
  end

  def get_saldo_ano(ano)
    data_inicio = Date.new(ano,1,1)
    data_fim = Date.new(ano,-1,-1)
    MovimentacaoMaterial.where(material_id: id).sum(:quantidade)
  end

  def get_saldo_entrada_ano(ano)
    data_inicio = Date.new(ano,1,1)
    data_fim = Date.new(ano,-1,-1)
    MovimentacaoMaterial.where(material_id: id, data_movimento: data_inicio..data_fim).where("entrada_item_id IS NOT NULL or (inventario_item_id IS NOT NULL and quantidade > 0)").sum(:quantidade)
  end

  def get_saldo_saida_ano(ano)
    data_inicio = Date.new(ano,1,1)
    data_fim = Date.new(ano,-1,-1)
    MovimentacaoMaterial.where(material_id: id, data_movimento: data_inicio..data_fim).where("saida_item_id IS NOT NULL or (inventario_item_id IS NOT NULL and quantidade < 0)").sum(:quantidade)
  end

    def get_saldo_inventario(inventario)
    unless inventario == 0 #tratamento para caso onde estamos no primeiro inventário, logo não existe anterior
      inventario = Inventario.find_by_id(inventario)
      ultimo_inventario = Inventario.find_by_id(inventario.id-1)
      if ultimo_inventario #define como data inicio, 1 dia depois do ultimo inventário(quando existe) caso não ele define a data inicial como a primeira movimentação do sistema.
        data_inicio = ultimo_inventario.data_inventario.next_day
      else
        data_inicio = MovimentacaoMaterial.first.data_movimento
      end
      data_fim = inventario.data_inventario
      MovimentacaoMaterial.where(material_id: id, data_movimento: data_inicio..data_fim).sum(:quantidade)
    else
      return "0.0"
    end
  end

  def get_saldo_entrada_inventario(inventario)
    unless inventario == 0  #tratamento para caso onde estamos no primeiro inventário, logo não existe anterior
      inventario = Inventario.find_by_id(inventario)
      ultimo_inventario = Inventario.find_by_id(inventario.id-1)
      if ultimo_inventario #define como data inicio, 1 dia depois do ultimo inventário(quando existe) caso não ele define a data inicial como a primeira movimentação do sistema.
        data_inicio = ultimo_inventario.data_inventario.next_day
      else
        data_inicio = MovimentacaoMaterial.first.data_movimento
      end
      data_fim = inventario.data_inventario
      MovimentacaoMaterial.where(material_id: id, data_movimento: data_inicio..data_fim).where("entrada_item_id IS NOT NULL or (inventario_item_id IS NOT NULL and quantidade > 0)").sum(:quantidade)
    else
      return "0.0"
    end
  end

  def get_saldo_saida_inventario(inventario)
    unless inventario == 0 #tratamento para caso onde estamos no primeiro inventário, logo não existe anterior
      inventario = Inventario.find_by_id(inventario)
      ultimo_inventario = Inventario.find_by_id(inventario.id-1)
      if ultimo_inventario #define como data inicio, 1 dia depois do ultimo inventário(quando existe) caso não ele define a data inicial como a primeira movimentação do sistema.
        data_inicio = ultimo_inventario.data_inventario.next_day
      else
        data_inicio = MovimentacaoMaterial.first.data_movimento
      end
      data_fim = inventario.data_inventario
      MovimentacaoMaterial.where(material_id: id, data_movimento: data_inicio..data_fim).where("saida_item_id IS NOT NULL  or (inventario_item_id IS NOT NULL and quantidade < 0)").sum(:quantidade)
    else
      return "0.0"
    end
  end

  def get_saldo_ate_data(data)
    MovimentacaoMaterial.where("created_at <= ? and material_id = ?", data, id).sum(:quantidade)
  end

  def codigo_existe
    unless ItemDespesa.find_by(codigo: codigo)
      errors.add(:codigo, ": Item não cadastrado")
    end
  end

  def em_falta?
    saldo_em_estoque = MovimentacaoMaterial.where(material_id: id).sum(:quantidade)
    if saldo_em_estoque < limite_minimo
      true
    else
      false
    end
  end

  def get_data_ressuprimento
    movimentacoes = MovimentacaoMaterial.find_all_by_material_id(id)
    data_ressuprimento = nil
    movimentacoes.each do |movimento|
      break if data_ressuprimento != nil
      saldo = get_saldo_ate_data(movimento.data_movimento)
      if saldo < limite_minimo
        data_ressuprimento = movimento.data_movimento
      end
    end

    return data_ressuprimento
  end
end
