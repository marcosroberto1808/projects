class Colaborador < ActiveRecord::Base
	has_many :cfue, primary_key: :codigo, foreign_key: :colaborador_codigo

	#conexão com a tabela colaboradores do portaldigital
	establish_connection "colaboradores_#{Rails.env}"

	devise 	:database_authenticatable, 
					:registerable, 
					:rememberable, 
					:recoverable,
					:trackable, 
					:validatable,
					:authentication_keys => [:pessoa_fisica_cpf, :ativo]

	def email_required?
		false
	end

	# verifica se o colaborador tem a função necessaria para acessar o sistema.
	def active_for_authentication?
  	super && get_permissao
	end

	def inactive_message
	  get_permissao ? super : "Você não tem permissão para acessar o sistema."
	end
	
	def get_permissao
		self.cfue.where(ativo: true, funcao_descricao: "Almoxarife").exists? || self.cfue.where(ativo: true, funcao_descricao: "Requisitante").exists? || self.cfue.where(ativo: true, funcao_descricao: "Gestor de Compras").exists? || self.cfue.where(ativo: true, funcao_descricao: "Relatório").exists? || self.cfue.where(ativo: true, funcao_descricao: "Supervisor de Almoxarifado").exists? || self.cfue.where(ativo: true, funcao_descricao: "Defensor Público").exists?
	end

	# metodo para validar password encriptografados pelos sitemas antigos	
	def valid_password?(password)
		if self.legacy_password?
			# Use Devise's secure_compare to avoid timing attacks
			if Devise.secure_compare(self.senha, Colaborador.legacy_password(password)) 
				self.password = password
				self.password_confirmation = password
				self.legacy_password = false
				self.save!
			else
				return false
			end
		end

		super(password)
	end
 	
 	# algoritimo de criptografia usado nas senhas antigas dos colaboradores
	def self.legacy_password(password)
		return Digest::SHA1.hexdigest("--#{nil}--#{password}--")
	end
end
