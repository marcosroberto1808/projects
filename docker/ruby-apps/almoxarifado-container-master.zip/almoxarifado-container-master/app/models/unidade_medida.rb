class UnidadeMedida < ActiveRecord::Base
	validates :descricao, presence: {message: ": O campo tem que ser preenchido."}
	before_destroy :checa_dependencias, message: "Direction from' really really really can't be blank!"

	def checa_dependencias
		@materiais_consumo = Material.where(:unidade_medida_consumo_id => id).first
		@materiais_fornecimento = Material.where(:unidade_medida_fornecimento_id => id).first
		if @materiais_fornecimento != nil or @materiais_consumo != nil
			errors.add(:base, 'Você não pode remover este item, pois existem materias cadastrados usando ele.')
			return false
		else
			return true
		end
	end
end
