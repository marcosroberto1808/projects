class TipoSaida < ActiveRecord::Base
end
