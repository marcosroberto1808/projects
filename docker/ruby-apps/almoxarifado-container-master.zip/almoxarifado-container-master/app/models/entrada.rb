class Entrada < ActiveRecord::Base
  validates_presence_of :tipo_entrada_id, :data_entrada, presence: true
  validates_presence_of :fornecedor_id, :nota_fiscal, :nota_empenho, :data_emissao, :valor_nota_fiscal, if: :nota_fiscal?
  validates :nota_fiscal, :nota_empenho, numericality: {only_integer: true, allow_nil: true, message: " aceita apenas inteiros (ex: 231002)."}, if: :nota_fiscal?
  validates_uniqueness_of :nota_fiscal, :on => :create , message: " já cadastrada para o fornecedor, favor verificar.", if: (:nota_fiscal? and :fornecedor_nota_fiscal?)
  #validates_uniqueness_of :nota_empenho, message: " já cadastrada este ano, favor verificar.", if: (:nota_fiscal?)  #bloco_antigo -> if: (:nota_fiscal? and :nota_empenho_ano?)

  belongs_to :tipo_entrada, class_name: 'TipoEntrada', foreign_key: :tipo_entrada_id
  belongs_to :fornecedor, class_name: 'Fornecedor', foreign_key: :fornecedor_id
  belongs_to :situacao, class_name: 'Situacao', foreign_key: :situacao_id
  belongs_to :requisicao

  has_many	 :entrada_item, dependent: :delete_all
  has_many :movimentacao_materiais, through: :entrada_item


  def confereNota
  	valor_total = 0
  	entrada_item.each do |itens|
  		valor_total += itens.quantidade_fornecimento * itens.valor_unitario_fornecimento
  	end
  	valor_total == valor_nota_fiscal
  end

  def devolucao_update_valores(req_id)
    valor_total = 0
    entrada_item.each do |itens|
      valor_total += itens.quantidade * itens.valor_unitario
    end
    self.update(valor_nota_fiscal: valor_total, requisicao_id: req_id)
  end

  def devolucao_valida_quantidade
    itens = Array.new

    entrada_item.each do |item|
      requisicao_item = RequisicaoItem.find_by(requisicao_id: requisicao_id, material_id: item.material_id)
      saida_item = SaidaItem.find_by(requisicao_item_id: requisicao_item.id, material_id: item.material_id)
      #raise saida_item.inspect
      itens << item.material.descricao if item.quantidade > (saida_item.quantidade - requisicao_item.qde_devolvida)
    end
    #raise itens.inspect

    return {response: true} if itens.empty?
    return {response: false, erro: ("Os itens " + itens.map{|item| item}.join(", ") + " estão com valores maiores que os valores disponíveis.")}
  end

  def devolucaoUpdateQuantidadeDevolvida
    if requisicao_id
      requisicao = Requisicao.find_by_id(requisicao_id)
      #raise requisicao.inspect
      entrada_item.each do |item|
        requisicao_item = requisicao.requisicao_item.find_by_material_id(item.material_id)
        #raise requisicao_item.inspect
        qde_nova = requisicao_item.qde_devolvida - item.quantidade
        #raise qde_nova.inspect
        if qde_nova <= 0
          requisicao_item.update(qde_devolvida: 0)
        else
          requisicao_item.update(qde_devolvida: qde_nova)
        end
      end
    end
  end

  def devolucaoUpdateQuantidadeDevolvidaAdd
    if requisicao_id
      requisicao = Requisicao.find_by_id(requisicao_id)
      #raise requisicao.inspect
      entrada_item.each do |item|
        requisicao_item = requisicao.requisicao_item.find_by_material_id(item.material_id)
        #raise requisicao_item.inspect
        qde_nova = requisicao_item.qde_devolvida + item.quantidade
        #raise qde_nova.inspect
        if qde_nova <= 0
          requisicao_item.update(qde_devolvida: 0)
        else
          requisicao_item.update(qde_devolvida: qde_nova)
        end
      end
    end
  end

  #checa se é do tipo nota_fiscal
  def nota_fiscal?
  	(tipo_entrada_id == 1)
  end

# O bloco abaixo foi comentado porque foi passado depois que um fornecedor pode ter sim duas notas de empenho iguais.
=begin
  def nota_empenho_ano?
    if (tipo_entrada_id == 1)
      if id != nil #checa se é create ou update
        entrada = Entrada.find_by(nota_empenho: nota_empenho, fornecedor_id: fornecedor_id)
        if entrada.nil?
          return false #se não houver nota_empenho repetida do fornecedor para a entrada.
        else
          return true #se houver nota_empenho repetida do fornecedor para a entrada.
        end
      end
    end
  end
=end

  #Só confere a nota fiscal se for no mesmo fornecedor.
  def fornecedor_nota_fiscal?
    #checa se é create ou update
    if fornecedor_id != nil
      entrada = Entrada.find_by(nota_fiscal: nota_fiscal, fornecedor_id: fornecedor_id)

      if entrada.nil?
        return false #se não houver nota_fiscal repetida do fornecedor para a entrada.
      else
        return true #se houver nota_fiscal repetida do fornecedor para a entrada.
      end
    end
  end

  def inventario_pendente?
    inventario = Inventario.find_by_fechado(false)
    material_conflitante = false
    if inventario != nil
      if self.entrada_item.size > 0
        self.entrada_item.each do |item_entrada|
          inventario.inventario_item.each do |item_inventario|
            if item_entrada.material_id == item_inventario.material_id
              material_conflitante = true
            end
          end
        end
      end
    end

    return material_conflitante
  end

  #Serve para os que não tem valor_nota_fiscal
  def get_valor_total
    valor_total = 0.0
    entrada_item.each do |ei|
      valor_total += ei.quantidade * ei.valor_unitario
    end
    return valor_total
  end

end
