class Requisicao < ActiveRecord::Base
	belongs_to :situacao, class_name: 'Situacao', foreign_key: :situacao_id

	has_many :requisicao_item, dependent: :delete_all
	has_many :saida
	has_many :entrada

  def get_total_requisicao
  	RequisicaoItem.sum(:quantidade, :conditions => {:requisicao_id => id})
  end

	#Usado no Relatorio de Requisições
	def get_movimentacoes
		saida = Saida.find_by_requisicao_id(id)
		saida_item_ids = SaidaItem.find_all_by_saida_id(saida.id)
		movimentacoes = MovimentacaoMaterial.where("(saida_item_id in (?))", saida_item_ids)
		movimentacoes.joins(:material).order('materiais.descricao ASC')
	end

end
