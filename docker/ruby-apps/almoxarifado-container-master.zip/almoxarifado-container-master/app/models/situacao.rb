class Situacao < ActiveRecord::Base
  validates :descricao, presence: true
end
