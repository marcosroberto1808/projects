class ItemDespesa < ActiveRecord::Base
  belongs_to :natureza_despesa, class_name: 'NaturezaDespesa', foreign_key: :natureza_despesa_id
  has_many :material
  has_many :movimentacao_materiais, through: :material

  def get_saldo
  	material_ids = Material.find_all_by_item_despesa_id(id)
  	movimentacoes = MovimentacaoMaterial.where("material_id in (?)", material_ids)
  	movimentacoes.sum("valor_unitario * quantidade")
  end

  def get_saldo_ate_mes(mes)
  	material_ids = Material.find_all_by_item_despesa_id(id)
  	movimentacoes = MovimentacaoMaterial.where("material_id in (?)", material_ids)
  	data_inicio = Date.new(Date.today.year,1,1)
  	data_fim = Date.new(Date.today.year,mes.to_i,-1)
  	movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_no_mes(mes)
  	material_ids = Material.find_all_by_item_despesa_id(id)
  	movimentacoes = MovimentacaoMaterial.where("material_id in (?)", material_ids)
  	data_inicio = Date.new(Date.today.year,mes.to_i,1)
  	data_fim = Date.new(Date.today.year,mes.to_i,-1)
  	movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_saida
    material_ids = Material.find_all_by_item_despesa_id(id)
    movimentacoes = MovimentacaoMaterial.where("material_id in (?) and (saida_item_id IS NOT NULL or (inventario_item_id IS NOT NULL and quantidade < 0))", material_ids)
    movimentacoes.sum("valor_unitario * quantidade")
  end

  def get_saldo_saida_ate_mes(mes)
    material_ids = Material.find_all_by_item_despesa_id(id)
    movimentacoes = MovimentacaoMaterial.where("material_id in (?) and (saida_item_id IS NOT NULL or (inventario_item_id IS NOT NULL and quantidade < 0))", material_ids)
    data_inicio = Date.new(Date.today.year,1,1)
    data_fim = Date.new(Date.today.year,mes.to_i,-1)
    movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_saida_ate_mes_e_ano(mes, ano)
    ano = ano.to_i
    mes = mes.to_i
    material_ids = Material.find_all_by_item_despesa_id(id)
    movimentacoes = MovimentacaoMaterial.where(material_id: material_ids).where.not(saida_item_id: nil)
    data_inicio = Date.new(ano,1,1)
    data_fim = Date.new(ano,mes,-1)
    movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_saida_no_mes(mes)
    material_ids = Material.find_all_by_item_despesa_id(id)
    movimentacoes = MovimentacaoMaterial.where("material_id in (?) and (saida_item_id IS NOT NULL or (inventario_item_id IS NOT NULL and quantidade < 0))", material_ids)
    data_inicio = Date.new(Date.today.year,mes.to_i,1)
    data_fim = Date.new(Date.today.year,mes.to_i,-1)
    movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_saida_no_mes_e_ano(mes, ano)
    ano = ano.to_i
    mes = mes.to_i
    material_ids = Material.find_all_by_item_despesa_id(id)
    movimentacoes = MovimentacaoMaterial.where(material_id: material_ids).where.not(saida_item_id: nil)
    data_inicio = Date.new(ano,mes,1)
    data_fim = Date.new(ano,mes,-1)
    movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_entrada_no_mes_e_ano(mes, ano)
    ano = ano.to_i
    mes = mes.to_i
    material_ids = Material.find_all_by_item_despesa_id(id)
    movimentacoes = MovimentacaoMaterial.where(material_id: material_ids).where.not(entrada_item_id: nil)
    data_inicio = Date.new(ano,mes,1)
    data_fim = Date.new(ano,mes,-1)
    movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

  def get_saldo_entrada_ate_mes_e_ano(mes, ano)
    ano = ano.to_i
    mes = mes.to_i
    material_ids = Material.find_all_by_item_despesa_id(id)
    movimentacoes = MovimentacaoMaterial.where(material_id: material_ids).where.not(entrada_item_id: nil)
    data_inicio = Date.new(ano,1,1)
    data_fim = Date.new(ano,mes,-1)
    movimentacoes.where(data_movimento: data_inicio..data_fim).sum("valor_unitario * quantidade")
  end

end
