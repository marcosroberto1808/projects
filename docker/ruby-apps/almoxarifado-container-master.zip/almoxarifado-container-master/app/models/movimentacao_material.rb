class MovimentacaoMaterial < ActiveRecord::Base
	belongs_to :entrada_item, class_name: 'EntradaItem', foreign_key: :entrada_item_id
	belongs_to :saida_item, class_name: 'SaidaItem', foreign_key: :saida_item_id
	belongs_to :inventario_item, class_name: 'InventarioItem', foreign_key: :inventario_item_id
	belongs_to :material, class_name: 'Material', foreign_key: :material_id
	has_many :entradas, through: :entrada_item
end
