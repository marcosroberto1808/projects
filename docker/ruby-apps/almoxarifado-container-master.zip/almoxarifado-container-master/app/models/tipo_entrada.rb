class TipoEntrada < ActiveRecord::Base
    has_many :entradas
end
