class SaidaItem < ActiveRecord::Base
  belongs_to :saida
  belongs_to :material
  belongs_to :requisicao_item
  validate	 :checa_estoque, :checa_quantidade

  def checa_quantidade
    if RequisicaoItem.find(self.requisicao_item_id).quantidade.to_i < quantidade.to_i
      errors.add(:quantidade, "não pode ser maior que a solicitada.")
    end  
  end

  def checa_estoque
  	if self.material.get_saldo.to_i < quantidade.to_i
      errors.add(:quantidade, "não pode ser maior que o estoque.")
  	end		
  end

  #retorna true se não atingir o limite minimo e false se atingir/passar do limite minimo
  def valida_min_material
    valor = self.material.get_saldo - self.quantidade
    
    if valor <= self.material.limite_minimo       
      # AlmoxarifadoMailer.send_mail_min_material_saida(Cfue.where(funcao_descricao: 'Almoxarife'), self)
      false
    else
      true
    end    
  end

  def self.get_saida_item_quantidade_by_material_id(id)
    find_by_material_id(id).quantidade
  end
end
