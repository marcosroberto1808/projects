class Fornecedor < ActiveRecord::Base
	validates :razao_social, :nome_fantasia, :cnpj, :endereco, :numero, :cep, :estado, :cidade, presence: {message: ": O campo tem que ser preenchido."}
	validates :razao_social, :nome_fantasia, :endereco, length: {maximum: 100, message: "%{value} (máximo 100 caracteres)."}
	validates :cnpj, :telefone1, :telefone2, :telefone3, length: {maximum: 20, message: "%{value} (máximo 20 caracteres)."}
	validates :numero, :cep, length: {maximum: 10, message: "%{value} (máximo 10 caracteres)."}
	validates :complemento, length: {maximum: 250, message: "%{value} (máximo 250 caracteres)."}
	validates :estado, length: {maximum: 2, message: "%{value} (máximo 2 caracteres)."}
	validates :cidade, :email, length: {maximum: 50, message: "%{value} (máximo 50 caracteres)."}
	validates :estado, :cidade, format: { with: /\A[a-zA-Z]+\z/, message: "permitido apenas letras."}

	def teste
		raise "teste"
	end
end