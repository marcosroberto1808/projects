class InventarioItensController < ApplicationController
  before_action :set_inventario_item, only: [:show, :edit, :update, :destroy]

  #CONFIGURAÇÕES DO CANCAN
  load_and_authorize_resource #Carregando Autorizações do cancan

  def inventario_item_params #workaround para o problema com strong parameter do cancan
    params.require(:inventario_item).permit(:what, :ever)
  end
  #END CANCAN CONFIG

  def create
    @inventario_item = InventarioItem.new(inventario_item_params)
    material = Material.find_by(descricao: params["material"].split(" | ")[0]) if params["material"] != ""
    @inventario_item.material_id = material.id if material 
    if params[:valor_medio] != '' and params[:valor_medio] != nil
      @inventario_item.valor_medio = params[:valor_medio]
    else
      @inventario_item.valor_medio = material.valor_medio
    end
    respond_to do |format|
      if @inventario_item.save
        format.html { redirect_to edit_inventario_path(@inventario_item.inventario), notice: t(:successfully_save_m, objeto: "Item") }
        format.json { render action: 'edit', status: :created, location: @inventario_item.inventario }
      else    
        format.html { redirect_to edit_inventario_path(@inventario_item.inventario, error: @inventario_item.errors.messages) }
        format.json { render json: @inventario_item.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @inventario_item.destroy
    respond_to do |format|
      format.html { redirect_to :back }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_inventario_item
      @inventario_item = InventarioItem.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def inventario_item_params
      params.require(:inventario_item).permit(:inventario_id, :material_id, :quantidade, :valor_medio)
    end
end
