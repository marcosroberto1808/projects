class UnidadeMedidasController < ApplicationController
  before_action :set_unidade_medida, only: [:show, :edit, :update, :destroy]

	#CONFIGURAÇÕES DO CANCAN
	load_and_authorize_resource	#Carregando Autorizações do cancan

	def unidade_medida_params	#workaround para o problema com strong parameter do cancan
		params.require(:unidade_medida).permit(:what, :ever)
	end
	#END CANCAN CONFIG

  def index
    @unidade_medidas = UnidadeMedida.page(params[:page]).order(descricao: :asc)
    @unidade_medidas = UnidadeMedida.page(1).order(descricao: :asc) if @unidade_medidas.any? == false
    @setor = "Unidades de Medidas"
  end

  def show
  end

  def new
    @unidade_medida = UnidadeMedida.new
    @setor = "Unidades de Medidas"
  end

  def edit
    @setor = "Unidades de Medidas"
  end

  def create
    @unidade_medida = UnidadeMedida.new(unidade_medida_params)
    @setor = "Unidades de Medidas"

    respond_to do |format|
      if @unidade_medida.save
        format.html { redirect_to @unidade_medida, notice: t(:successfully_save_m, objeto: "Unidade de Medida") }
        format.json { render action: 'show', status: :created, location: @unidade_medida }
      else
        format.html { render action: 'new' }
        format.json { render json: @unidade_medida.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    @setor = "Unidades de Medidas"
    respond_to do |format|
      if @unidade_medida.update(unidade_medida_params)
        format.html { redirect_to @unidade_medida, notice: t(:successfully_updated_m, objeto: "Unidade de Medida") }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @unidade_medida.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @setor = "Unidades de Medidas"
    @unidade_medida.destroy
    respond_to do |format|
      format.html { redirect_to unidade_medidas_url, :alert => @unidade_medida.errors[:base][0] }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_unidade_medida
      @unidade_medida = UnidadeMedida.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def unidade_medida_params
      params.require(:unidade_medida).permit(:descricao)
    end
end
