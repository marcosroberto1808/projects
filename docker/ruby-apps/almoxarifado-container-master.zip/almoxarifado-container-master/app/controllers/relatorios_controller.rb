class RelatoriosController < ApplicationController
  #CONFIGURAÇÕES DO CANCAN
  load_and_authorize_resource #Carregando Autorizações do cancan
  #END CANCAN CONFIG
  before_action :set_filtros_entrada_e_saida_financeira, only: [:saida_financeira, :entrada_financeira]

  def show
    render layout: false
  end

  def saida
    @setor = "Relatório de Saídas"

  	@areas = Requisicao.all.pluck('DISTINCT area')
  end

  def saida_relatorio
    @setor = "Relatório de Saídas"
    @setores = Array.new
    #Validação Material
    @material = Material.where(descricao: params["material"]).pluck(:descricao)
    if params["material"] != "" and @material.length == 0
      flash[:alert] = "O Material pesquisado não existe."
      redirect_to :back
    end
    @material = params["material"]

    #Validação Datas
    begin
      if params["data_inicio"] != ""
        Date.parse(params["data_inicio"])
      end
      if params["data_fim"] != ""
        Date.parse(params["data_fim"])
      end
      if params["data_inicio"].length < 10 and params["data_inicio"].length > 0
        raise "erro"
      end
      if params["data_fim"].length < 10 and params["data_fim"].length > 0
        raise "erro"
      end
    rescue
      flash[:alert] = "Data Invalida."
      redirect_to :back
    end

    @todos = false
    if params["area"] == ""
      @todos = true
    end
  	if params["area"] != ""
  		@setores << params["area"]
  	else
  		@setores = Requisicao.all.pluck('DISTINCT area')
  	end

  	if params["data_inicio"] != ""
  		@data_inicio = params["data_inicio"]
  	else
  		@data_inicio = "01/01/1900"
  	end

  	if params["data_fim"] != ""
  		@data_fim = params["data_fim"]
  	else
  		@data_fim = "01/01/2900"
  	end
  end

  def entrada
    @setor = "Relatório de Entradas"

    @fornecedores = Fornecedor.all.pluck(:nome_fantasia)
    item_despesa_ids = Material.all.pluck('DISTINCT item_despesa_id')
    @item_despesa = ItemDespesa.where("id in (?)", item_despesa_ids).pluck(:descricao)
  end

  def entrada_relatorio
    #Validação Material
    @setor = "Relatório de Entradas"

    @material = Material.where(descricao: params["material"]).pluck(:descricao)
    if params["material"] != "" and @material.length == 0
      flash[:alert] = "O Material pesquisado não existe."
      redirect_to :back
    end

    #Validação Data Valida
    begin
      if params["data_inicio"] != ""
        Date.parse(params["data_inicio"])
      end
      if params["data_fim"] != ""
        Date.parse(params["data_fim"])
      end
      if params["data_inicio"].length < 10 and params["data_inicio"].length > 0
        raise "erro"
      end
      if params["data_fim"].length < 10 and params["data_fim"].length > 0
        raise "erro"
      end
    rescue
      flash[:alert] = "Data Invalida."
      redirect_to :back
    end

    @fornecedores = Array.new
    @material = params["material"]
    @nota_fiscal = params["nota_fiscal"]
    @nota_empenho = params["nota_empenho"]
    @item_despesa = params["item_despesa"]
    @todos = false
    if params["fornecedor"] == ""
      @todos = true
    end

    if params["fornecedor"] != ""
      @fornecedores << params["fornecedor"]
    else
      @fornecedores = Fornecedor.all.pluck(:nome_fantasia)
    end

    if params["data_inicio"] != ""
      @data_inicio = params["data_inicio"]
    else
      @data_inicio = "01/01/1900"
    end

    if params["data_fim"] != ""
      @data_fim = params["data_fim"]
    else
      @data_fim = "01/01/3000"
    end
  end

  def posicao
    @setor = "Relatório de Posição"

    @item_despesa = ItemDespesa.uniq.pluck(:descricao)
  end

  def posicao_relatorio
    @setor = "Relatório de Posição"

    erros = ""
    @qde_e_materiais = Array.new
    params[:data_inicio_aux] = (l Date.new(1960, 1, 1))
    params[:data_posicao] = (l Date.today) if params[:data_posicao].empty?

    validacao = posicao_relatorio_validacao(params)
    erros = validacao[:erros]
    #raise validacao.inspect

    if (validacao[:response])
      @qde_e_materiais = posicao_relatorio_get_movimentacoes(params)
    else
      redirect_to relatorios_posicao_path({:erros => erros})
    end

  end

  def posicao_relatorio_validacao(params)
    erros = Array.new
    response = true
    data = true
    syntax_data_posicao = true

    params[:data_inicio_aux]

    data = (params[:data_inicio_aux]<=params[:data_posicao])
    syntax_data_posicao = (params[:data_posicao].length == 10)

    if data == false
      erros << ("Data posicao não pode ser menor que "+params[:data_inicio_aux].to_s+".")
    end
    if syntax_data_posicao == false
      erros << ("Data Posição ("+params[:data_posicao].to_s+") inadequada.")
    end

    response = false if (!erros.empty?)
    retorno = {response: response, erros: erros}
  end

  def posicao_relatorio_get_movimentacoes(params)
    movimentacoes = Array.new
    materiais = Material.all

    if (!params[:item_despesa].nil? and !params[:item_despesa].empty?)
      item_despesa_id = ItemDespesa.find_by_descricao(params[:item_despesa]).id
      materiais = Material.where(item_despesa_id: item_despesa_id)

      if (!params[:material].nil? and !params[:material].empty?)
        materiais = Material.where('descricao = ? AND item_despesa_id = ?', params[:material], item_despesa_id)
      end

    elsif (!params[:material].nil? and !params[:material].empty?)
      materiais = Material.where('descricao = ?', params[:material])
    end

    lista = Array.new
    #Ordenar a lista por ordem de item de despesa e pega o total pela param data_posicao
    if (!materiais.nil? and !materiais.empty?)
      #ordena do menor pelo maior usando a descricao
      materiais = materiais.order(descricao: :asc)
      materiais.each do |material|
        movimentacoes = MovimentacaoMaterial.where('material_id = ? and data_movimento <= ?', material.id, params[:data_posicao] )
        if movimentacoes.any?
          quantidade_data = movimentacoes.sum(:quantidade)
          valor_medio_data = movimentacoes.last.valor_medio
          lista << [quantidade_data, material, valor_medio_data] if (!quantidade_data.nil? and !valor_medio_data.nil?)
        end
      end

      # A lista está no seguinte formato:
      # lista = [ [quantidade_data0, material0, valor_medio_data0], ... ]
      # Agrupa por item de despesa.
      lista = lista.group_by { |l| l[1][:item_despesa_id]}
      # Após o agrupamento a lista vai virar um hash
      # lista = {item_despesa_id0 => [ [quantidade_data0.1, material0.1, valor_medio_data0.1], ... ], ...}
    end
    lista
  end

  def entrada_saida
    @setor = "Relatório de Entrada e Saídas"

    item_despesa_ids = Material.all.pluck('DISTINCT item_despesa_id')
    @item_despesa = ItemDespesa.where("id in (?)", item_despesa_ids).pluck(:descricao)
  end

  def entrada_saida_relatorio
    @setor = "Relatório de Entrada e Saídas"

    @item_despesa_tipos = Array.new
    #Validação Material
    @material = Material.where(descricao: params["material"]).pluck(:descricao)
    if params["material"] != "" and @material.length == 0
      flash[:alert] = "O Material pesquisado não existe."
      redirect_to :back
    end
    @material = params["material"]
    #Validação Datas
    begin
      if params["data_inicio"] != ""
        Date.parse(params["data_inicio"])
      end
      if params["data_fim"] != ""
        Date.parse(params["data_fim"])
      end
      if params["data_inicio"].length < 10 and params["data_inicio"].length > 0
        raise "erro"
      end
      if params["data_fim"].length < 10 and params["data_fim"].length > 0
        raise "erro"
      end
    rescue
      flash[:alert] = "Data Invalida."
      redirect_to :back
    end


    @material = params["material"]
    @todos = false
    if params["item_despesa"] == ""
      @todos = true
    end
    if params["item_despesa"] != ""
      @item_despesa_tipos << params["item_despesa"]
    else
      item_despesa_ids = Material.all.pluck('DISTINCT item_despesa_id')
      @item_despesa_tipos = ItemDespesa.where("id in (?)", item_despesa_ids).pluck(:descricao)
    end

    if params["data_inicio"] != ""
      @data_inicio = params["data_inicio"]
    else
      @data_inicio = "01/01/1900"
    end

    if params["data_fim"] != ""
      @data_fim = params["data_fim"]
    else
      @data_fim = "01/01/3000"
    end
  end

  def entrada_devolucao
    @setor = "Relatório de Entrada"

    @areas = Requisicao.uniq.pluck(:area)
    @despesa_itens = ItemDespesa.pluck(:descricao)
  end

  def entrada_relatorio_devolucao
    @setor = "Relatório de Entrada"

    erros = Array.new
    @devolucoes = Array.new
    validacao = entrada_relatorio_devolucao_valida_parametros(params)
    erros = validacao[:erros]

    if validacao[:response]
      @data_inicio = (l Date.new(1960, 1, 1)) if params[:data_inicio].empty?
      @data_fim = (l Date.today) if params[:data_fim].empty?
      @devolucoes = entrada_relatorio_devolucao_get_devolucoes(params, @data_inicio, @data_fim)
    else
      redirect_to relatorios_entrada_devolucao_path({:erros => erros})
    end
  end

  def entrada_relatorio_devolucao_valida_parametros(params)
    erros = Array.new
    response = true
    area = true
    item_despesa = true
    data = true
    syntax_data_inicio = true
    syntax_data_fim = true

    params[:data_inicio].empty? ? (@data_inicio = (l Date.new(1960, 1, 1))) : (@data_inicio = params[:data_inicio])
    params[:data_fim].empty? ? (@data_fim = l Date.today) : (@data_fim = params[:data_fim])

    area = (!Requisicao.find_by_area(params[:area]).nil?) if (!(params[:area].gsub(/\s+/, "").empty?))
    item_despesa = (!ItemDespesa.find_by_descricao(params[:item_despesa]).nil?) if (!params[:item_despesa].empty?)
    data = (@data_inicio<=@data_fim)
    syntax_data_inicio = (@data_inicio.length == 10)
    syntax_data_fim = (@data_fim.length == 10)

    if area == false
      erros << "Área ("+params[:area]+") não encontrada."
    end
    if item_despesa == false
      erros << "Item de Despesa ("+params[:item_despesa]+") não encontrado."
    end
    if data == false
      erros << ("Data Inicio ("+@data_inicio.to_s+") maior que a Data Fim ("+@data_fim.to_s+").")
    end
    if syntax_data_inicio == false
      erros << ("Data Inicio ("+@data_inicio.to_s+") inadequada.")
    end
    if syntax_data_fim == false
      erros << ("Data Fim ("+@data_fim.to_s+") inadequada.")
    end

    response = false if (!erros.empty?)
    retorno = {response: response, erros: erros}
  end

  def entrada_relatorio_devolucao_get_devolucoes(params, data_inicio, data_fim)
    response = Array.new
    msgs = Array.new
    entradas = Entrada.where("tipo_entrada_id = ? AND data_entrada >= ? AND data_entrada <= ? AND fechado = ?", 3, data_inicio, data_fim, true)
    itens_devolvidos = Array.new
    if entradas.any?

      if (!params[:area].empty?)
        new_entradas = Array.new
        entradas.each do |entrada|
          if (entrada.requisicao.area == params[:area])
            new_entradas << entrada
          end
        end
        entradas = new_entradas
        itens_devolvidos = get_itens_devolvidos(entradas, params[:item_despesa])

      else
        itens_devolvidos = get_itens_devolvidos(entradas, params[:item_despesa])
      end
    end
  end

  def get_itens_devolvidos(entradas, item_despesa)
    itens_entrada = Array.new

    if (!item_despesa.empty?)
      entradas.each do |entrada|
        entrada.entrada_item.each do |item|
          if item.material.item_despesa.descricao == item_despesa
            itens_entrada << item
          end
        end
      end
    else
      entradas.each do |entrada|
        entrada.entrada_item.each do |item|
          itens_entrada << item
        end
      end
    end

    #Ordena lista
    lista = Array.new
    itens_despesa = ItemDespesa.find(:all)
    itens_despesa.each do |item_despesa|
      temp_itens = Array.new
      itens_entrada.each do |item_entrada|
        temp_itens << item_entrada if (item_entrada.material.item_despesa_id == item_despesa.id)
      end
      if temp_itens.any?
        # A linha abaixo organiza pela maior data de entrada.
        temp_itens = temp_itens.sort { |x, y| y.entrada.data_entrada <=> x.entrada.data_entrada }
        lista << temp_itens
        temp_itens.each do |item|
          itens_entrada.delete(item)
        end
      end
    end
    lista
  end

  def entrada_doacao
    @setor = "Relatório de Entrada"
  end

  def entrada_relatorio_doacao
    #Validação Material
    @setor = "Relatório de Entrada"

    @material = Material.where(descricao: params["material"]).pluck(:descricao)
    if params["material"] != "" and @material.length == 0
      flash[:alert] = "O Material pesquisado não existe."
      redirect_to :back
    end
    @material = params["material"]

    #Validação Datas
    begin
      if params["data_inicio"] != ""
        Date.parse(params["data_inicio"])
      end
      if params["data_fim"] != ""
        Date.parse(params["data_fim"])
      end
      if params["data_inicio"].length < 10 and params["data_inicio"].length > 0
        raise "erro"
      end
      if params["data_fim"].length < 10 and params["data_fim"].length > 0
        raise "erro"
      end
    rescue
      flash[:alert] = "Data Invalida."
      redirect_to :back
    end

    if params["data_inicio"] != ""
      @data_inicio = params["data_inicio"]
    else
      @data_inicio = "01/01/1900"
    end

    if params["data_fim"] != ""
      @data_fim = params["data_fim"]
    else
      @data_fim = "01/01/3000"
    end
  end

  def ressuprimento
    @setor = "Relatório de Ressuprimento"

    item_despesa_ids = Material.all.pluck('DISTINCT item_despesa_id')
    @item_despesa = ItemDespesa.where(id: item_despesa_ids).pluck(:descricao, :id)
    @material = Material.all.order(:descricao).pluck(:descricao, :id)
  end

  def ressuprimento_items
    item_despesa_id = params["item_despesa_id"]
    @material = item_despesa_id.present? ? Material.where(item_despesa_id: item_despesa_id).order(:descricao).pluck(:descricao, :id) :
    Material.all.order(:descricao).pluck(:descricao, :id)

    render layout: false
  end

  def ressuprimento_relatorio
    setor = "Relatório de Ressuprimento"
    @material = params["material"]

    @item_despesa_ids = params["item_despesa"].present? ? [params["item_despesa"].to_i] : Material.all.pluck(:item_despesa_id).uniq()

    @descricao_material = params["material"].present? ? Material.find(@material).descricao : "Todos"
    @descricao_item_despesa = params["item_despesa"].present? ? ItemDespesa.find(params["item_despesa"]).descricao : "Todos"
  end

  def saida_financeira

  end

  def saida_financeira_relatorio
    @natureza_despesas = params["natureza_despesa"].present? ? NaturezaDespesa.where(id: params["natureza_despesa"]) : NaturezaDespesa.all
    @ano = params["ano"]
    @mes = params["mes"]

    @item_despesa_tipos = []

    if params["item_despesa"].present?
      @item_despesa = ItemDespesa.find(params['item_despesa'])
      render 'saida_financeira_item_despesa_unico_relatorio'
    end
  end

  def saida_financeira_detalhamento_relatorio
    @mes = params[:mes]
    @ano = params[:ano]
    @item_despesa = ItemDespesa.find_by_descricao(params[:item_despesa])
    data_civil_inicial = Date.civil(@ano.to_i, @mes.to_i, 1)
    data_civil_final = Date.civil(@ano.to_i, @mes.to_i, -1)

    @movimentacoes = @item_despesa.movimentacao_materiais.where(data_movimento: data_civil_inicial..data_civil_final)
    .where.not(saida_item_id: [nil, ""]).order('movimentacao_materiais.material_id').select(:material_id, :valor_total)
    .group('movimentacao_materiais.material_id').sum(:valor_total)

    @movimentacoes = Hash[@movimentacoes.map { |k, v| [Material.find(k).descricao, v] }]
    @total = 0
    @movimentacoes.each { |k, v| @total += v }
  end

  def entrada_financeira

  end

  def entrada_financeira_relatorio
    @natureza_despesas = params["natureza_despesa"].present? ? NaturezaDespesa.where(id: params["natureza_despesa"]) : NaturezaDespesa.all
    @ano = params["ano"]
    @mes = params["mes"]

    @item_despesa_tipos = []

    if params["item_despesa"].present?
      @item_despesa = ItemDespesa.find(params['item_despesa'])
      render 'entrada_financeira_item_despesa_unico_relatorio'
    end

  end

  def entrada_financeira_detalhamento_relatorio
    @mes = params[:mes]
    @ano = params[:ano]
    @item_despesa = ItemDespesa.find_by_descricao(params[:item_despesa])
    data_civil_inicial = Date.civil(@ano.to_i, @mes.to_i, 1)
    data_civil_final = Date.civil(@ano.to_i, @mes.to_i, -1)

    @movimentacoes = @item_despesa.movimentacao_materiais.where(data_movimento: data_civil_inicial..data_civil_final)
    .where.not(entrada_item_id: [nil, ""]).order('movimentacao_materiais.material_id').select(:material_id, :valor_total)
    .group('movimentacao_materiais.material_id').sum(:valor_total)

    @movimentacoes = Hash[@movimentacoes.map { |k, v| [Material.find(k).descricao, v] }]
    @total = 0
    @movimentacoes.each { |k, v| @total += v }
  end

  def requisicao
    @setor = "Relatório de Saída"

  end

  def requisicao_relatorio
    @setor = "Relatório de Requisição"

    @requisicao = Requisicao.find_by_id(params['requisicao'])

    if @requisicao == nil
      flash[:alert] = "Número de Requisição Inválido."
      redirect_to :back
    else
      if (Saida.find_by_requisicao_id(@requisicao.id)) == nil
        flash[:alert] = "Não foi dada Saída para esta Requisição."
        redirect_to :back
      end
    end
  end

  def inventario
    @setor = "Inventário"

    @anos = MovimentacaoMaterial.all.pluck(:data_movimento).map{|x| x.year}.uniq
    item_despesa_ids = Material.all.pluck('DISTINCT item_despesa_id')
    @item_despesa = ItemDespesa.where("id in (?)", item_despesa_ids).pluck(:descricao)
  end

  def inventario_relatorio
    @setor = "Inventário"

    @item_despesa_tipos = Array.new
    @item_despesa_tipos_model = Array.new
    @ano = params['ano'].to_i

    if params["item_despesa"] == ""
      @todos = true
    end
    if params["item_despesa"] != ""
      @item_despesa_tipos_model << ItemDespesa.find_by_descricao(params["item_despesa"])
      @item_despesa_tipos = ItemDespesa.where(descricao: params["item_despesa"]).pluck(:descricao)
    else
      item_despesa_ids = Material.all.pluck('DISTINCT item_despesa_id')
      @item_despesa_tipos = ItemDespesa.where("id in (?)", item_despesa_ids).pluck(:descricao)
      @item_despesa_tipos_model = ItemDespesa.where("id in (?)", item_despesa_ids)
    end
  end

  private
  def set_filtros_entrada_e_saida_financeira
    @natureza_despesas = NaturezaDespesa.all.pluck(:descricao, :id)
    @item_despesa = ItemDespesa.where(id: Material.all.pluck(:item_despesa_id).uniq()).pluck(:descricao, :id)

    ano_inicio = MovimentacaoMaterial.first.data_movimento.year
    ano_fim = MovimentacaoMaterial.last.data_movimento.year
    @anos = (ano_inicio..ano_fim).to_a.reverse

    @meses = []
    (1..12).each { |mes| @meses << [t("date.month_names")[mes], mes] }
  end

end
