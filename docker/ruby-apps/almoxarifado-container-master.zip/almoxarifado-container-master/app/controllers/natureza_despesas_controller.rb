class NaturezaDespesasController < ApplicationController
  before_action :set_natureza_despesa, only: [:show, :edit, :update, :destroy]

  # GET /natureza_despesas
  # GET /natureza_despesas.json
  def index
    @natureza_despesas = NaturezaDespesa.all
  end

  # GET /natureza_despesas/1
  # GET /natureza_despesas/1.json
  def show
  end

  # GET /natureza_despesas/new
  def new
    @natureza_despesa = NaturezaDespesa.new
  end

  # GET /natureza_despesas/1/edit
  def edit
  end

  # POST /natureza_despesas
  # POST /natureza_despesas.json
  def create
    @natureza_despesa = NaturezaDespesa.new(natureza_despesa_params)

    respond_to do |format|
      if @natureza_despesa.save
        format.html { redirect_to @natureza_despesa, notice: 'Natureza despesa was successfully created.' }
        format.json { render action: 'show', status: :created, location: @natureza_despesa }
      else
        format.html { render action: 'new' }
        format.json { render json: @natureza_despesa.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /natureza_despesas/1
  # PATCH/PUT /natureza_despesas/1.json
  def update
    respond_to do |format|
      if @natureza_despesa.update(natureza_despesa_params)
        format.html { redirect_to @natureza_despesa, notice: 'Natureza despesa was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @natureza_despesa.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /natureza_despesas/1
  # DELETE /natureza_despesas/1.json
  def destroy
    @natureza_despesa.destroy
    respond_to do |format|
      format.html { redirect_to natureza_despesas_url }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_natureza_despesa
      @natureza_despesa = NaturezaDespesa.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def natureza_despesa_params
      params.require(:natureza_despesa).permit(:descricao)
    end
end
