class TipoSaidasController < ApplicationController
  before_action :set_tipo_saida, only: [:show, :edit, :update, :destroy]

	#CONFIGURAÇÕES DO CANCAN
	load_and_authorize_resource	#Carregando Autorizações do cancan

	def tipo_saida_params	#workaround para o problema com strong parameter do cancan
		params.require(:tipo_saida).permit(:what, :ever)
	end
	#END CANCAN CONFIG

  def index
    @tipo_saidas = TipoSaida.page(params[:page]).order('created_at DESC')
    @tipo_saidas = TipoSaida.page(1).order('created_at DESC') if @tipo_saidas.any? == false
  end

  def show
  end

  def new
    @tipo_saida = TipoSaida.new
  end

  def edit
  end

  def create
    @tipo_saida = TipoSaida.new(tipo_saida_params)

    respond_to do |format|
      if @tipo_saida.save
        format.html { redirect_to @tipo_saida, notice: 'Tipo saida was successfully created.' }
        format.json { render action: 'show', status: :created, location: @tipo_saida }
      else
        format.html { render action: 'new' }
        format.json { render json: @tipo_saida.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @tipo_saida.update(tipo_saida_params)
        format.html { redirect_to @tipo_saida, notice: 'Tipo saida was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @tipo_saida.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @tipo_saida.destroy
    respond_to do |format|
      format.html { redirect_to tipo_saidas_url }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_tipo_saida
      @tipo_saida = TipoSaida.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def tipo_saida_params
      params.require(:tipo_saida).permit(:descricao)
    end
end
