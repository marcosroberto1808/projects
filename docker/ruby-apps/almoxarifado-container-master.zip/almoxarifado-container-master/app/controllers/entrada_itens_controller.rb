class EntradaItensController < ApplicationController
  before_action :set_entrada_item, only: [:show, :edit, :update, :destroy]

	#CONFIGURAÇÕES DO CANCAN
	load_and_authorize_resource	#Carregando Autorizações do cancan

	def entrada_item_params	#workaround para o problema com strong parameter do cancan
		params.require(:entrada_item).permit(:what, :ever)
	end
	#END CANCAN CONFIG

  def create
    #Se não for devolução.
    if (params["qde_devolver"] == nil)
      @entrada_item = EntradaItem.new(entrada_item_params)
      material = Material.find_by(descricao: params["material"].split(" | ")[0]) if params["material"] != ""
      @entrada_item.material_id = material.id if material
      @entrada_item.quantidade = (@entrada_item.quantidade_fornecimento * @entrada_item.fator_multiplicador).round(4) if (@entrada_item.quantidade_fornecimento and @entrada_item.fator_multiplicador)
      @entrada_item.valor_unitario = (@entrada_item.valor_unitario_fornecimento/@entrada_item.fator_multiplicador).round(2) if (@entrada_item.valor_unitario_fornecimento and @entrada_item.fator_multiplicador)
     
      respond_to do |format|
        if @entrada_item.save
          unless @entrada_item.valida_max_material
            flash[:warning] = [t(:max_material_checked, material: @entrada_item.material.descricao)] 
            AlmoxarifadoMailer.send_mail_max_material_entrada(Cfue.where(funcao_descricao: 'Almoxarife'),  @entrada_item)
          end
          format.html { redirect_to edit_entrada_path(@entrada_item.entrada), notice: t(:successfully_save_m, objeto: "Item") }
          format.json { render action: 'edit', status: :created, location: @entrada_item.entrada }
        else    
          format.html { redirect_to edit_entrada_path(@entrada_item.entrada, error: @entrada_item.errors.messages) }
          format.json { render json: @entrada_item.errors, status: :unprocessable_entity }
        end
      end

    #Se for devolução.
    else
      validacao = ""
      lista_itens = Array.new
      @entrada_item = ""

      params["material_id"].each_with_index do |material, index|      
        @entrada_item = EntradaItem.new
        @entrada_item.entrada_id = params["entrada_id"]
        @entrada_item.material_id = material
        params["qde_devolver"][index].empty? ? (@entrada_item.quantidade = 0) : (@entrada_item.quantidade = params["qde_devolver"][index])
        params["qde_devolver"][index].empty? ? (@entrada_item.quantidade_fornecimento = 0) : (@entrada_item.quantidade_fornecimento = params["qde_devolver"][index])
        @entrada_item.valor_unitario = params["valor_medio"][index]
        @entrada_item.valor_unitario_fornecimento = params["valor_medio"][index]
        @entrada_item.fator_multiplicador = 1

        validacao = @entrada_item.valida_devolucao_item(params, index)
        if validacao[:valido]
          lista_itens << @entrada_item
        
        #Retorna com o erro de que a quantidade que está tentando devolver é maior que a quantidade requisitada.
        else
          respond_to do |format|
            format.html { redirect_to :back, alert: validacao[:erros] }
            format.json { render json: @entrada_item.errors, status: :unprocessable_entity }
          end
          return
        end
      end

      lista_itens.each_with_index do |item, index|
        requisicao_item = RequisicaoItem.find_by_id(params["requisicao_item_id"][index])
        #Se não for inserido nada no campo de devolver.
        if requisicao_item.qde_devolvida.nil?
          requisicao_item.update(qde_devolvida: 0)
        end
        item.save
      end
      
      requisicao_item = RequisicaoItem.find_by_id(params["requisicao_item_id"][0])
      @entrada_item.entrada.devolucao_update_valores(requisicao_item.requisicao.id)
    

      respond_to do |format|
        if validacao != nil and validacao[:valido]
          #quando terminar o metodo tenho que dar um redirect para o show!
          format.html { redirect_to edit_entrada_path(@entrada_item.entrada), notice: "Itens devolvidos com sucesso." }
          format.json { render action: "new" }
        else
          format.html { redirect_to :back, alert: validacao[:erro_msg] }
          format.json { render json: @entrada_item.errors, status: :unprocessable_entity }
        end
      end
    end
  end

  def update
    validacao = valida_entrada_item_ids(params["entrada_item_ids"])

    #Atualiza a requisição e o item_entrada.
    if validacao[:response]
      #lista_itens são as entrada_item da entrada editada.
      validacao[:lista_itens].each_with_index do |item, index|
        #raise params.inspect
        #raise item.inspect
        params["qde_devolver"][index].empty? ? item.update(quantidade: 0) : item.update(quantidade: params["qde_devolver"][index])
        requisicao_item = RequisicaoItem.find_by_id(params["requisicao_item_id"][index])
        if requisicao_item.qde_devolvida.nil?
          requisicao_item.update(qde_devolvida: 0)
        end
      end

      respond_to do |format|
        format.html { redirect_to  "/entradas" }
        format.json { head :no_content }
      end
    
    else
      respond_to do |format|
        format.html { redirect_to :back, alert: validacao[:erros] }
        format.json { render json: @entrada_item.errors, status: :unprocessable_entity }
      end
    end
  end

  def valida_entrada_item_ids(entrada_item_ids)
    lista_itens = Array.new

    entrada_item_ids.each_with_index do |id, index|
      @entrada_item = EntradaItem.find_by_id(id)
      #A função abaixo se encontra no model.
      validacao = @entrada_item.valida_devolucao_item(params, index)
      if validacao[:valido]
        lista_itens << @entrada_item
      else
        return {response: false, erros: validacao[:erros]}
      end
    end
    return {response: true, lista_itens: lista_itens}
  end

  def destroy
    @entrada_item.destroy
    respond_to do |format|
        format.html { redirect_to :back }
        format.json { head :no_content }
    end
  end

   private
    # Use callbacks to share common setup or constraints between actions.
    def set_entrada_item
      @entrada_item = EntradaItem.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def entrada_item_params
      params.require(:entrada_item).permit(:entrada_id, :material_id, :quantidade, :valor_unitario, :quantidade_fornecimento, :valor_unitario_fornecimento, :fator_multiplicador)
    end
end
