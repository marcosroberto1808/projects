class SaidaItensController < ApplicationController
  before_action :set_saida_item, only: [:show, :edit, :update, :destroy]

	#CONFIGURAÇÕES DO CANCAN
	load_and_authorize_resource	#Carregando Autorizações do cancan

	def saida_item_params	#workaround para o problema com strong parameter do cancan
		params.require(:saida_item).permit(:what, :ever)
	end
	#END CANCAN CONFIG

  def index
    @saida_itens = SaidaItem.page(params[:page]).order('created_at DESC')
    @saida_itens = SaidaItem.page(1).order('created_at DESC') if @saida_itens.any? == false
  end

  def new
    @saida_item = SaidaItem.new
  end

  def salvar_saida_item(saida_item)
    saida_item.save
  end

  def create
    flash[:warning] = []
    
    validade_lista = true
    lista_itens = Array.new

    params["materiais"].each_with_index do |saida, index|      
      @saida_item = SaidaItem.new
      @saida_item.saida_id = params["saida_id"]
      @saida_item.material_id = params["materiais"][index]
      @saida_item.quantidade = params["quantidades"][index]
      @saida_item.requisicao_item_id = params["requisicao_item_id"][index]
      @saida_item.requisicao_item.update(codigo_rastreamento: params["codigo_rastreamento"][index]) if (!params["codigo_rastreamento"][index].nil? and params["codigo_rastreamento"][index] != "")

      if @saida_item.valid?
        lista_itens << @saida_item
        unless @saida_item.valida_min_material
          flash[:warning] << t(:min_material_checked, material: @saida_item.material.descricao) 
        end
      else
        validade_lista = false
      end
    end

    if validade_lista
      lista_itens.each do |item|
        item.save
      end
    end

    respond_to do |format|
      if validade_lista != nil and validade_lista
        Saida.find(params["saida_id"]).update(observacao: params["saida_observacao"])
        format.html { redirect_to "/saidas" }
        format.json { render action: "new" }
      else
        format.html { redirect_to :back, alert: "Erro!" }
        format.json { render json: @saida_item.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    lista_salva = true
    flash[:warning] = []
    params["saida_item_ids"].each_with_index do |id, index|
      @saida_item = SaidaItem.where(id: id).first      
      lista_salva = false if !@saida_item.update_attributes(:quantidade => params["quantidades"][index])
      @saida_item.requisicao_item.update(codigo_rastreamento: params["codigo_rastreamento"][index]) if (!params["codigo_rastreamento"][index].nil?)
      
      if lista_salva
        unless @saida_item.valida_min_material
          flash[:warning] << t(:min_material_checked, material: @saida_item.material.descricao) 
        end
      end
    end
    
    respond_to do |format|
      if lista_salva
        Saida.find(params["saida_id"]).update(observacao: params["saida_observacao"])        
        format.html { redirect_to  "/saidas" }
        format.json { head :no_content }
      else
        format.html { redirect_to :back, alert: "Solicitação maior que a quantidade disponível no estoque." }
        format.json { render json: @saida_item.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @saida_item.destroy
    respond_to do |format|
      format.html { redirect_to :back }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_saida_item
      @saida_item = SaidaItem.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def saida_item_params
      params.fetch(:saida_item, {}).permit(:saida_id, :material_id, :quantidade)
      #params.fetch(:photo, {})
    end
end
