class RequisicoesController < ApplicationController
  before_action :set_requisicao, only: [:show, :edit, :update, :destroy]

	#CONFIGURAÇÕES DO CANCAN
	#Carregando Autorizações do cancan
	load_and_authorize_resource

	def requisicao_params
		params.require(:requisicao).permit(:what, :ever)
	end
	#END CANCAN CONFIG

  def index
    @setor = "Requisições"
    @requisicoes = Requisicao.where(solicitante_colaborador_codigo: current_colaborador.cfue.first.colaborador_codigo).paginate(:page => params[:page]).order('id DESC')
    @requisicoes = Requisicao.where(solicitante_colaborador_codigo: current_colaborador.cfue.first.colaborador_codigo).paginate(:page => 1).order('id DESC') if @requisicoes.any? == false
  end  

  def show
  end

  def new    
    @setor = "Requisições"
    @requisicao = Requisicao.new
    @requisicao.solicitante = current_colaborador.pessoa_fisica_nome
    @requisicao.solicitante_colaborador_codigo = current_colaborador.codigo
    @requisicao.area = current_colaborador.cfue.where(colaborador_codigo: current_colaborador.codigo, ativo: true).first.area_tipo_descricao 
    @requisicao.data_requisicao = Date.today

    respond_to do |format|
      if @requisicao.save
        format.html { redirect_to edit_requisicao_path(@requisicao) }
        format.json { render action: 'edit', status: :created, location: @requisicao }
      else
        format.html { render action: 'new' }
        format.json { render json: @requisicao.errors, status: :unprocessable_entity }
      end
    end
  end

  def edit 
    @setor = "Requisições"
    @requisicao_item = RequisicaoItem.new
    params[:error].each {|key, value| @requisicao_item.errors.add(key, value[0]) } if params[:error]
  end

	def update
    respond_to do |format|
      if @requisicao.update(requisicao_params)
        format.html { redirect_to @requisicao, notice: t(:successfully_save_f, objeto: "Requisição") }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @requisicao.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @requisicao.destroy
    respond_to do |format|
      format.html { redirect_to requisicoes_url }
      format.json { head :no_content }
    end
  end

  def change_status
    if @requisicao.requisicao_item.length == 0
      flash[:alert] = "A requisição não pode ser fechada sem items."
      redirect_to :back
    else
      @requisicao.fechado ? @requisicao.update(fechado: false, situacao_id: 1) : @requisicao.update(fechado: true, situacao_id: 2)
      redirect_to :back
    end 
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_requisicao
      @requisicao = Requisicao.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def requisicao_params
      params.require(:requisicao).permit(:solicitante, :area, :data_requisicao, :observacao, :situacao_id, :solicitante_colaborador_codigo, :fechado)
    end
end
