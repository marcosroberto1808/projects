class MateriaisController < ApplicationController
  before_action :set_material, only: [:show, :edit, :update, :destroy]

  #CONFIGURAÇÕES DO CANCAN
  load_and_authorize_resource #Carregando Autorizações do cancan
  # skip_authorize_resource :only => [:autocomplete_material_check, :show_material_info, :show_material_unidade_medida, :json_autocomplete_material, :json_autocomplete_material_requisicao]
  skip_before_filter :verify_authenticity_token

  def material_params #workaround para o problema com strong parameter do cancan
    params.require(:material).permit(:what, :ever)
  end
  #END CANCAN CONFIG

  def index
    @materiais = Material.page(params[:page]).order('descricao ASC')
    @materiais = Material.page(1).order('descricao ASC') if @materiais.any? == false
    @setor = "Materiais"
  end

  def show
  end

  def pesquisar
    @termo_descricao = params["descricao_material_pesquisa"]
    search = enhancement_ilike('descricao', @termo_descricao)
    @materiais = Material.page(params[:page]).where(search).order('descricao ASC')

    respond_to do |format|
      format.js
    end
  end

  def new
    @material = Material.new
  end

  def edit
  end

  def create
    @material = Material.new(material_params)
    respond_to do |format|
      if @material.save
        format.html { redirect_to @material, notice: t(:successfully_save_m, objeto: "Material") }
        format.json { render action: 'show', status: :created, location: @material }
      else
        format.html { render action: 'new' }
        format.json { render json: @material.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @material.update(material_params)
        format.html { redirect_to @material, notice: t(:successfully_updated_m, objeto: "Material") }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @material.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @material.destroy
    respond_to do |format|
      format.html { redirect_to materiais_url }
      format.json { head :no_content }
    end
  end

  def json_autocomplete_material
    search = enhancement_ilike('descricao', params["term"])
    @materiais = Material.where(search).pluck(:descricao)

    respond_to do |format|
      format.html { render json: @materiais }
    end
  end

  def json_autocomplete_material_requisicao
    @materiais = Array.new
    search = enhancement_ilike('descricao', params["term"])
    @material_descricao = Material.where(search)

    @material_descricao.each do |material|
      @materiais << material.descricao+" | "+material.unidade_medida_consumo.descricao
    end

    respond_to do |format|
      format.html { render json: @materiais }
    end
  end

  def autocomplete_material_check
    @material_descricao = Material.where(descricao: params[:material_descricao].split(" | ")[0]).pluck(:descricao)

    respond_to do |format|
      format.html { render json: @material_descricao.any? }
    end
  end

  def valor_medio_material_check
    @material_valor_medio = Material.where(descricao: params[:material_descricao].split(" | ")[0]).pluck(:valor_medio)

    respond_to do |format|
      format.html { render json: @material_valor_medio.any? }
    end
  end

  def show_material_info
    @material = Material.where(descricao: params[:material_descricao].split(" | ")[0])

    respond_to do |format|
      format.js
    end
  end

  def show_material_unidade_medida
    @material = Material.where(descricao: params[:material_descricao].split(" | ")[0]).first

    respond_to do |format|
      format.js
    end
  end

  def show_natureza_item_despesa
    @item_despesa = ItemDespesa.where(codigo: params[:item_despesa_codigo].to_i).first
    respond_to do |format|
      format.js
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_material
      @material = Material.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def material_params
      params.require(:material).permit(:unidade_medida_consumo_id, :unidade_medida_fornecimento_id, :descricao, :limite_maximo, :limite_minimo, :codigo, :localizacao, :detalhes, :item_despesa_id)
    end
end
