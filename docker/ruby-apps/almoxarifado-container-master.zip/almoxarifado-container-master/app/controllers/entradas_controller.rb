class EntradasController < ApplicationController
  before_action :set_entrada, only: [:show, :edit, :update, :destroy]

	#CONFIGURAÇÕES DO CANCAN
	load_and_authorize_resource	#Carregando Autorizações do cancan

	def entrada_params	#workaround para o problema com strong parameter do cancan
		params.require(:entrada).permit(:what, :ever)
	end
	#END CANCAN CONFIGURAÇÕES

  def index
    @setor = "Entradas"
    @entradas = Entrada.page(params[:page]).order('created_at DESC')
    @entradas = Entrada.page(1).order('created_at DESC') if @entradas.any? == false
  end

  def pesquisar_requisicao
    @setor = "Entradas"
    validacao = validar_devolucao(params)

    if (validacao[:response])
      @entrada = Entrada.find_by_id(params[:entrada_id].to_i)
      @requisicao = validacao[:requisicao]
      @saida = Saida.find_by_requisicao_id(@requisicao.id)
      @entrada_itens = EntradaItem.find_all_by_entrada_id(@entrada.id)
      @entrada_item = (@entrada.entrada_item.empty? ?  EntradaItem.new : @entrada.entrada_item.first )
      @erros = Array.new
      
      render :template => "entradas/devolucao_show_requisicao"

    else
      @requisicao = nil
      @entrada_item = EntradaItem.new
      @erros = validacao[:erros]
      #O js ainda tem que ser renderizado para mostrar que não foi encontrada a requisição com o id pesquisado.
      render :template => 'entradas/devolucao_show_requisicao'
    end

  end

  def validar_devolucao (params)
    erros = Array.new
    valido = true
    requisicao = Requisicao.find_by_id(params[:numero_requisicao].to_i)

    if (requisicao)
      situacao = requisicao.situacao_id

      case situacao
        when 1
          erros << "A requisição ainda está sendo cadastrada."
        when 2
          erros << "A requisição ainda está sendo solicitada."
        when 3
          erros << "A requisição ainda está sendo atendida."
      end

    else
      erros << "A requisicao pesquisada não existe."
    end

    valido = false if erros.any?
    response = {response: valido, erros: erros, requisicao: requisicao}
  end

  def show
    @setor = "Entradas"
    @entradas = Entrada.page(params[:page]).order('created_at DESC')
    @entradas = Entrada.page(1).order('created_at DESC') if @entradas.any? == false
  end

  def new
    @setor = "Entradas"
    @entrada = Entrada.new
    @anos = Array.new
    @anos << (Date.today.year).to_s
    @anos << (Date.today.year-1).to_s 
  end

  def edit
    @setor = "Entradas"
    @anos = Array.new
    @anos << (Date.today.year).to_s
    @anos << (Date.today.year-1).to_s  
    
    (@entrada.data_emissao = l @entrada.data_emissao) if @entrada.data_emissao
    (@entrada.data_entrada = l @entrada.data_entrada) if @entrada.data_entrada
    @entrada_item = EntradaItem.new
    params[:error].each {|key, value| @entrada_item.errors.add(key, value[0]) } if params[:error]
  end

  def create
    params[:entrada][:valor_nota_fiscal] = params[:entrada][:valor_nota_fiscal].gsub(".","").gsub(",",".")
    @setor = "Entradas"
    @entrada = Entrada.new(entrada_params)
    @entrada["fechado"] = false

    respond_to do |format|
      if @entrada.save
        format.html { redirect_to edit_entrada_path(@entrada), notice: t(:successfully_save_f, objeto: "Entrada") }
        format.json { render action: 'edit', status: :created, location: @entrada }
      else
        @anos = Array.new
        @anos << (Date.today.year).to_s
        @anos << (Date.today.year-1).to_s

        format.html { render action: 'new' }
        @entrada.errors.add(:base, "Error message")
        format.json { render json: @entrada.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    params[:entrada][:valor_nota_fiscal] = params[:entrada][:valor_nota_fiscal].gsub(".","").gsub(",",".")
    @setor = "Entradas"
    @anos = Array.new
    @anos << (Date.today.year).to_s
    @anos << (Date.today.year-1).to_s  

    respond_to do |format|
      if @entrada.update(entrada_params)
        format.html { redirect_to @entrada, notice: t(:successfully_updated_f, objeto: "Entrada") }
        format.json { head :no_content }
      else
        @entrada_item = EntradaItem.new
        format.html { render action: 'edit' }
        format.json { render json: @entrada.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @entrada.destroy
    respond_to do |format|
      format.html { redirect_to entradas_url}
      format.json { head :no_content }
    end
  end

  def change_status
    if @entrada.entrada_item.length == 0
      flash[:alert] = "A entrada não pode ser fechada sem items."
    else
      if @entrada.inventario_pendente? #Inventário Pendente
        flash[:alert] = "Existe um Ajuste de Estoque em aberto que inclui itens desta movimentação, sua ação não pode ser realizada."
      else        
        if @entrada.fechado
          @entrada.devolucaoUpdateQuantidadeDevolvida if (@entrada.tipo_entrada.descricao == "Devolução") #devolução
          @entrada.update(fechado: false)
          @entrada.entrada_item.each do |item|
            MovimentacaoMaterial.where(entrada_item_id: item.id).destroy_all
          end
        else

          if (@entrada.tipo_entrada.descricao == "Devolução") #devolução
            validacao = @entrada.devolucao_valida_quantidade
            #raise validacao.inspect
            if validacao[:response]
              @entrada.devolucaoUpdateQuantidadeDevolvidaAdd
              @entrada.update(fechado: true)
              @entrada.entrada_item.each do |item|
                MovimentacaoMaterial.create(entrada_item_id: item.id, valor_unitario: item.valor_unitario, quantidade: item.quantidade, valor_total: item.quantidade*item.valor_unitario, material_id: item.material_id, data_movimento: Date.today)
              end
            else 
              flash[:alert] = validacao[:erro] if validacao[:response] == false
            end

          elsif @entrada.tipo_entrada_id == 1 #nota fiscal
            if @entrada.confereNota
                ActiveRecord::Base.transaction do
                  if @entrada.update(fechado: true)
                    if @entrada.fechado
                        @entrada.entrada_item.each do |item|
                          MovimentacaoMaterial.create(entrada_item_id: item.id, valor_unitario: item.valor_unitario, quantidade: item.quantidade, valor_total: item.quantidade*item.valor_unitario, material_id: item.material_id, data_movimento: Date.today)
                        end
                    end
                  else
                    flash[:alert] = "Ocorreu um erro ao movimentar essa entrada procure o setor de Informática."
                  end
                end
            else 
              flash[:alert] = "Nota Fiscal não confere com o valor das somas dos itens."
            end

          else
            @entrada.update(fechado: true)
            @entrada.entrada_item.each do |item|
              MovimentacaoMaterial.create(entrada_item_id: item.id, valor_unitario: item.valor_unitario, quantidade: item.quantidade, valor_total: item.quantidade*item.valor_unitario, material_id: item.material_id, data_movimento: Date.today)
            end
          end

        end
      end
    end

    redirect_to action: :index
  end

  def nota_fiscal
    @entrada = Entrada.new
    @setor = "Entradas"

    @anos = Array.new
    @anos << (Date.today.year).to_s
    @anos << (Date.today.year-1).to_s  
        
    render layout: false
  end

  def devolucao
    @entrada = Entrada.new
    @setor = "Entradas"

    render layout: false
  end

  def doacao
    @setor = "Entradas"
    
    @entrada = Entrada.new
    render layout: false
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_entrada
      @entrada = Entrada.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def entrada_params
      params.require(:entrada).permit(:situacao_id, :tipo_entrada_id, :fornecedor_id, :nota_fiscal, :valor_nota_fiscal, :nota_empenho, :data_emissao, :data_entrada, :observacao, :ano_nota_empenho)
    end
end
