class TipoEntradasController < ApplicationController
  before_action :set_tipo_entrada, only: [:show, :edit, :update, :destroy]

	#CONFIGURAÇÕES DO CANCAN
	load_and_authorize_resource	#Carregando Autorizações do cancan

	def tipo_entrada_params	#workaround para o problema com strong parameter do cancan
		params.require(:tipo_entrada).permit(:what, :ever)
	end
	#END CANCAN CONFIG

  def index
    @tipo_entradas = TipoEntrada.page(params[:page]).order('created_at DESC')
    @tipo_entradas = TipoEntrada.page(1).order('created_at DESC') if @tipo_entradas.any? == false
  end

  def show
  end

  def new
    @tipo_entrada = TipoEntrada.new
  end

  def edit
  end

  def create
    @tipo_entrada = TipoEntrada.new(tipo_entrada_params)

    respond_to do |format|
      if @tipo_entrada.save
        format.html { redirect_to @tipo_entrada, notice: 'Tipo entrada was successfully created.' }
        format.json { render action: 'show', status: :created, location: @tipo_entrada }
      else
        format.html { render action: 'new' }
        format.json { render json: @tipo_entrada.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @tipo_entrada.update(tipo_entrada_params)
        format.html { redirect_to @tipo_entrada, notice: 'Tipo entrada was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @tipo_entrada.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @tipo_entrada.destroy
    respond_to do |format|
      format.html { redirect_to tipo_entradas_url }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_tipo_entrada
      @tipo_entrada = TipoEntrada.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def tipo_entrada_params
      params.require(:tipo_entrada).permit(:descricao)
    end
end
