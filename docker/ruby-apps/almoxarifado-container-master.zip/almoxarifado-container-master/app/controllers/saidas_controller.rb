class SaidasController < ApplicationController
  before_action :set_saida, only: [:show, :edit, :update, :destroy]

  #CONFIGURAÇÕES DO CANCAN
  load_and_authorize_resource #Carregando Autorizações do cancan

  def saida_params  #workaround para o problema com strong parameter do cancan
    params.require(:saida).permit(:what, :ever)
  end
  #END CANCAN CONFIG

  def index
    @setor = "Saídas"

    @saidas = Saida.all.paginate(:page => params[:page_saidas]).order('created_at DESC')
    @requisicoes = Requisicao.where(situacao_id: 2).paginate(:page => params[:page_requisicoes]).order('created_at ASC')
   
    @saidas = Saida.all.paginate(:page => 1).order('created_at DESC')if @saidas.any? == false
    @requisicoes = Requisicao.where(situacao_id: 2).paginate(:page => 1).order('created_at ASC')if @requisicoes.any? == false
  end

  def show
    @saida_itens = SaidaItem.where(saida_id: @saida.id).all
  end

  def new
    @setor = "Saídas"
    @saida = Saida.new
    @saida["requisicao_id"] = params["requisicao"]
    @saida["tipo_saida_id"] = params["tipo_saida"]
    @saida["data_saida"] = Date.today

    respond_to do |format|
      if @saida.save
        @saida.requisicao.update_attribute(:situacao_id, 3)
        format.html { redirect_to edit_saida_path(@saida, requisicao: params["requisicao"], tipo_saida: params["tipo_saida"]), notice: t(:successfully_save_f, objeto: "Saida")}
        format.json { render action: 'edit', status: :created, location: @saida }
      else
        format.html { redirect_to :back }
        format.json { render json: @saida.errors, status: :unprocessable_entity }
      end
    end
  end

  def edit    
    @setor = "Saídas"
    #Checa se já existe item_saida, para este gerenciar o action;
    @saida_item = (@saida.saida_item.empty? ?  SaidaItem.new : @saida.saida_item.first )
    ##====
    @saida_itens = SaidaItem.find_all_by_saida_id(@saida.id)
  end

  def update
    respond_to do |format|
      if @saida.update(saida_params)
        format.html { redirect_to @saida }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @saida.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @requisicao = Requisicao.find(@saida.requisicao_id)
    ActiveRecord::Base.transaction do
      @requisicao.update(situacao_id: 2)
      @requisicao.requisicao_item.each do |item|
        item.update(codigo_rastreamento: nil)
      end
      @saida_item = SaidaItem.where(saida_id: @saida.id).delete_all
      @saida.delete
    end
    respond_to do |format|
      format.html { redirect_to saidas_url }
      format.json { head :no_content }
    end
  end

  def change_status
    if @saida.inventario_pendente? #Inventário Pendente
      flash[:alert] = "Existe um Ajuste de Estoque em aberto que inclui itens desta movimentação, sua ação não pode ser realizada."
   
    #Executa se a saída estiver fechada.
    elsif @saida.devolucao_associada? and @saida.get_devolucoes_ids.length > 0
      #Recupera os ids das devoluções.
      ids = @saida.get_devolucoes_ids.map{|id| id}.join(", ")
      flash[:alert] = "A saída não pode ser aberta, pois existem as seguintes devoluções associadas a ela: IDs "+ids

    else
      if @saida.fechado
        @saida.update(fechado: false, situacao_id: 1)
        @saida.requisicao.update(situacao_id: 3)  
        @saida.saida_item.each do |item|
          @movimentacao = MovimentacaoMaterial.find_by_saida_item_id(item.id)
          @movimentacao.destroy
        end 
      else
        if @saida.saida_item.length > 0 #Saída sem Item                 
          @saida.update(fechado: true, situacao_id: 2)
          @saida.saida_item.each do |item|
            material = Material.find_by_id(item.material_id)
            MovimentacaoMaterial.create(saida_item_id: item.id, quantidade: -item.quantidade, material_id: item.material_id, valor_total: ((-item.quantidade)*material.valor_medio), valor_medio: material.valor_medio, data_movimento: Date.today)
          end
          total_saida = @saida.get_total_saida
          total_requisicao = @saida.requisicao.get_total_requisicao
          if total_requisicao > total_saida
            @saida.requisicao.update_attribute(:situacao_id, 4)
          else
            @saida.requisicao.update_attribute(:situacao_id, 5)      
          end
        else
          flash[:alert] = "A saida não pode ser processada pois as quantidades solicitadas estão incorretas, favor corrigir."
        end
      end
    end   

    redirect_to action: :index
  end  

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_saida
      @saida = Saida.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def saida_params
      params.require(:saida).permit(:situacao_id, :tipo_saida_id, :requisicao_id)
    end
end
