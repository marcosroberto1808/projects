class FornecedoresController < ApplicationController
  before_action :set_fornecedor, only: [:show, :edit, :update, :destroy]

	#CONFIGURAÇÕES DO CANCAN
	load_and_authorize_resource	#Carregando Autorizações do cancan

	def fornecedor_params	#workaround para o problema com strong parameter do cancan
		params.require(:fornecedor).permit(:what, :ever)
	end
	#END CANCAN CONFIG

  def index
    @fornecedores = Fornecedor.page(params[:page]).order(razao_social: :asc)
    @fornecedores = Fornecedor.page(1).order('created_at DESC') if @fornecedores.any? == false
    @setor = "Fornecedores"
  end

  def show
  end

  def pesquisar
    @total = Fornecedor.where("razao_social ilike ? or nome_fantasia ilike ? or cnpj ilike ?", "%"+params["Fornecedor"]+"%", "%"+params["Fornecedor"]+"%", "%"+params["Fornecedor"]+"%").size
    @fornecedores = Fornecedor.where("razao_social ilike ? or nome_fantasia ilike ? or cnpj ilike ?", "%"+params["Fornecedor"]+"%", "%"+params["Fornecedor"]+"%", "%"+params["Fornecedor"]+"%").page(params[:page]).order('created_at DESC')
    @fornecedores = Fornecedor.where("razao_social ilike ? or nome_fantasia ilike ? or cnpj ilike ?", "%"+params["Fornecedor"]+"%", "%"+params["Fornecedor"]+"%", "%"+params["Fornecedor"]+"%").page(1).order('created_at DESC') if @fornecedores.any? == false
  end

  def new
    @fornecedor = Fornecedor.new
  end

  def edit
  end

  def create
    @fornecedor = Fornecedor.new(fornecedor_params)

    respond_to do |format|
      if @fornecedor.save
        format.html { redirect_to @fornecedor, notice: t(:successfully_save_m, objeto: "Fornecedor") }
        format.json { render action: 'show', status: :created, location: @fornecedor }
      else
        format.html { render action: 'new' }
        format.json { render json: @fornecedor.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @fornecedor.update(fornecedor_params)
        format.html { redirect_to @fornecedor, notice: t(:successfully_updated_m, objeto: "Fornecedor") }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @fornecedor.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @fornecedor.destroy
    respond_to do |format|
      format.html { redirect_to fornecedores_url }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_fornecedor
      @fornecedor = Fornecedor.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def fornecedor_params
      params.require(:fornecedor).permit(:razao_social, :nome_fantasia, :contato, :cnpj, :endereco, :numero, :complemento, :cep, :estado, :cidade, :telefone1, :telefone2, :telefone3, :email)
    end
end
