class RequisicaoItensController < ApplicationController
  before_action :set_requisicao_item, only: [:show, :edit, :update, :destroy]

	#CONFIGURAÇÕES DO CANCAN
	#Carregando Autorizações do cancan
	load_and_authorize_resource

	def requisicao_item_params
		params.require(:requisicao_item).permit(:what, :ever)
	end
	#END CANCAN CONFIG

  def create
    @requisicao_item = RequisicaoItem.new(requisicao_item_params)
    material = Material.find_by(descricao: params["material"].split(" | ")[0]) if params["material"] != ""
    @requisicao_item.material_id = material.id if material

    respond_to do |format|
      if @requisicao_item.save
        format.html { redirect_to edit_requisicao_path(@requisicao_item.requisicao), notice: t(:successfully_save_m, objeto: "Item") }
        format.json { render action: 'edit', status: :created, location: @requisicao_item.requisicao }
      else    
        format.html { redirect_to edit_requisicao_path(@requisicao_item.requisicao, error: @requisicao_item.errors.messages) }
        format.json { render json: @requisicao_item.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @requisicao_item.destroy
    respond_to do |format|
		  format.html { redirect_to :back, notice: "Item excluído com sucesso." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_requisicao_item
      @requisicao_item = RequisicaoItem.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def requisicao_item_params
      params.require(:requisicao_item).permit(:requisicao_id, :material_id, :quantidade)
    end
end
