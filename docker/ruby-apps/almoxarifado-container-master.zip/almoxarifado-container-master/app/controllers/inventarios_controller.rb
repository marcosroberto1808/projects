class InventariosController < ApplicationController
  before_action :set_inventario, only: [:show, :edit, :update, :destroy]

  #CONFIGURAÇÕES DO CANCAN
  load_and_authorize_resource #Carregando Autorizações do cancan

  def inventario_params  #workaround para o problema com strong parameter do cancan
    params.require(:inventario).permit(:what, :ever)
  end
  #END CANCAN CONFIG

  def index
    @setor = "Controle de Estoque"
    @inventarios = Inventario.page(params[:page]).order('created_at DESC')    
    @inventarios = Inventario.page(1).order('created_at DESC') if @inventarios.any? == false
  end

  def show
  end

  def new
    @setor = "Controle de Estoque"
    @inventario = Inventario.new
    @inventario.data_inventario = Date.today
    @inventario.observacao = 'Sua observação.'
    
    respond_to do |format|
      if @inventario.save
        format.html { redirect_to edit_inventario_path(@inventario) }
        format.json { render action: 'edit', status: :created, location: @inventario }
      else
        format.html { render action: 'new' }
        format.json { render json: @inventario.errors, status: :unprocessable_entity }
      end
    end
  end

  def edit
    @setor = "Controle de Estoque"
    @inventario.data_inventario = l @inventario.data_inventario
    @inventario_item = InventarioItem.new
    params[:error].each {|key, value| @inventario_item.errors.add(key, value[0]) } if params[:error]
  end

  def update
    respond_to do |format|
      if @inventario.update(inventario_params)
        format.html { redirect_to @inventario, notice: t(:successfully_updated_m, objeto: "Inventário") }
        format.json { head :no_content }
      else
        @inventario_item = InventarioItem.new
        format.html { render action: 'edit' }
        format.json { render json: @inventario.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy

    @inventario.destroy
    respond_to do |format|
      format.html { redirect_to inventarios_url }
      format.json { head :no_content }
    end
  end

  def change_status
    if @inventario.inventario_item.length == 0
      flash[:alert] = "O Ajuste de Estoque não pode ser fechado sem items."
    else  
      if @inventario.fechado
	      flash[:alert] = "Ajustes de Estoque fechados não podem ser reabertos."
      else
        @inventario.update(fechado: true, data_inventario: Date.today)
        @inventario.inventario_item.each do |item|
        quantidade_ajuste = 0
        diferenca = item.quantidade - item.material.get_saldo
        @material = Material.find_by_id(item.material_id)
          if @material.valor_medio == '' or @material.valor_medio == nil
            material = Material.find_by_id(item.material_id)
            material.update_attribute(:valor_medio, item.valor_medio)
            MovimentacaoMaterial.create(inventario_item_id: item.id, valor_unitario: item.valor_medio, quantidade: diferenca , valor_total: (item.quantidade * item.valor_medio) , material_id: item.material_id, valor_medio: item.valor_medio, data_movimento: Date.today)
          else
            MovimentacaoMaterial.create(inventario_item_id: item.id, valor_unitario: @material.valor_medio, quantidade: diferenca , valor_total: (item.quantidade * @material.valor_medio) , material_id: item.material_id, valor_medio: @material.valor_medio, data_movimento: Date.today)
          end
        end
      end
    end
      
    redirect_to action: :index
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_inventario
      @inventario = Inventario.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def inventario_params
      params.require(:inventario).permit(:data_inventario, :observacao)
    end
end
