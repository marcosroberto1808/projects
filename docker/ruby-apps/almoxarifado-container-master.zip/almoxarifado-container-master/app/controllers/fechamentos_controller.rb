class FechamentosController < ApplicationController
  before_action :set_fechamento, only: [:show, :edit, :update, :destroy]

  #CONFIGURAÇÕES DO CANCAN
  load_and_authorize_resource #Carregando Autorizações do cancan

  def saida_params  #workaround para o problema com strong parameter do cancan
    params.require(:saida).permit(:what, :ever)
  end
  #END CANCAN CONFIG

  def index
    @setor = "Fechamento"
    @fechamento = Fechamento.new
    @fechamentos_salvos = Fechamento.find_all_by_processado(false)
    @fechamentos_processados = Fechamento.find_all_by_processado(true)
    @fechamentos_abertos = Array.new  
    @data_fechamento_inicial = MovimentacaoMaterial.first
    if @data_fechamento_inicial != nil
      year_inicial = @data_fechamento_inicial.created_at.year
      month_inicial = @data_fechamento_inicial.created_at.month
      for year in year_inicial..Date.today.year    
        for month in month_inicial..12
          if (Date.today > Date.civil(year,month,-1)) and !Fechamento.find_by_data_fechamento(Date.civil(year,month,-1))
            @fechamentos_abertos << [t("date.month_names")[month]+"-"+year.to_s, Date.civil(year,month,-1)]
          end  
        end
      end
    end  
  end

  def show
    @setor = "Fechamento"
    year = @fechamento.data_fechamento.year    
    month = @fechamento.data_fechamento.month

    respond_to do |format|
      if @fechamento.checa_fechamento
        @fechamento.update_attribute(:processado, true)  
        format.html { redirect_to :back, notice: 'Fechamento Processado com Sucesso' }
        format.json { head :no_content }
      else
        @entradas = Entrada.where(data_entrada: Date.civil(year,month,1)..Date.civil(year,month,-1), fechado: false)
        @requisicoes = Requisicao.where(data_requisicao: Date.civil(year,month,1)..Date.civil(year,month,-1), fechado: false)
        @saidas = Saida.where(data_saida: Date.civil(year,month,1)..Date.civil(year,month,-1), fechado: false)
        @inventarios = Inventario.where(data_inventario: Date.civil(year,month,1)..Date.civil(year,month,-1), fechado: false)

        format.html { render action: 'show' }
        @fechamento.errors.add :base, "Existem pendências para este periodo ou periodos anteriores estão em aberto, favor realizar as devidas correções(fechamentos/cancelamentos)."
        format.json { render json: @fechamento.errors, status: :unprocessable_entity }
      end
    end
  end

  def new
    @setor = "Fechamento"
    @fechamento = Fechamento.new
  end

  def edit
    @setor = "Fechamento"
  end

  def create
    @fechamento = Fechamento.new(fechamento_params)
    @fechamento["data_fechamento"] = params["fechamento_aberto"].to_time
    @fechamento["data_fechamento"] = @fechamento["data_fechamento"].change(:hour => 23, :min => 59, :sec => 59)

    respond_to do |format|
      if @fechamento.save
        format.html { redirect_to @fechamento }
        format.json { render action: 'show', status: :created, location: @fechamento }
      else
        format.html { render action: 'new' }
        format.json { render json: @fechamento.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @fechamento.update(fechamento_params)
        format.html { redirect_to @fechamento, notice: 'Fechamento was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @fechamento.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @fechamento.destroy
    respond_to do |format|
      format.html { redirect_to fechamentos_url }
      format.json { head :no_content }
    end
  end

  def processar
    respond_to do |format|
      if @fechamento.checa_fechamento
        @fechamento.update_attribute(:processado, true)  
        format.html { redirect_to @fechamento, notice: 'Fechamento Processado com Sucesso' }
        format.json { head :no_content }
      else
        format.html { render action: 'show' }
        @fechamento.errors.add :base, "Existem pendências para este periodo, favor realizar as devidas correções(fechamentos/cancelamentos)."
        format.json { render json: @fechamento.errors, status: :unprocessable_entity }
      end
    end
   end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_fechamento
      @fechamento = Fechamento.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def fechamento_params
      params.require(:fechamento).permit(:data_fechamento, :observacao, :descricao, :processado)
    end
end
