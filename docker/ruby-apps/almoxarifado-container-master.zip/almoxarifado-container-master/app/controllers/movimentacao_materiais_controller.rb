class MovimentacaoMateriaisController < ApplicationController
  before_action :set_movimentacao_material, only: [:show, :edit, :update, :destroy]

  # GET /movimentacao_materiais
  # GET /movimentacao_materiais.json
  def index
    @movimentacao_materiais = MovimentacaoMaterial.all
  end

  # GET /movimentacao_materiais/1
  # GET /movimentacao_materiais/1.json
  def show
  end

  # GET /movimentacao_materiais/new
  def new
    @movimentacao_material = MovimentacaoMaterial.new
  end

  # GET /movimentacao_materiais/1/edit
  def edit
  end

  # POST /movimentacao_materiais
  # POST /movimentacao_materiais.json
  def create
    MovimentacaoMaterial.new(movimentacao_material_params)
    respond_to do |format|
      if @movimentacao_material.save
        format.html { redirect_to @movimentacao_material }
        format.json { render action: 'show', status: :created, location: @movimentacao_material }
      else
        format.html { render action: 'new' }
        format.json { render json: @movimentacao_material.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /movimentacao_materiais/1
  # PATCH/PUT /movimentacao_materiais/1.json
  def update
    respond_to do |format|
      if @movimentacao_material.update(movimentacao_material_params)
        format.html { redirect_to @movimentacao_material, notice: 'Movimentacao material was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @movimentacao_material.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /movimentacao_materiais/1
  # DELETE /movimentacao_materiais/1.json
  def destroy
    @movimentacao_material.destroy
    respond_to do |format|
      format.html { redirect_to movimentacao_materiais_url }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_movimentacao_material
      @movimentacao_material = MovimentacaoMaterial.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def movimentacao_material_params
      params.require(:movimentacao_material).permit(:inventario_item, :saida_item, :entrada_item, :valor_unitario, :quantidade, :valor_total)
    end
end
