module LocaisHelper

	def selectEstados (objeto)
		#@fornecedor = Fornecedor.new
    estadoCidades = JSON.parse( IO.read(Dir.getwd+"/app/helpers/estados_cidades.json") )
    #raise estadoCidades.inspect
		#estados = ["AC", "AL" ,"AP" ,"AM" ,"BA" ,"CE" ,"DF" ,"ES" ,"GO" ,"MA" ,"MT" ,"MS" ,"MG" ,"PA" ,"PB" ,"PR" ,"PE" ,"PI" ,"RJ" ,"RN" ,"RS" ,"RO" ,"RR" ,"SC" ,"SP" ,"SE" ,"TO"]
		#select(objeto, "estado",estados.map {|p| [ p, p ] }, { include_blank: "Selecione seu estado" })
		#raise estadoCidades.keys.map{|p| [ p, p ] }.inspect
		select(objeto, "estado",estadoCidades.keys.map{|p| [ p, p ] }, { include_blank: "Selecione seu estado",  :onchange => 'cidades()'})
	end

	def selectCidades (objeto, estadoId)
		#@fornecedor = Fornecedor.new
    estadoCidades = JSON.parse( IO.read(Dir.getwd+"/app/helpers/estados_cidades.json") )
    cidades = estadoCidades[estadoId]
    cidades = cidades["cidades"]

		#estados = ["AC", "AL" ,"AP" ,"AM" ,"BA" ,"CE" ,"DF" ,"ES" ,"GO" ,"MA" ,"MT" ,"MS" ,"MG" ,"PA" ,"PB" ,"PR" ,"PE" ,"PI" ,"RJ" ,"RN" ,"RS" ,"RO" ,"RR" ,"SC" ,"SP" ,"SE" ,"TO"]
		#select(objeto, "estado",estados.map {|p| [ p, p ] }, { include_blank: "Selecione seu estado" })
		select(objeto, "cidade",cidades.map {|p| [ p, p ] }, { include_blank: "Selecione sua cidade" })
	end

	def states
   	http = Net::HTTP.new('raw.github.com', 443); http.use_ssl = true
  	qualquer = JSON.parse http.get('/celsodantas/br_populate/master/states.json').body
  	raise qualquer.inspect
  end

  def capital?(city, state)
    city["name"] == state["capital"]
  end

	def populate
		states.each do |state|
			state_obj = State.new(:acronym => state["acronym"], :name => state["name"])
			state_obj.save
      
    	state["cities"].each do |city|
     		c = City.new
     		c.name = city
     		c.state = state_obj
     		c.capital = capital?(city, state)
      	c.save
      end
		end
	end

end
