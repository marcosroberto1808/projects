module RequisicoesHelper
	def link_to_actions_requisicao requisicao
		case requisicao.situacao_id
			when 1..2
			  if requisicao.fechado		
					render partial: "requisicoes/link_acoes_fechado", locals: {requisicao: requisicao}
				else
					render partial: "requisicoes/link_acoes_aberto", locals: {requisicao: requisicao}
				end
			when 3
			  render partial: "requisicoes/link_acoes_fechado_atendimento", locals: {requisicao: requisicao}
			else			 	
		 		render partial: "requisicoes/link_acoes_atendida", locals: {requisicao: requisicao}	 	
			end
	end
end
