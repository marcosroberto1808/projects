module RelatoriosHelper
	def check_movimentacao_entrada_saida(movimentacao)
		if !movimentacao.entrada_item_id.nil?
			render partial: "relatorios/movimentacao_entrada", locals: {movimentacao: movimentacao}
		elsif !movimentacao.saida_item_id.nil?
			render partial: "relatorios/movimentacao_saida", locals: {movimentacao: movimentacao}
		elsif !movimentacao.inventario_item_id.nil?
			render partial: "relatorios/movimentacao_inventario", locals: {movimentacao: movimentacao}
		end
	end

	def get_movimentacoes_relatorio_saida(setores, material, data_inicio, data_fim)
		@total_geral_quantidade = 0
		@total_geral_total = 0
		h_movimentacoes = {}

		setores.each do |setor|
			arr_movimentacoes = []
			movimentacoes = Relatorio.get_movimentacoes_por_setor(setor, material, data_inicio, data_fim)
			unless movimentacoes.length <= 0
				if movimentacoes != nil
					movimentacoes.sum("quantidade")
					@total_geral_quantidade = @total_geral_quantidade + movimentacoes.sum("quantidade")
					number_to_currency(movimentacoes.sum("valor_unitario * quantidade"))
					@total_geral_total = @total_geral_total + movimentacoes.sum("valor_unitario * quantidade")
					setor

					movimentacoes = movimentacoes.sort{|mov, mov2| mov2[:created_at] <=> mov[:created_at]}
					movimentacoes.each do |movimentacao|
						h_movimentacao = {}
						h_movimentacao[:setor] =  setor
						h_movimentacao[:material] =  movimentacao.saida_item.material.descricao
						h_movimentacao[:data_saida] = movimentacao.saida_item.saida.data_saida
						h_movimentacao[:quantidade] = movimentacao.quantidade
						h_movimentacao[:valor_unitario] = movimentacao.valor_unitario
						h_movimentacao[:total] = (movimentacao.valor_unitario*movimentacao.quantidade)
						h_movimentacao[:tipo_saida] = movimentacao.saida_item.saida.tipo_saida.descricao
						h_movimentacao[:numero_pedido] = movimentacao.saida_item.saida.requisicao.id
						h_movimentacao[:solicitante] = movimentacao.saida_item.saida.requisicao.solicitante
						arr_movimentacoes << h_movimentacao
					end
					h_movimentacoes[setor] = arr_movimentacoes if arr_movimentacoes
				end
			end
		end
		h_movimentacoes
	end

end
