module EntradasHelper
	def link_to_actions_entrada entrada
	  data_ultimo_fechamento = Fechamento.where(processado: true).last
	  if data_ultimo_fechamento != nil and data_ultimo_fechamento.data_fechamento > entrada.data_entrada
			render partial: "saidas/link_acoes_bloqueado", locals: {entrada: entrada}
		else	 		
		  if entrada.fechado		
				render partial: "entradas/link_acoes_fechado", locals: {entrada: entrada}
			else
				render partial: "entradas/link_acoes_aberto", locals: {entrada: entrada}
			end
		end	
	end
	
end
