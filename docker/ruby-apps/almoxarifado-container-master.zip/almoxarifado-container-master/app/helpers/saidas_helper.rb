module SaidasHelper
	def link_to_actions_saida saida
	  data_ultimo_fechamento = Fechamento.where(processado: true).last
	  if data_ultimo_fechamento != nil and data_ultimo_fechamento.data_fechamento > saida.data_saida
			render partial: "saidas/link_acoes_bloqueado", locals: {saida: saida}
		else	 	
		  if saida.fechado		
				render partial: "saidas/link_acoes_fechado", locals: {saida: saida}
			else
				render partial: "saidas/link_acoes_aberto", locals: {saida: saida}
			end
		end	
	end
end
