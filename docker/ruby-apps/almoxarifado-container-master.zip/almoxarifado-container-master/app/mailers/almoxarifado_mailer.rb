class AlmoxarifadoMailer < ActionMailer::Base
  default from: "sistemas@defensoria.ce.def.br"
  layout "email"

=begin
  def send_mail_max_material_entrada(almoxarifes, entrada_item)
  	@item =  entrada_item

  	almoxarifes.where(funcao_descricao: 'Almoxarife').each do |cfue|
      @cfue = cfue
      mail(to: @cfue.colaborador.email, subject: 'Alerta Almoxarifado').deliver unless @cfue.colaborador.email.empty?
    end
  end
=end  

  def send_mail_max_material_entrada(almoxarifes, entrada_item)
    @item = entrada_item
    @emails = Array.new

    #pega lista de todos os usuários que são almoxarifes e devem ser notificados
    @almoxarifes = almoxarifes.where(funcao_descricao: 'Almoxarife', ativo: true)

    #pega lista de emails dos almoxarifes que tem email cadastrado
    @almoxarifes.each do |almo|
      @emails << almo.colaborador.email unless almo.colaborador.email.empty?
    end  

    #remove duplicadas de email  
    @emails = @emails.uniq

    #realiza o envio para lista de emails
    @emails.each do |email|
      @cfue = Colaborador.where(email: email, ativo: true).first.cfue.where(ativo: true).first
      mail(to: email, subject: 'Alerta Almoxarifado').deliver
    end
  end

  def send_mail_min_material_saida(almoxarifes, saida_item)
    @item = saida_item
    @emails = Array.new

    #pega lista de todos os usuários que são almoxarifes e devem ser notificados
    @almoxarifes = almoxarifes.where(funcao_descricao: 'Almoxarife', ativo: true)

    #pega lista de emails dos almoxarifes que tem email cadastrado
    @almoxarifes.each do |almo|
      @emails << almo.colaborador.email unless almo.colaborador.email.empty?
    end  

    #remove duplicadas de email  
    @emails = @emails.uniq

    #realiza o envio para lista de emails
    @emails.each do |email|
      @cfue = Colaborador.where(email: email, ativo: true).first.cfue.where(ativo: true).first
      Logger.new(STDOUT).warn "********#{email}"
      mail(to: email, subject: 'Alerta Almoxarifado').deliver
    end
  end
end
