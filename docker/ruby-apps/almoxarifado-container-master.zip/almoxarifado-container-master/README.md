# Almoxarifado

### Reiniciando a aplicação utilizando passenger:
```
$ cd <caminho-para-o-repositório-da-aplicação>
$ touch tmp/restart.txt
``` 

> Vá ao navegador e acesse a aplicação e o passenger vai reiniciar a aplicação

```
$ rm tmp/restart.txt
``` 
