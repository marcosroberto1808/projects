# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20140401125532) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "entrada_itens", force: true do |t|
    t.integer  "entrada_id",                                           null: false
    t.integer  "material_id",                                          null: false
    t.integer  "quantidade"
    t.decimal  "valor_unitario",              precision: 16, scale: 2
    t.decimal  "quantidade_fornecimento",     precision: 16, scale: 4
    t.decimal  "valor_unitario_fornecimento", precision: 16, scale: 2
    t.datetime "created_at"
    t.datetime "updated_at"
    t.decimal  "fator_multiplicador",         precision: 16, scale: 4
  end

  add_index "entrada_itens", ["entrada_id"], name: "index_entrada_itens_on_entrada_id", using: :btree
  add_index "entrada_itens", ["material_id"], name: "index_entrada_itens_on_material_id", using: :btree

  create_table "entradas", force: true do |t|
    t.integer  "tipo_entrada_id",                                                        null: false
    t.integer  "fornecedor_id"
    t.integer  "nota_fiscal"
    t.decimal  "valor_nota_fiscal",             precision: 16, scale: 2
    t.integer  "nota_empenho"
    t.date     "data_emissao"
    t.date     "data_entrada"
    t.text     "observacao"
    t.string   "ordem_de_compra",   limit: 250
    t.string   "string",            limit: 250
    t.string   "ata",               limit: 250
    t.boolean  "fechado",                                                default: false, null: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "ano_nota_empenho"
    t.integer  "requisicao_id"
  end

  add_index "entradas", ["fornecedor_id"], name: "index_entradas_on_fornecedor_id", using: :btree
  add_index "entradas", ["tipo_entrada_id"], name: "index_entradas_on_tipo_entrada_id", using: :btree

  create_table "fechamentos", force: true do |t|
    t.date     "data_fechamento"
    t.text     "observacao"
    t.string   "descricao"
    t.boolean  "processado",      default: false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "fornecedores", force: true do |t|
    t.string   "razao_social",  limit: 100, null: false
    t.string   "nome_fantasia", limit: 100, null: false
    t.string   "cnpj",          limit: 20,  null: false
    t.string   "endereco",      limit: 100, null: false
    t.string   "numero",        limit: 10,  null: false
    t.string   "complemento",   limit: 250
    t.string   "cep",           limit: 10,  null: false
    t.string   "estado",        limit: 2,   null: false
    t.string   "cidade",        limit: 50,  null: false
    t.string   "telefone1",     limit: 20
    t.string   "telefone2",     limit: 20
    t.string   "telefone3",     limit: 20
    t.string   "email",         limit: 50
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "contato"
  end

  create_table "inventario_itens", force: true do |t|
    t.integer  "inventario_id"
    t.integer  "material_id"
    t.decimal  "quantidade"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.decimal  "valor_medio",   precision: 16, scale: 2
  end

  add_index "inventario_itens", ["inventario_id"], name: "index_inventario_itens_on_inventario_id", using: :btree
  add_index "inventario_itens", ["material_id"], name: "index_inventario_itens_on_material_id", using: :btree

  create_table "inventarios", force: true do |t|
    t.date     "data_inventario"
    t.text     "observacao"
    t.boolean  "fechado",         default: false, null: false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "item_despesas", force: true do |t|
    t.integer  "codigo",              limit: 8, null: false
    t.string   "descricao"
    t.integer  "natureza_despesa_id",           null: false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "item_despesas", ["natureza_despesa_id"], name: "index_item_despesas_on_natureza_despesa_id", using: :btree

  create_table "materiais", force: true do |t|
    t.integer  "unidade_medida_consumo_id",                                           null: false
    t.integer  "unidade_medida_fornecimento_id",                                      null: false
    t.string   "descricao",                      limit: 250,                          null: false
    t.string   "codigo",                         limit: 20
    t.decimal  "limite_maximo",                              precision: 16, scale: 4
    t.decimal  "limite_minimo",                              precision: 16, scale: 4
    t.string   "localizacao",                    limit: 250
    t.decimal  "valor_medio",                                precision: 16, scale: 2
    t.datetime "created_at"
    t.datetime "updated_at"
    t.text     "detalhes"
    t.integer  "item_despesa_id"
  end

  add_index "materiais", ["unidade_medida_consumo_id"], name: "index_materiais_on_unidade_medida_consumo_id", using: :btree
  add_index "materiais", ["unidade_medida_fornecimento_id"], name: "index_materiais_on_unidade_medida_fornecimento_id", using: :btree

  create_table "movimentacao_materiais", force: true do |t|
    t.integer  "inventario_item_id"
    t.integer  "saida_item_id"
    t.integer  "entrada_item_id"
    t.integer  "material_id"
    t.decimal  "valor_unitario"
    t.decimal  "quantidade"
    t.decimal  "valor_total"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.decimal  "valor_medio",        precision: 16, scale: 2
    t.date     "data_movimento"
  end

  create_table "natureza_despesas", force: true do |t|
    t.string   "descricao"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "requisicao_itens", force: true do |t|
    t.decimal  "quantidade",          precision: 16, scale: 4, null: false
    t.integer  "requisicao_id",                                null: false
    t.integer  "material_id",                                  null: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.decimal  "qde_devolvida",       precision: 16, scale: 4
    t.string   "codigo_rastreamento"
  end

  add_index "requisicao_itens", ["material_id"], name: "index_requisicao_itens_on_material_id", using: :btree
  add_index "requisicao_itens", ["requisicao_id"], name: "index_requisicao_itens_on_requisicao_id", using: :btree

  create_table "requisicoes", force: true do |t|
    t.integer  "situacao_id",                                default: 1,     null: false
    t.string   "solicitante"
    t.string   "area"
    t.date     "data_requisicao"
    t.string   "observacao",                     limit: 500
    t.boolean  "fechado",                                    default: false, null: false
    t.string   "solicitante_colaborador_codigo", limit: 15,  default: "",    null: false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "requisicoes", ["situacao_id"], name: "index_requisicoes_on_situacao_id", using: :btree

  create_table "saida_itens", force: true do |t|
    t.integer  "saida_id",                                    null: false
    t.integer  "requisicao_item_id",                          null: false
    t.integer  "material_id",                                 null: false
    t.decimal  "quantidade",         precision: 16, scale: 4, null: false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "saida_itens", ["material_id"], name: "index_saida_itens_on_material_id", using: :btree
  add_index "saida_itens", ["requisicao_item_id"], name: "index_saida_itens_on_requisicao_item_id", using: :btree
  add_index "saida_itens", ["saida_id"], name: "index_saida_itens_on_saida_id", using: :btree

  create_table "saidas", force: true do |t|
    t.integer  "situacao_id",   default: 1,     null: false
    t.integer  "tipo_saida_id",                 null: false
    t.integer  "requisicao_id",                 null: false
    t.date     "data_saida"
    t.boolean  "fechado",       default: false, null: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "observacao"
  end

  add_index "saidas", ["requisicao_id"], name: "index_saidas_on_requisicao_id", using: :btree
  add_index "saidas", ["situacao_id"], name: "index_saidas_on_situacao_id", using: :btree
  add_index "saidas", ["tipo_saida_id"], name: "index_saidas_on_tipo_saida_id", using: :btree

  create_table "situacoes", force: true do |t|
    t.string   "descricao",  limit: 50, null: false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tipo_entradas", force: true do |t|
    t.string   "descricao",  limit: 50
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tipo_saidas", force: true do |t|
    t.string   "descricao",  limit: 50
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "unidade_medidas", force: true do |t|
    t.string   "descricao",  null: false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

end
