# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

Situacao.create([
								{id: 1, descricao: 'Cadastrando'}, 
								{id: 2, descricao: 'Solicitada'}, 
								{id: 3, descricao: 'Em Atendimento'}, 
								{id: 4, descricao: 'Atendido Parcialmente'}, 
								{id: 5, descricao: 'Atendido Totalmente'}
								])

TipoSaida.create([
								{id: 1, descricao: 'Requisição'},
								{id: 2, descricao: 'Doação'}
								])

TipoEntrada.create([
								{id: 1, descricao: 'Nota Fiscal'}, 
								{id: 2, descricao: 'Doação'}, 
								{id: 3, descricao: 'Devolução'}
								])

NaturezaDespesa.create([
								{id: 1, descricao: 'Material de Consumo'}, 
								{id: 2, descricao: 'Material de Distribuição Gratuita'}
								])

ItemDespesa.create([
								{codigo: 33903000004, descricao: 'Gás e Outros Materiais Engarrafados', natureza_despesa_id: 1}, 
								{codigo: 33903000007, descricao: 'Gêneros de Alimentação', natureza_despesa_id: 1}, 
								{codigo: 33903000009, descricao: 'Material de Expediente', natureza_despesa_id: 1}, 
								{codigo: 33903000018, descricao: 'Material Educativo e ou Esportivo', natureza_despesa_id: 1}, 
								{codigo: 33903000019, descricao: 'Material para Festividades e Homenagens', natureza_despesa_id: 1}, 
								{codigo: 33903000020, descricao: 'Material de Processamento de Dados', natureza_despesa_id: 1}, 
								{codigo: 33903000022, descricao: 'Material de acondicionamento e Embalagem', natureza_despesa_id: 1}, 
								{codigo: 33903000023, descricao: 'Material de Cama. Mesa e Banho', natureza_despesa_id: 1}, 
								{codigo: 33903000024, descricao: 'Material de Copa e Cozinha', natureza_despesa_id: 1}, 
								{codigo: 33903000025, descricao: 'Material de Limpeza e Produção de Higienização', natureza_despesa_id: 1}, 
								{codigo: 33903000026, descricao: 'Uniformes, Tecidos e Aviamentos', natureza_despesa_id: 1}, 
								{codigo: 33903000027, descricao: 'Material para Manutenção de Bens Imóveis/Instalações', natureza_despesa_id: 1}, 
								{codigo: 33903000028, descricao: 'Material para Manutenção de Bens Móveis', natureza_despesa_id: 1}, 
								{codigo: 33903000029, descricao: 'Material Elétrico e Eletrônico', natureza_despesa_id: 1}, 
								{codigo: 33903000031, descricao: 'Material de Proteção e Segurança', natureza_despesa_id: 1}, 
								{codigo: 33903000032, descricao: 'Material para Áudio, Video e Foto', natureza_despesa_id: 1}, 
								{codigo: 33903000040, descricao: 'Material para Manutenção de Veículos', natureza_despesa_id: 1}, 
								{codigo: 33903000041, descricao: 'Material para Utilização em Gráfica', natureza_despesa_id: 1}, 
								{codigo: 33903000042, descricao: 'Ferramentas e Utensílios', natureza_despesa_id: 1}, 
								{codigo: 33903000044, descricao: 'Material de Sinalização Visual e Afins', natureza_despesa_id: 1}, 
								{codigo: 33903000045, descricao: 'Material Técnico para Seleção e Treinamento', natureza_despesa_id: 1}, 
								{codigo: 33903000046, descricao: 'Material Bibliográfico', natureza_despesa_id: 1}, 
								{codigo: 33903000050, descricao: 'Bandeiras, Flâmulas e Insígnias', natureza_despesa_id: 1}, 
								{codigo: 33903000055, descricao: 'Material para Instalação Hidráulica', natureza_despesa_id: 1}, 
								{codigo: 33903000099, descricao: 'Outros Materiais de Consumo', natureza_despesa_id: 1}, 
								{codigo: 33903200001, descricao: 'Gêneros de Alimentação', natureza_despesa_id: 2}, 
								{codigo: 33903200005, descricao: 'Material Educativo', natureza_despesa_id: 2}, 
								{codigo: 33903200010, descricao: 'Material de Divulgação', natureza_despesa_id: 2}, 
								{codigo: 33903200012, descricao: 'Material para Cerimonial', natureza_despesa_id: 2}, 
								{codigo: 33903200099, descricao: 'Outros Materiais e Serviços para Distribuição Gratuita', natureza_despesa_id: 2}, 
								])