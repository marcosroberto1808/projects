class CreateRequisicaoItens < ActiveRecord::Migration
  def change
    create_table :requisicao_itens do |t|
      t.decimal :quantidade, precision: 16, scale: 4, null: false
      t.references :requisicao, index: true, null: false
      t.references :material, index: true, null: false

      t.timestamps
    end


    reversible do |dir|
      dir.up do
        #add a foreign key
        execute "ALTER TABLE requisicao_itens
            ADD CONSTRAINT fk_requisicao_item_requisicao
            FOREIGN KEY (requisicao_id)
            REFERENCES requisicoes(id)"

        execute "ALTER TABLE requisicao_itens
            ADD CONSTRAINT fk_requisicao_item_material
            FOREIGN KEY (material_id)
            REFERENCES materiais(id)"
      end

      dir.down do
        execute "ALTER TABLE requisicao_itens
            DROP CONSTRAINT fk_requisicao_item_requisicao"

        execute "ALTER TABLE requisicao_itens
            DROP CONSTRAINT fk_requisicao_item_material"
      end
    end

  end
end
