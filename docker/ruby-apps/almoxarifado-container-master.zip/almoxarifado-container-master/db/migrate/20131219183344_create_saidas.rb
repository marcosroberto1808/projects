class CreateSaidas < ActiveRecord::Migration
  def change
    create_table :saidas do |t|
      t.references :situacao, index: true, null: false, default: 1
      t.references :tipo_saida, index: true, null: false
      t.references :requisicao, index: true, null: false
      t.date :data_saida
      t.boolean :fechado, default: false, null: false

      t.timestamps
    end

    reversible do |dir|
      dir.up do
        #add a foreign key
        execute "ALTER TABLE saidas
            ADD CONSTRAINT fk_saida_situacao
            FOREIGN KEY (situacao_id)
            REFERENCES situacoes(id)"

        execute "ALTER TABLE saidas
            ADD CONSTRAINT fk_saida_tipo_saida
            FOREIGN KEY (tipo_saida_id)
            REFERENCES tipo_saidas(id)"

        execute "ALTER TABLE saidas
            ADD CONSTRAINT fk_entrada_requisicao
            FOREIGN KEY (requisicao_id)
            REFERENCES requisicoes(id)"
      end

      dir.down do
        execute "ALTER TABLE saidas
            DROP CONSTRAINT fk_saida_situacao"

        execute "ALTER TABLE saidas
            DROP CONSTRAINT fk_saida_tipo_saida"

        execute "ALTER TABLE saidas
            DROP CONSTRAINT fk_entrada_requisicao"
      end
    end

  end
end
