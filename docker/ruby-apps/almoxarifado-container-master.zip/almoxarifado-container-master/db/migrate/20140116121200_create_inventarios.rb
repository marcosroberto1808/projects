class CreateInventarios < ActiveRecord::Migration
  def change
    create_table :inventarios do |t|
      t.date :data_inventario
      t.text :observacao
      t.boolean :fechado, default: false, null: false

      t.timestamps
    end
  end
end
