class AddValorMedioEmInventario < ActiveRecord::Migration
  def change
  	add_column :inventario_itens, :valor_medio, :decimal, precision: 16, scale: 2
  end
end
