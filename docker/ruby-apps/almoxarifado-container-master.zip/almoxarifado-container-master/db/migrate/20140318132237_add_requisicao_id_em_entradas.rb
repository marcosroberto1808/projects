class AddRequisicaoIdEmEntradas < ActiveRecord::Migration
  def change
  	add_column :entradas, :requisicao_id, :integer
  end
end
