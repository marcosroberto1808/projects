class CreateSaidaItens < ActiveRecord::Migration
  def change
    create_table :saida_itens do |t|
      t.references :saida, index: true, null: false
      t.references :requisicao_item, index: true, null: false
      t.references :material, index: true, null: false
      t.decimal :quantidade, precision: 16, scale: 4, null: false

      t.timestamps
    end

    reversible do |dir|
      dir.up do
        #add a foreign key
        execute "ALTER TABLE saida_itens
            ADD CONSTRAINT fk_saida_item_saida
            FOREIGN KEY (saida_id)
            REFERENCES saidas(id)"

        execute "ALTER TABLE saida_itens
            ADD CONSTRAINT fk_saida_item_material
            FOREIGN KEY (material_id)
            REFERENCES materiais(id)"

        execute "ALTER TABLE saida_itens
            ADD CONSTRAINT fk_saida_itens_requisicao_itens
            FOREIGN KEY (requisicao_item_id)
            REFERENCES requisicao_itens(id)"
      end

      dir.down do
        execute "ALTER TABLE saida_itens
            DROP CONSTRAINT fk_saida_item_saida"

        execute "ALTER TABLE saida_itens
            DROP CONSTRAINT fk_saida_item_material"
            
        execute "ALTER TABLE saida_itens
            DROP CONSTRAINT fk_saida_itens_requisicao_itens"
      end
    end

  end
end
