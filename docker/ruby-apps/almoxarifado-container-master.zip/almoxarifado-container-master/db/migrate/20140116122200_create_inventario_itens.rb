class CreateInventarioItens < ActiveRecord::Migration
  def change
    create_table :inventario_itens do |t|
      t.references :inventario, index: true
      t.references :material, index: true
      t.decimal :quantidade

      t.timestamps
    end

    reversible do |dir|
      dir.up do
        #add a foreign key
        execute "ALTER TABLE inventario_itens
            ADD CONSTRAINT fk_inventario_itens
            FOREIGN KEY (inventario_id)
            REFERENCES inventarios(id)"

        execute "ALTER TABLE inventario_itens
            ADD CONSTRAINT fk_materiais
            FOREIGN KEY (material_id)
            REFERENCES materiais(id)"
      end

      dir.down do
        execute "ALTER TABLE inventario_itens
            DROP CONSTRAINT fk_inventario_itens"

        execute "ALTER TABLE inventario_itens
            DROP CONSTRAINT fk_materiais"
      end
    end
  end
end
