class AddObservacaoSaida < ActiveRecord::Migration
  def change
  	add_column :saidas, :observacao, :string  	
  end
end