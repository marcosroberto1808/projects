class AddContatoFornecedor < ActiveRecord::Migration
  def change
  	add_column :fornecedores, :contato, :string  	
  end
end