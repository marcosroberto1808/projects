class CreateRequisicoes < ActiveRecord::Migration
  def change
    create_table :requisicoes do |t|
      t.references :situacao, index: true, null: false, default: 1
      t.string :solicitante
      t.string :area
      t.date :data_requisicao
      t.string :observacao, limit: 500
      t.boolean :fechado, default: false, null: false
      t.string :solicitante_colaborador_codigo, limit: 15, default: '', null: false
      
      t.timestamps
    end

    reversible do |dir|
      dir.up do
        #add a foreign key
        execute "ALTER TABLE requisicoes
            ADD CONSTRAINT fk_requisicao_situacao
            FOREIGN KEY (situacao_id)
            REFERENCES situacoes(id)"
      end

      dir.down do
        execute "ALTER TABLE requisicoes
            DROP CONSTRAINT fk_requisicao_situacao"
      end
    end
  end
end
