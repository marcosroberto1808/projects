class AddValorMedioEmMovimentacaoMaterial < ActiveRecord::Migration
  def change
  	add_column :movimentacao_materiais, :valor_medio, :decimal, precision: 16, scale: 2
  end
end
