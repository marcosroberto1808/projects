class CreateItemDespesas < ActiveRecord::Migration
  def change
    create_table :item_despesas do |t|
      t.integer :codigo, limit: 8, null: false
      t.string :descricao
      t.references :natureza_despesa, index: true, null: false

      t.timestamps
    end
  end
end
