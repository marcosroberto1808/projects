class CreateTipoEntradas < ActiveRecord::Migration
  def change
    create_table :tipo_entradas do |t|
      t.string :descricao, limit: 50

      t.timestamps
    end
  end
end
