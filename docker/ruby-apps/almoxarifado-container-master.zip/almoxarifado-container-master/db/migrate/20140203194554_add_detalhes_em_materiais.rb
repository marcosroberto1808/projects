class AddDetalhesEmMateriais < ActiveRecord::Migration
  def change
  	add_column :materiais, :detalhes, :text
  end
end
