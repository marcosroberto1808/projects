class ChangeStoredProceduresRecalcularValoresHistoricoMaterial2 < ActiveRecord::Migration
 	def change
		reversible do |dir|
			dir.up do
			   execute "CREATE OR REPLACE FUNCTION recalcular_valores_historico_material(integer)
					RETURNS numeric AS
					$BODY$
					DECLARE
						REGISTRO record;
						QUANTIDADE_ESTOQUE numeric(16,4);
						QUANTIDADE_MATERIAL numeric(16,4);
						MATERIAL record;
						VALOR_MEDIO_MATERIAL  numeric(16,2);
		
		
					BEGIN
						raise NOTICE 'Calculando todo historico de : %', $1 ;
						raise NOTICE 'Setando valor médio para NULL ' ;
						update materiais set valor_medio = null where id = $1;
						VALOR_MEDIO_MATERIAL = NULL;
						QUANTIDADE_ESTOQUE = 0;
						raise NOTICE 'Recontando Entradas e Saidas do material ' ;
						FOR REGISTRO in select * from movimentacao_materiais where material_id = $1
						LOOP
							IF VALOR_MEDIO_MATERIAL IS NOT NULL  THEN --Quando existir valor médio
								raise NOTICE '>>Valor Movimento: %', REGISTRO.valor_unitario;
								raise NOTICE '>>Quantidade Movimento: %', REGISTRO.quantidade;
								raise NOTICE '>>Quantidade ESTOQUE: %', QUANTIDADE_ESTOQUE;
								raise NOTICE '>>Valor Médio: %', VALOR_MEDIO_MATERIAL;
								raise NOTICE '##FORMULA: %', (VALOR_MEDIO_MATERIAL * QUANTIDADE_ESTOQUE);
								VALOR_MEDIO_MATERIAL   = ((VALOR_MEDIO_MATERIAL * QUANTIDADE_ESTOQUE) + (REGISTRO.valor_unitario * REGISTRO.quantidade))/(QUANTIDADE_ESTOQUE + REGISTRO.quantidade)  ;
								raise NOTICE '>>Valor médio novo: %', VALOR_MEDIO_MATERIAL  ;
							ELSE --Quando não existir valor médio
								--update materiais set valor_medio = REGISTRO.valor_unitario where id = REGISTRO.material_id;
								VALOR_MEDIO_MATERIAL  = REGISTRO.valor_unitario;
								raise NOTICE '>>Valor médio novo: %',VALOR_MEDIO_MATERIAL;
							END IF;
							update movimentacao_materiais set valor_medio = VALOR_MEDIO_MATERIAL   where id = REGISTRO.id;
							QUANTIDADE_ESTOQUE = QUANTIDADE_ESTOQUE  + REGISTRO.quantidade;
							raise NOTICE '-----------------------------';
						END LOOP;
						update movimentacao_materiais set valor_medio = VALOR_MEDIO_MATERIAL   where id = REGISTRO.id;
						update materiais set valor_medio = VALOR_MEDIO_MATERIAL   where id = $1;
						raise NOTICE 'Novo Valor Médio é: %', VALOR_MEDIO_MATERIAL   ;

					    RETURN VALOR_MEDIO_MATERIAL  ;
					END;
					$BODY$
					  LANGUAGE plpgsql VOLATILE
					  COST 100;
					ALTER FUNCTION recalcular_valores_historico_material(integer)
					  OWNER TO postgres;"

			end
			dir.down do
			   execute "DROP PROCEDURE IF EXISTS `recalcular_valores_historico_material`"
			end
		end
  end
end
