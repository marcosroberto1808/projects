class AddStoredProceduresCalcularEstoque < ActiveRecord::Migration
   def change
	reversible do |dir|

		dir.up do
		   execute "CREATE OR REPLACE FUNCTION calcular_estoque(integer)
			RETURNS numeric AS
			$BODY$
			DECLARE
				REGISTRO record;
				SALDO decimal;
				MATERIAL record;
	
			BEGIN
				select id into MATERIAL from materiais where id = $1;
				if MATERIAL.id is not null then
					select sum(quantidade) as quantidade into REGISTRO from movimentacao_materiais where material_id = $1;
					--for REGISTRO in (select sum(quantidade) as quantidade from movimentacao_materiais where material_id = $1)
					if REGISTRO.quantidade is not null then  
						SALDO = REGISTRO.quantidade ;
					else 
						SALDO = 0 ;
					end if;
				else
					raise 'Material não cadastrado';
				end if;
	

				RETURN SALDO;
			END;
			$BODY$
			LANGUAGE plpgsql VOLATILE
			COST 100;
			ALTER FUNCTION calcular_estoque(integer)
			OWNER TO postgres;"

		end
		dir.down do
		   execute "DROP PROCEDURE IF EXISTS `calcular_estoque`"
		end
	end
  end
end
