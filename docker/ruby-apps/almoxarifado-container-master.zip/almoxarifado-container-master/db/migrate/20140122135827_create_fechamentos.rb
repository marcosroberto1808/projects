class CreateFechamentos < ActiveRecord::Migration
  def change
    create_table :fechamentos do |t|
      t.date :data_fechamento
      t.text :observacao
      t.string :descricao
      t.boolean :processado, default: false

      t.timestamps
    end
  end
end
