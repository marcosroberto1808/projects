class AddAnoNotaEmpenho < ActiveRecord::Migration
  def change
  	add_column :entradas, :ano_nota_empenho, :string  	  	
  end
end