class RemovePagoDeEntrada < ActiveRecord::Migration
  def change
  	remove_column :entradas, :pago
  end
end
