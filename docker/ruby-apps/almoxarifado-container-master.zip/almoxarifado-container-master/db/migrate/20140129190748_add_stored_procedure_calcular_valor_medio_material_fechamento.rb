class AddStoredProcedureCalcularValorMedioMaterialFechamento < ActiveRecord::Migration
  def change
	reversible do |dir|

		dir.up do
		   execute "CREATE OR REPLACE FUNCTION calcular_valor_medio_material_fechamento()
			  	RETURNS trigger AS
				$BODY$
				DECLARE
					VALOR_MEDIO_CORRIGIDO decimal;
					VALOR_MEDIO_MATERIAL decimal;
					QUANTIDADE_ESTOQUE decimal;
					REGISTRO record;
					DATA_ULTIMO_FECHAMENTO date;
					COUNT integer;
					ESTOQUE decimal;
				BEGIN
	
					--Inserindo nova entrada:
					--Se não existir valor médio, deve assumir o vaor unitario da entrada como valor médio
					--Caso exista, deve ser feito a médio ponderada utilizando como referência o valor médio com o saldo, 
					--e o valor da nova entrada com o valor unitário da entrada
					 IF ( TG_OP = 'INSERT' and (NEW.entrada_item_id is not null or NEW.saida_item_id is not null)) THEN

						select valor_medio into VALOR_MEDIO_MATERIAL from materiais where id = NEW.material_id;
						raise NOTICE 'Valor médio anterior: %', VALOR_MEDIO_MATERIAL;

						IF VALOR_MEDIO_MATERIAL IS NOT NULL or VALOR_MEDIO_MATERIAL = 0 THEN
							IF (NEW.entrada_item_id is not null) THEN
								select calcular_estoque(NEW.material_id) into QUANTIDADE_ESTOQUE;
								raise NOTICE 'QUANTIDADE_ESTOQUE: %',QUANTIDADE_ESTOQUE ;
								VALOR_MEDIO_CORRIGIDO = ((VALOR_MEDIO_MATERIAL * QUANTIDADE_ESTOQUE) + (NEW.valor_unitario * NEW.quantidade))/(QUANTIDADE_ESTOQUE + NEW.quantidade)  ;
								update materiais set valor_medio = VALOR_MEDIO_CORRIGIDO where id = NEW.material_id;
								NEW.valor_medio = VALOR_MEDIO_CORRIGIDO;
							ELSE
							--Na saída a média não se altera, o valor unitario é igual a média
								NEW.valor_unitario = VALOR_MEDIO_MATERIAL;
							END IF;
			
							raise NOTICE 'Valor médio novo: %', VALOR_MEDIO_CORRIGIDO;
						ELSE
							update materiais set valor_medio = NEW.valor_unitario where id = NEW.material_id;
							NEW.valor_medio = NEW.valor_unitario;
							raise NOTICE 'Valor médio novo: %', NEW.valor_unitario;
						END IF;
		
					END IF;
					RETURN NEW;
	
				END;
				$BODY$
				  LANGUAGE plpgsql VOLATILE
				  COST 100;
				ALTER FUNCTION calcular_valor_medio_material_fechamento()
				  OWNER TO postgres;"

		end
		dir.down do
		   execute "DROP PROCEDURE IF EXISTS `calcular_valor_medio_material_fechamento`"
		end
	end
  end
end


