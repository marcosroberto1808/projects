class AddDataMovimento < ActiveRecord::Migration
  def change
  	add_column :movimentacao_materiais, :data_movimento, :date
  end
end