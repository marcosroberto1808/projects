class AddReferenciaDeItemDespesaEmMaterial < ActiveRecord::Migration
  def change
    add_column :entradas, :item_despesa_id, :integer, index: true

    reversible do |dir|
      dir.up do
        #add a foreign key
        execute "ALTER TABLE entradas
            ADD CONSTRAINT fk_item_despesas
            FOREIGN KEY (item_despesa_id)
            REFERENCES item_despesas(id)"
      end

      dir.down do
        execute "ALTER TABLE entradas
            DROP CONSTRAINT fk_item_despesas"
      end
    end
    
  end
end