class TransfereCodigoRastreamentoDeRequisicaoParaRequisicaoItens < ActiveRecord::Migration
  def change
  	remove_column :requisicoes, :codigo_rastreamento
		add_column :requisicao_itens, :codigo_rastreamento, :string
  end
end
