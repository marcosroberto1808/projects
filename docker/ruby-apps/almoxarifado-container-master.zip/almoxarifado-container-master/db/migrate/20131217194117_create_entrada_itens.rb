class CreateEntradaItens < ActiveRecord::Migration
  def change
    create_table :entrada_itens do |t|
      t.references :entrada, index: true, null: false
      t.references :material, index: true, null: false
      t.integer :quantidade
      t.decimal :valor_unitario, precision: 16, scale: 2
      t.decimal :quantidade_fornecimento, precision: 16, scale: 4
      t.decimal :valor_unitario_fornecimento, precision: 16, scale: 2

      t.timestamps
    end

    reversible do |dir|
      dir.up do
        #add a foreign key
        execute "ALTER TABLE entrada_itens
            ADD CONSTRAINT fk_entrada_item_entrada
            FOREIGN KEY (entrada_id)
            REFERENCES entradas(id)"

        execute "ALTER TABLE entrada_itens
            ADD CONSTRAINT fk_entrada_item_material
            FOREIGN KEY (material_id)
            REFERENCES materiais(id)"
      end

      dir.down do
        execute "ALTER TABLE entrada_itens
            DROP CONSTRAINT fk_entrada_item_entrada"

        execute "ALTER TABLE entrada_itens
            DROP CONSTRAINT fk_entrada_item_material"
      end
    end

  end
end
