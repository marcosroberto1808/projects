class AddStoredProcedureTriggersMovimentacaoMaterial < ActiveRecord::Migration
  def change
		reversible do |dir|
			dir.up do
			   execute 	"CREATE TRIGGER calcula_valor_delete
					AFTER DELETE
					ON movimentacao_materiais
					FOR EACH ROW
					EXECUTE PROCEDURE calcular_valor_medio_material_abertura();"

			   execute	"CREATE TRIGGER calcula_valor_insert_update
					BEFORE INSERT OR UPDATE
					ON movimentacao_materiais
					FOR EACH ROW
					EXECUTE PROCEDURE calcular_valor_medio_material_fechamento();"
			end

			dir.down do
			   execute 	"DROP TRIGGER 'calcula_valor_delete' ON movimentacao_materiais;"
			   execute 	"DROP TRIGGER 'calcula_valor_insert_update' ON movimentacao_materiais;"
			end
  	end
  end
end