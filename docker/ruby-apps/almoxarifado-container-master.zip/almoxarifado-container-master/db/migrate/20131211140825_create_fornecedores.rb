class CreateFornecedores < ActiveRecord::Migration
  def change
    create_table :fornecedores do |t|
      t.string :razao_social, limit: 100, null: false
      t.string :nome_fantasia, limit: 100, null: false
      t.string :cnpj, limit: 20, null: false
      t.string :endereco, limit: 100, null: false
      t.string :numero, limit: 10, null: false
      t.string :complemento, limit: 250
      t.string :cep, limit: 10, null: false
      t.string :estado, limit: 2, null: false
      t.string :cidade, limit: 50, null: false
      t.string :telefone1, limit: 20
      t.string :telefone2, limit: 20
      t.string :telefone3, limit: 20
      t.string :email, limit: 50

      t.timestamps
    end
  end
end
