class ChangeForeignKeyFromMovimentacaoMateriais < ActiveRecord::Migration
  def change
    reversible do |dir|
      dir.up do
        #add a foreign key
        execute "ALTER TABLE movimentacao_materiais
            DROP CONSTRAINT fk_inventario_itens"

        execute "ALTER TABLE movimentacao_materiais
            ADD CONSTRAINT fk_inventario_itens
            FOREIGN KEY (inventario_item_id)
            REFERENCES inventario_itens(id)"
      end

      dir.down do
        execute "ALTER TABLE movimentacao_materiais
            DROP CONSTRAINT fk_inventario_itens"
      end
    end
  end
end
