class AddDeviseToColaboradores < ActiveRecord::Migration
  def self.up  	
    Colaborador.connection.add_column(:colaboradores, :email, :string, default: '') unless Colaborador.column_names.include?('email')
    Colaborador.connection.add_column(:colaboradores, :encrypted_password, :string, default: '', null: false) unless Colaborador.column_names.include?('encrypted_password')
    Colaborador.connection.add_column(:colaboradores, :reset_password_token, :string) unless Colaborador.column_names.include?('reset_password_token')
    Colaborador.connection.add_column(:colaboradores, :reset_password_sent_at, :datetime) unless Colaborador.column_names.include?('reset_password_sent_at')
    Colaborador.connection.add_column(:colaboradores, :remember_created_at, :datetime) unless Colaborador.column_names.include?('remember_created_at')
    Colaborador.connection.add_column(:colaboradores, :sign_in_count, :integer, default: 0, null: false) unless Colaborador.column_names.include?('sign_in_count')
    Colaborador.connection.add_column(:colaboradores, :current_sign_in_at, :datetime) unless Colaborador.column_names.include?('current_sign_in_at')
    Colaborador.connection.add_column(:colaboradores, :last_sign_in_at, :datetime) unless Colaborador.column_names.include?('last_sign_in_at')
    Colaborador.connection.add_column(:colaboradores, :current_sign_in_ip, :string) unless Colaborador.column_names.include?('current_sign_in_ip')
    Colaborador.connection.add_column(:colaboradores, :last_sign_in_ip, :string) unless Colaborador.column_names.include?('last_sign_in_ip')
    Colaborador.connection.add_column(:colaboradores, :legacy_password, :boolean, default: true) unless Colaborador.column_names.include?('legacy_password')
  end

  def self.down
    Colaborador.connection.remove_column(:colaboradores, :email, :string, default: '') unless Colaborador.column_names.include?('email')
    Colaborador.connection.remove_column(:colaboradores, :encrypted_password, :string, default: '', null: false) unless Colaborador.column_names.include?('encrypted_password')
    Colaborador.connection.remove_column(:colaboradores, :reset_password_token, :string) unless Colaborador.column_names.include?('reset_password_token')
    Colaborador.connection.remove_column(:colaboradores, :reset_password_sent_at, :datetime) unless Colaborador.column_names.include?('reset_password_sent_at')
    Colaborador.connection.remove_column(:colaboradores, :remember_created_at, :datetime) unless Colaborador.column_names.include?('remember_created_at')
    Colaborador.connection.remove_column(:colaboradores, :sign_in_count, :integer, default: 0, null: false) unless Colaborador.column_names.include?('sign_in_count')
    Colaborador.connection.remove_column(:colaboradores, :current_sign_in_at, :datetime) unless Colaborador.column_names.include?('current_sign_in_at')
    Colaborador.connection.remove_column(:colaboradores, :last_sign_in_at, :datetime) unless Colaborador.column_names.include?('last_sign_in_at')
    Colaborador.connection.remove_column(:colaboradores, :current_sign_in_ip, :string) unless Colaborador.column_names.include?('current_sign_in_ip')
    Colaborador.connection.remove_column(:colaboradores, :last_sign_in_ip, :string) unless Colaborador.column_names.include?('last_sign_in_ip')
    Colaborador.connection.remove_column(:colaboradores, :legacy_password, :boolean, default: true) unless Colaborador.column_names.include?('legacy_password')
  end
end
