class CreateMovimentacaoMateriais < ActiveRecord::Migration
  def change
    create_table :movimentacao_materiais do |t|
      t.references :inventario_item
      t.references :saida_item
      t.references :entrada_item
      t.references :material, null: :false
      t.decimal :valor_unitario
      t.decimal :quantidade
      t.decimal :valor_total      
      
      t.timestamps
    end

    reversible do |dir|
      dir.up do
        #add a foreign key
        execute "ALTER TABLE movimentacao_materiais
            ADD CONSTRAINT fk_inventario_itens
            FOREIGN KEY (inventario_item_id)
            REFERENCES inventarios(id)"

        execute "ALTER TABLE movimentacao_materiais
            ADD CONSTRAINT fk_saida_itens
            FOREIGN KEY (saida_item_id)
            REFERENCES saida_itens(id)"

        execute "ALTER TABLE movimentacao_materiais
            ADD CONSTRAINT fk_entrada_itens
            FOREIGN KEY (entrada_item_id)
            REFERENCES entrada_itens(id)"
      end

      dir.down do
        execute "ALTER TABLE movimentacao_materiais
            DROP CONSTRAINT fk_inventario_itens"

        execute "ALTER TABLE movimentacao_materiais
            DROP CONSTRAINT fk_saida_itens"

        execute "ALTER TABLE movimentacao_materiais
            DROP CONSTRAINT fk_entrada_itens"
      end
    end

  end
end
