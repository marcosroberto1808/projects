class AddQdeDevolvidaEmRequisicao < ActiveRecord::Migration
  def change
  	add_column :requisicao_itens, :qde_devolvida, :decimal, precision: 16, scale: 4
  end
end
