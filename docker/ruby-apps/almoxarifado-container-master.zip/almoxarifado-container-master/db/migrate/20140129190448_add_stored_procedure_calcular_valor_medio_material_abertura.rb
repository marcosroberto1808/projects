class AddStoredProcedureCalcularValorMedioMaterialAbertura < ActiveRecord::Migration
  def change
	reversible do |dir|

		dir.up do
		   execute "CREATE OR REPLACE FUNCTION calcular_valor_medio_material_abertura()
				  RETURNS trigger AS
				$BODY$
				DECLARE
					VALOR_MEDIO_CORRIGIDO numeric(16,2);
	
				BEGIN

					IF ( TG_OP = 'DELETE' AND OLD.entrada_item_id is not null) THEN
						raise NOTICE 'DELETANDO movimentação de id: %',OLD.id ;
						raise NOTICE 'INICIANDO O RECALCULO COMPLETO DO MATERIAL';
						--select * from  recalcular_valores_historico_material(OLD.material_id);
						select * into VALOR_MEDIO_CORRIGIDO from recalcular_valores_historico_material(OLD.material_id);
		
					END IF;
					RETURN OLD;
				END;
				$BODY$
				  LANGUAGE plpgsql VOLATILE
				  COST 100;
				ALTER FUNCTION calcular_valor_medio_material_abertura()
				  OWNER TO postgres;"

		end
		dir.down do
		   execute "DROP PROCEDURE IF EXISTS `calcular_valor_medio_material_abertura`"
		end
	end
  end
end

