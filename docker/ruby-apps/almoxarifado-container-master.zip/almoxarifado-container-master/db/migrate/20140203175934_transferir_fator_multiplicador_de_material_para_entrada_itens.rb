class TransferirFatorMultiplicadorDeMaterialParaEntradaItens < ActiveRecord::Migration
  def change
  	remove_column :materiais, :fator_multiplicador
  	add_column :entrada_itens, :fator_multiplicador, :decimal, precision: 16, scale: 4, null: :false
  end
end
