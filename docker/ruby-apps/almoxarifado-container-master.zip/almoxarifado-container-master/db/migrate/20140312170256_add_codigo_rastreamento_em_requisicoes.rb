class AddCodigoRastreamentoEmRequisicoes < ActiveRecord::Migration
  def change
  	add_column :requisicoes, :codigo_rastreamento, :string
  end
end
