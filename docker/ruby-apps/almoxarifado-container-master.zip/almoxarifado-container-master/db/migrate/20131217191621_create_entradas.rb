class CreateEntradas < ActiveRecord::Migration
  def change
    create_table :entradas do |t|
      t.references :tipo_entrada, index: true, null: false
      t.references :fornecedor, index: true
      t.integer :nota_fiscal
      t.decimal :valor_nota_fiscal, precision: 16, scale: 2
      t.integer :nota_empenho
      t.date :data_emissao
      t.date :data_entrada
      t.text :observacao
      t.boolean :pago
      t.string :ordem_de_compra, :string, limit: 250
      t.string :ata, :string, limit: 250
      t.boolean :fechado, default: false,  null: false

      t.timestamps
    end

    reversible do |dir|
      dir.up do
        #add a foreign key
        execute "ALTER TABLE entradas
            ADD CONSTRAINT fk_entrada_tipo_entrada
            FOREIGN KEY (tipo_entrada_id)
            REFERENCES tipo_entradas(id)"

        execute "ALTER TABLE entradas
            ADD CONSTRAINT fk_entrada_fornecedor
            FOREIGN KEY (fornecedor_id)
            REFERENCES fornecedores(id)"
      end

      dir.down do
        execute "ALTER TABLE entradas
            DROP CONSTRAINT fk_entrada_tipo_entrada"

        execute "ALTER TABLE entradas
            DROP CONSTRAINT fk_entrada_fornecedor"
      end
    end

  end
end
