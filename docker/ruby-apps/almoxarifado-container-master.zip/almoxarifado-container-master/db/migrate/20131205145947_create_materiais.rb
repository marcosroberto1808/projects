class CreateMateriais < ActiveRecord::Migration
  def change
    create_table :materiais do |t|
      t.references :unidade_medida_consumo, index: true, null: false
      t.references :unidade_medida_fornecimento, index: true, null: false
      t.string :descricao, null: false, limit: 250
      t.string :codigo, limit: 20
      t.decimal :limite_maximo, precision: 16, scale: 4
      t.decimal :limite_minimo, precision: 16, scale: 4
      t.decimal :fator_multiplicador, precision: 16, scale: 4, null: false
      t.string :localizacao, limit: 250
      t.decimal :valor_medio, precision: 16, scale: 2

      t.timestamps
    end

    reversible do |dir|
      dir.up do
        #add a foreign key
        execute "ALTER TABLE materiais
            ADD CONSTRAINT fk_consumo_unidade_medidas
            FOREIGN KEY (unidade_medida_consumo_id)
            REFERENCES unidade_medidas(id)"

        execute "ALTER TABLE materiais
            ADD CONSTRAINT fk_fornecimento_unidade_medidas
            FOREIGN KEY (unidade_medida_fornecimento_id)
            REFERENCES unidade_medidas(id)"
      end

      dir.down do
        execute "ALTER TABLE materiais
            DROP CONSTRAINT fk_consumo_unidade_medidas"

        execute "ALTER TABLE materiais
            DROP CONSTRAINT fk_fornecimento_unidade_medidas"
      end
    end
    
  end
end
