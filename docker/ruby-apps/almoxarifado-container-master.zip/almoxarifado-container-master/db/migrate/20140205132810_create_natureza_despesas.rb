class CreateNaturezaDespesas < ActiveRecord::Migration
  def change
    create_table :natureza_despesas do |t|
      t.string :descricao, null: :false

      t.timestamps
    end
  end
end
