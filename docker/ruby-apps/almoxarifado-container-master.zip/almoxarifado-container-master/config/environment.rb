# Load the Rails application.
require File.expand_path('../application', __FILE__)

# Initialize the Rails application.
Almoxarifado::Application.initialize!

if Rails.env.development?
  URL_ALMOXARIFADO = "localhost:3000"
elsif Rails.env.homolog?
  URL_ALMOXARIFADO = "hg.almoxarifado.defensoria.ce.def.br"
elsif Rails.env.production?
  URL_ALMOXARIFADO = "almoxarifado.defensoria.ce.def.br"
elsif Rails.env.stage?
  URL_ALMOXARIFADO = "stage.almoxarifado.defensoria.ce.def.br"
end
