Almoxarifado::Application.routes.draw do
  get  "relatorios/saida"
  post "relatorios/saida_relatorio"
  get  "relatorios/entrada"
  post "relatorios/entrada_relatorio"
  get  "relatorios/posicao"
  post "relatorios/posicao_relatorio"
  get  "relatorios/entrada_devolucao"
  post "relatorios/entrada_relatorio_devolucao"
  get  "relatorios/entrada_doacao"
  post "relatorios/entrada_relatorio_doacao"
  get  "relatorios/entrada_saida"
  post "relatorios/entrada_saida_relatorio"
  get  "relatorios/ressuprimento"
  post "relatorios/ressuprimento_relatorio"
  get 'relatorios/ressuprimento_items'
  get  "relatorios/saida_financeira"
  post "relatorios/saida_financeira_relatorio"
  get  "relatorios/entrada_financeira"
  post "relatorios/entrada_financeira_relatorio"
  get  "relatorios/requisicao"
  post "relatorios/requisicao_relatorio"
  get  "relatorios/inventario"
  post "relatorios/inventario_relatorio"
  get "relatorios/show"
  post "relatorios/show"
  get "relatorios/saida_financeira_detalhamento_relatorio", as: "saida_financeira_detalhamento_relatorio"
  get "relatorios/entrada_financeira_detalhamento_relatorio", as: "entrada_financeira_detalhamento_relatorio"

    get  "colaboradores/reset_password"
      post  "colaboradores/reset_password"


  resources :item_despesas
  resources :natureza_despesas
  resources :fechamentos do
     member do
      get 'processar'
    end
  end

  resources :inventarios
  resources :inventario_itens
  resources :movimentacao_materiais
  resources :saida_itens
  resources :tipo_saidas
  resources :entrada_itens
  resources :tipo_entradas
  resources :requisicao_itens
  resources :fornecedores do
    post "pesquisar", :on => :collection
  end

  get "materiais/pesquisar", to: "materiais#pesquisar", defaults: { format: 'js' }

  resources :materiais do
    post "pesquisar", :on => :collection
  end

  resources :unidade_medidas
  resources :home, only: :index

  resources :requisicoes do
    member do
      get 'change_status'
    end
  end

  resources :entradas do
    member do
      get 'change_status'
    end

    collection do
      get 'nota_fiscal'
      get 'devolucao'
      get 'doacao'
    end
  end

  resources :saidas do
    member do
      get 'change_status'
    end
  end

  resources :inventarios do
    member do
      get 'change_status'
    end
  end

  resource :colaborador do
    collection do
      patch 'update_password'
      patch 'reset_password'
    end
  end

  devise_for  :colaboradores,
              :controllers => { :passwords => "passwords" },
              :path => '',
              :path_names => {sign_in: :login, sign_out: :logout}

  root 'home#index'
  get '/json_autocomplete_material' => 'materiais#json_autocomplete_material'
  get '/json_autocomplete_material_requisicao' => 'materiais#json_autocomplete_material_requisicao'
  post '/autocomplete_material_check' => 'materiais#autocomplete_material_check'
  post '/valor_medio_material_check' => 'materiais#valor_medio_material_check'
  post '/show_material_info' => 'materiais#show_material_info'
  post '/show_material_unidade_medida' => 'materiais#show_material_unidade_medida'
  post '/show_natureza_item_despesa' => 'materiais#show_natureza_item_despesa'
  post '/pesquisar_requisicao' => 'entradas#pesquisar_requisicao'
end
