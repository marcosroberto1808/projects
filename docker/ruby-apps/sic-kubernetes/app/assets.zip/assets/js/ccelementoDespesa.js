(function( $ ){
	$.fn.cadastraElementoDespesa = function(par){
		 $.ajax({
            type: "POST",
            url: par.url,
            data: $('#form-elemendoDispesa').serialize()
        }).done(function( resposta ) {
        	if(resposta.retorno){
        		var form = $('#form-cced').clone();
        		var formId = 'form-cced-' + resposta.id
        		var a = "<a href=\"#\" class=\"btn\" style=\"color:red\" onclick=\"$().removerElementoDespesa({url: '/contas-de-controle/json/exclui/elemento-despesa',form: '#form-cced-" + resposta.id + "});\" id=\"cced-" + resposta.id + "\" >" + resposta.codigo + " <i class=\"fa fa-ban\"></i></a>";
        		form.attr('id',formId);
        		form.append(a);
        		
        		$('#lista-elementos').append(form);
        		$('#elemento_despesa').val('');
        		window.location.reload();
        	}else{
        		alert(resposta.mensagem);
        	}
        });

	};
	$.fn.removerElementoDespesa = function(par){
		 $.ajax({
            type: "POST",
            url: par.url,
            data: $(par.form).serialize()
        }).done(function( resposta ) {
        	if(resposta.retorno == false){
        		alert(resposta.mensagem);
        	}else{
        		$(par.form).hide('slow');
        	}

        });

	};
})( jQuery );
