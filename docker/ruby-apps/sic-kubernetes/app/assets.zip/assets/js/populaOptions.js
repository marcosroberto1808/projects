(function( $ ){
    $.fn.montaOptions = function(lista,destino){
         if(lista.length > 0){
            var newOptions = lista;
            var select = $(destino);
            if($.isEmptyObject(select)){
                console.log('função montaOptions : o destino não foi encontrado.');
                return false;
            }
            $('option', select).remove();
            if(select.prop) {
                var options = select.prop('options');
            }else {
                var options = select.attr('options');
            }
            $('option', select).remove();
            $.each(newOptions, function(val, text) {
                options[options.length] = new Option(text.descricao, text.valor);
            });
        }
    }

    $.fn.limpaOptions = function(destino){
        var select = $(destino);
        $('option', select).remove();
    }

	$.fn.populaOptions = function(par, callback){
        if (typeof callback == 'function') { 
            callback.call(this); 
        }
        id = $(this).val();
        if(id > 0){
            dados = {
                        'id': id
            }
            var select = $(par.destino);
            $.ajax({
                type: "GET",
                url: par.url,
                data: dados
                }).done(function( lista ) {
                    if(lista.length > 0){
                        var newOptions = lista;
                        var select = $(par.destino);
                        if(select.prop) {
                          var options = select.prop('options');
                        }
                        else {
                          var options = select.attr('options');
                        }
                        $('option', select).remove();
                        $.each(newOptions, function(val, text) {
                            options[options.length] = new Option(text.descricao, text.valor);
                        });
                    }else{
                        var select = $(par.destino);
                        $('option', select).remove();
                    }
             });
        }else{
           	var select = $(par.destino);
            $('option', select).remove();
        }
	};
})( jQuery );