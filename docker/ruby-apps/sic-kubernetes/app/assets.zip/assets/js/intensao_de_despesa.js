(function( $ ){
	$.fn.somaCronogramaMensal = function(inputMensal, inputSolicitado, target){
        var total = 0;
        inputMensal.each(function(){
            var valor = $(this).val().replace(/\./g,'').replace(',','.');
            if(typeof(valor) == "string" && parseFloat(valor) > 0){
                total = total + parseFloat(valor);
            }
        });
        if ( total <= parseFloat(inputSolicitado.val().replace(/[,.]/g,''))) {
            setTimeout(function(){target.html("R$ " + number_format(total, 2, ',', '.')); }, 300);
        }else{
            setTimeout(function(){target.html("R$ " + number_format(total, 2, ',', '.')); }, 300);
        }
        
       
	}

    $.fn.pega_para_proposta = function(intencao){
        var url = '/intencoes-de-despesa/json/proposta-de-empenho/' + intencao;
        $.ajax({
            type: "GET",
            url: url
        }).done(function(json) {
            if (json == 'False'){
                $('#nome_intencao').html("Intenção de Despesa não encontrada.");
            }else{
                $().selecionaContaControle(json.conta_controle_ano);
                $('#nome_intencao').html(json.nome);
                $("#conta_controle").html(json.conta_controle);
                $("#conta_controle_ano").val(json.conta_controle_ano);
                $().ajustaMotivos(json.conta_controle_ano);
                
                if(json.instrumento_de_despesa == 'Possui Contrato'){
                    $('#instrumento_despesa').val(1);
                }

                if(json.instrumento_de_despesa == 'Despesa sem contrato'){
                    $('#instrumento_despesa').val(2);
                }

                if(json.fontes.FAADEP){
                    $('#cod_unidade_executora option[value="060101"]').show();
                }

                if(json.fontes.tesouro){
                    $('#cod_unidade_executora option[value="060001"]').show();
                }
            }
            
            $('.outroscampos').show();

        }).error(function(){
            $().selecionaContaControle(0);
            $('#nome_intencao').html("Intenção de Despesa não encontrada ou invalida.");
            $('.outroscampos').hide();
            $("#conta_controle").html('');
            $("#conta_controle_ano").val('');
        });
    }

    $.fn.get_intencao = function(){
        var intencao = parseInt($('#codigo_id').val());
        $("#intencao_despesa").val(intencao);
        $("#intencao_de_despesa").val(intencao);
        $().pega_para_proposta(intencao);
    }

})( jQuery );