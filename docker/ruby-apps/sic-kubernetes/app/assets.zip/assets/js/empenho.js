(function( $ ){
    $.fn.getdetalhesEmpenho = function(par){
         var url = "/empenhos/json/detalhes/" + par.id;
         if (par.id > 0){
             $.ajax({
                type: "GET",
                url: url,
            }).done(function( empenho ) {
                resultado = empenho[0].fields;
            }).error(function(empenho){

            });
        }       
    };

    $.fn.getdetalhesEmpenhoNumero = function(par){
         var url = "/empenhos/json/detalhes/numero/" + par.numero + "/" + par.ano + "/" + par.unidade;
         
             $.ajax({
                type: "GET",
                url: url,
            }).done(function( empenho ) {
                resultado = empenho[0].fields;
            }).error(function(empenho){

            });
             
    };

})( jQuery );