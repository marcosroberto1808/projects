(function( $ ){
	$.fn.getDotacaoContrato = function(par){
        url = "/orcamentarios/json/dotacoes/"
        $('#item_despesa option').remove();
        if(par.id == 'undefined' || par.id == null){
            id = $(this).val();
        }else{
            id = par.id;
        }

        if(id > 0){
        	$.ajax({
                type: "POST",
                url: url,
                data: {csrfmiddlewaretoken:$().getCSRF(),id:id,tipo:par.tipo,intencao:par.intencao,ano:par.ano}
             }).done(function( resposta ) {
                if(resposta != false){
                    $().montaOptions(resposta,par.destino);
                    if(par.dotacao > 0){
                       setTimeout(function(){$(par.destino).val(par.dotacao);$(par.destino).getItens({destino:'#item_despesa',item:par.item,ano:par.ano});},500);
                    }
                    if('contas_controle' == par.tipo){
                        $('.contrato-dados').hide();
                    }
                }else{
                    $('.contrato-dados').show();
                    $().limpaOptions(par.destino);
                }
            }).error(function(resposta){
                $().limpaOptions(par.destino);
            });
        }else{
            $().limpaOptions(par.destino);
        }
       
	};

    $.fn.getItens = function(par){
        url = "/orcamentarios/json/dotacao/" + $(this).val() + "/itens/" + par.ano;
        if($(this).val() > 0){
            $.ajax({
                type: "GET",
                url: url,
            }).done(function( resposta ) {
                if(resposta != false){
                    $().montaOptions(resposta,par.destino);
                    if(par.item > 0){
                        $(par.destino).val(par.item);
                    }
                }
            }).error(function(resposta){
                var select = $(par.destino);
                $('option', select).remove();
            });
        }else{
            var select = $(par.destino);
            $('option', select).remove();
        }
    }

    $.fn.getCredor = function(){
        $('#contratos-content').hide('fast');
        $('#constratos option').remove();

        var cca = $('#conta_controle_ano').val();
        var url = '/contas-de-controle/json/cca/cc/' + cca + '/';
        var instrumento = $('#instrumento_despesa').val();
        var ano = $('#ano').val();
        $.ajax({
            type: "GET",
            url: url
        }).done(function(json) {
            var verifica = json[0].fields.instrumento_despesa;
            if(verifica){
                $('#possui_contrato_content').show('fast');
                if(instrumento > 0){
                    $().mostraContratosNG(instrumento,$('#conta_controle_ano').val());
                    $('#contratos-content').show('fast');
                }
                $('#cod_reduzido_dotacao option').remove();
                $('#item_despesa option').remove();
            }else{
                //$('#num_conta_controle').getDotacaoContrato({tipo:'proposta_empenho',destino:'#cod_reduzido_dotacao',id:cca, intencao:$('#codigo_id').val(),ano:ano});
            }
        });
       
        url = "/orcamentarios/json/credor/"
        id = $('#credor').val();
        if (id > 0){
            $.ajax({
               type: "POST",
               url: url,
               data: {csrfmiddlewaretoken:$().getCSRF(),id:id}
            }).done(function( resposta ) {
                if(resposta != false){
                    $('#credor-cnpj').val(resposta[0].fields.cpf_cnpj);
                    $('#credor-codigo').val(resposta[0].fields.codigo);
                    $('#credor-email').val(resposta[0].fields.email);
                    $('#credor-logradouro').val(resposta[0].fields.logradouro);
                    $('#credor-cep').val(resposta[0].fields.cep);
                    $('#credor-municipio').val(resposta[0].fields.municipio);
                    $('#credor-uf').val(resposta[0].fields.uf);
                    
                    $('.contrato-dados input').val(''); 
                    $('#possui_contrato').val('');
                    $('#constratos').val('');
                }
            }).error(function(resposta){
                console.log("getCredor: " + resposta);
            });
            
        }else{
            alert("Credor não identificado.");
        }
    };
})( jQuery );
