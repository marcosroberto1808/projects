function getDateDiff(date1, date2, interval) {
    var second = 1000,
    minute = second * 60,
    hour = minute * 60,
    day = hour * 24,
    week = day * 7;
    dateone = new Date(date1).getTime();
    datetwo = (date2) ? new Date().getTime() : new Date(date2).getTime();
    var timediff = datetwo - dateone;
 secdate = new Date(date2);
 firdate = new Date(date1);
    if (isNaN(timediff)) return NaN;
    switch (interval) {
    case "anos":
        return secdate.getFullYear() - firdate.getFullYear();
    case "meses":
        return ((secdate.getFullYear() * 12 + secdate.getMonth()) - (firdate.getFullYear() * 12 + firdate.getMonth()));
    case "semanas":
        return Math.floor(timediff / week);
    case "dias":
        return Math.floor(timediff / day);
    case "horas":
        return Math.floor(timediff / hour);
    case "minutos":
        return Math.floor(timediff / minute);
    case "segundos":
        return Math.floor(timediff / second);
    default:
        return undefined;
    }
}