$(document).ready(function(){
   $( "#nome_credor" ).autocomplete({
        source: '/getcredores/',
        minLength: 3,
        select: function(e, ui) {
            e.preventDefault() // <--- Prevent the value from being inserted.
            var cnpj = $(this).attr('data-cnpj'),nome = '';
            if (cnpj == 'false'){
                var data = ui.item.label.split(' (');
                nome = data[0];
            }else{
                nome = ui.item.label;
            }

            $("#credor").val(ui.item.value);
            $("#nome_credor").val(nome);
            if($(this).attr('data-get') == 'true'){
                $().getCredor();
            }
        }
    });

   $( ".nome_id").autocomplete({
        source: '/intencoes-de-despesa/json/autocomplete/',
        minLength: 1,
        select: function(e, ui) {
            e.preventDefault()
            $("#intencao_despesa").val(ui.item.value);
            $("#intencao_de_despesa").val(ui.item.value);
            $(this).val(ui.item.label);
            $().pega_para_proposta(ui.item.value);
        }
    });

   $( "#contas_controle" ).change(function(){
        id = $(this).val();
        if(id > 0){
            
            dados = {
                'id': id
            }

            $.ajax({
                type: "GET",
                url: "/getcontrato/",
                data: dados
                }).done(function( lista ) {
                    var newOptions = lista;

                    var select = $('#contratos');
                    if(select.prop) {
                      var options = select.prop('options');
                    }
                    else {
                      var options = select.attr('options');
                    }
                    $('option', select).remove();
                    options[0] = new Option('Selecione um Contrato', '');
                    $.each(newOptions, function(val, text) {
                        options[options.length] = new Option(text.descricao, text.valor);
                    });
                    //select.val(selectedOption);
             });
            }else{
                var select = $('#contratos');
                 $('option', select).remove();
            }
    });

   $( "#contas_controle" ).change(function(){
        id = $(this).val();
        if(id > 0){
            dados = {
                        'id': id
            }
            $.ajax({
                type: "GET",
                url: "/getconvenio/",
                data: dados
                }).done(function( lista ) {
                    var newOptions = lista;

                    var select = $('#convenio');
                    if(select.prop) {
                      var options = select.prop('options');
                    }
                    else {
                      var options = select.attr('options');
                    }
                    $('option', select).remove();
                    options[0] = new Option('Selecione um Convenio', '');
                    $.each(newOptions, function(val, text) {
                        options[options.length] = new Option(text.descricao, text.valor);
                    });
             });
            }else{
                var select = $('#convenio');
                 $('option', select).remove();
            }
    });

   $( "#contas_de_controle" ).change(function(){
        id = $(this).val();
        if(id > 0){
            dados = {
                        'id': id
            }
            $.ajax({
                type: "GET",
                url: "/getintencao/",
                data: dados
                }).done(function( lista ) {
                    var newOptions = lista;

                    var select = $('#intencao_despesa');
                    if(select.prop) {
                      var options = select.prop('options');
                    }
                    else {
                      var options = select.attr('options');
                    }
                    $('option', select).remove();
                    options[0] = new Option('Selecione uma intenção de despesa.', '');
                    $.each(newOptions, function(val, text) {
                        options[options.length] = new Option(text.descricao, text.valor);
                    });
             });
            }else{
                var select = $('#intencao_despesa');
                 $('option', select).remove();
            }
    });
});