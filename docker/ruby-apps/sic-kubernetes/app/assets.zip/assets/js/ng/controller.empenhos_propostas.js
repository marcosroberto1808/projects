$.fn.mostraContratosNG = function(tipo,cc,contrato){
		$('#constratos').val('');
		$('.contrato-dados input').val('');	
		var id = $('#credor').val() + "|" + $('#conta_controle_ano').val(), valor = tipo;
		$('.so-com-contrato-selecionado').hide('fast');
		if( valor == 1){
			if(typeof(contrato) != "undefined"){
				$().getContratos({id:id,por:'credor_cc_despesa',destino: '#constratos',documento:contrato});
			}else{
				$().getContratos({id:id,por:'credor_cc_despesa',destino: '#constratos'});
			}
			$('#contratos-content').show('fast');
			$('#titulo_contrato').html('Contratos :');
			$(this).val(1);
		}else if(valor == 2){
			if(typeof(contrato) != "undefined"){
				$().getSemContrato({id:id,por:'credor_cc',destino: '#constratos',documento:contrato});
			}else{
				$().getSemContrato({id:id,por:'credor_cc',destino: '#constratos'});
			}
			$('#contratos-content').show('fast');
			$('#titulo_contrato').html('Despesa sem contrato :');
			
			$(this).val(2);
		}else if(valor == 3){
			if(typeof(contrato) != "undefined"){
				$().getConvenios({id:id,por:'credor_cc_despesa',destino: '#constratos',documento:contrato});
			}else{
				$().getConvenios({id:id,por:'credor_cc_despesa',destino: '#constratos'});
			}
			$('#contratos-content').show('fast');
			$('#titulo_contrato').html('Convênios :');
			$(this).val(3);
		}else {
			$('#constratos option').remove();
			$('#contratos-content, .so-com-contrato-selecionado').hide('fast');
			$().limpaOptions('#constratos');
		}
			$().limpaOptions('#cod_reduzido_dotacao');
			$().limpaOptions('#item_despesa');
	}
$.fn.getInstrumentosReceitaNG = function(tipo,cc,instrumento){
		var id = $('#credor').val() + "|" + cc, valor = tipo;
		if( valor == 1){
			if(typeof(instrumento) != "undefined"){
				$().getContratos({id:id,por:'credor_cc_receita',destino: '#cod_instrumento_receita',documento:instrumento});
			}else{
				$().getContratos({id:id,por:'credor_cc_receita',destino: '#cod_instrumento_receita'});
			}
			$('#content-cod_instrumento_receita').show('fast');
			$('#titulo_instrumento_receita').html('Contratos :');
			$(this).val(1);
		}else if(valor == 2){
			if(typeof(instrumento) != "undefined"){
				$().getConvenios({id:id,por:'credor_cc_receita',destino: '#cod_instrumento_receita',documento:instrumento});
			}else{
				$().getConvenios({id:id,por:'credor_cc_receita',destino: '#cod_instrumento_receita'});
			}
			$('#content-cod_instrumento_receita').show('fast');
			$('#titulo_instrumento_receita').html('Convênios :');
			$(this).val(2);
		}else {
			$('#cod_instrumento_receita option').remove();
			$('#content-cod_instrumento_receita').hide('fast');
			$().limpaOptions('#cod_instrumento_receita');
		}

	}