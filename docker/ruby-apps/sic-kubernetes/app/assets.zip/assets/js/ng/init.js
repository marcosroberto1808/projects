angular.module("sige", []);
angular.module("sige").config(function($interpolateProvider){
	$interpolateProvider.startSymbol('{[{').endSymbol('}]}');
});