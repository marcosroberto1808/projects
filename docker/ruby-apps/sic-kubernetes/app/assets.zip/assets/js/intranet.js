(function($){
	$('input, select, textarea').addClass('form-control');
	$('input[type="submit"], input[type="button"], input[type="reset"], input[type="radio"], input[type="checkbox"]').removeClass('form-control');
	$('input[type="submit"], input[type="button"], input[type="reset"]').addClass('btn');
	$('table').addClass('table table-bordered table-hover table-striped');
	$('.switch-display').change(function(){
		var elemento = $(this).attr('data-elemento');
		var show = $(this).val();
		$(elemento).hide('fast');
		$(show).show('fast');
	});

	$('.switch-element').click(function(){
		var elemento = $(this).attr('data-elemento');
		var estado = $(elemento).attr('data-display');
		if (estado == 'true'){
			$(elemento).attr('data-display', 'false');
			$(elemento).hide('fast');
		}else{
			$(elemento).attr('data-display', 'true');
			$(elemento).show('fast');
		}
		return false;
	});

	$('.remove-element').click(function(){
		var elemento = $(this).attr('data-elemento');
		$(elemento).remove();
	});

	$('.dropdown').mouseover(function(){
		var estado = $(this).find('.dropdown-toggle').attr('aria-expanded');
		if (estado == 'true'){
			$(this).find('.dropdown-toggle').attr('aria-expanded',false);
			$(this).removeClass('open');
		}else{
			$(this).find('.dropdown-toggle').attr('aria-expanded',true);
			$(this).addClass('open');
		}
	}).mouseout(function(){
		var estado = $(this).find('.dropdown-toggle').attr('aria-expanded');
		if (estado == 'true'){
			$(this).find('.dropdown-toggle').attr('aria-expanded',false);
			$(this).removeClass('open');
		}else{
			$(this).find('.dropdown-toggle').attr('aria-expanded',true);
			$(this).addClass('open');
		}
	});

	$('.switch-menu').click(function(){
		var elemento = $('#main-principal');
		var visibilidade = elemento.css('display');
		if('none' == visibilidade){
			elemento.show('fast');
			$('#wrapper').animate({
			    paddingLeft: '225px'
			}, 300);
			$(this).animate({
			    left: '210px'
			}, 300);
			$(this).find('i').removeClass('fa-arrow-right');
			$(this).find('i').addClass('fa-arrow-left');
		}else{
			elemento.hide('fast');
			$('#wrapper').animate({
			    paddingLeft: '0px'
			}, 500);
			$(this).animate({
			    left: '0px'
			}, 500);
			$(this).find('i').removeClass('fa-arrow-left');
			$(this).find('i').addClass('fa-arrow-right');
		}
	});

})(jQuery)