(function( $ ){
	$.fn.getSemContrato = function(par){
         url = "/despesas-sem-contrato/json/documento/";
    		 $.ajax({
                type: "POST",
                url: url,
                data: {csrfmiddlewaretoken:$().getCSRF(),id:par.id,por:par.por}
            }).done(function( contratos ) {
                if(contratos != false){
                    $().montaOptions(contratos,par.destino);
                    setTimeout(function(){$(par.destino).val(par.documento);},100);
                }
                  
            }).error(function(contratos){

                var select = $(par.destino);
                $('option', select).remove();
            });
       
	};
    $.fn.getdetalhesSemContrato = function(par){
        console.log(par);
         var url = "/despesas-sem-contrato/json/detalhes/" + par.id;
         if (par.id > 0){
             $.ajax({
                type: "GET",
                url: url,
            }).done(function( contratos ) {
                resultado = contratos[0].fields;
                $().propostaEmpenhoSetaValoresContratos(resultado);
                $('.so-com-contrato-selecionado').show();
            }).error(function(contratos){
                console.log(contratos);
            });
        }       
    };
    $.fn.getContratos.defaults = {
        id: $(this).val(),
       
        por : 'id'
    };

    
})( jQuery );