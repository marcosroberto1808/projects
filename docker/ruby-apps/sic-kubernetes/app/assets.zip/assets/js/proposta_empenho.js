(function( $ ){

	$.fn.instrumentoSelecionado = function(){
		var instrumento_despesa = $('#instrumento_despesa').val();
		var num_conta_controle = $('#conta_controle_ano').val();
		var credor = $('#credor').val();
		var id = credor + '|' + num_conta_controle;
		if (instrumento_despesa != '') {
            if(instrumento_despesa == 1){
            	$().getContratos({'por':'credor_cc_despesa','id':id,'destino':'#constratos',})
            	$('#contratos-content').show();
            	var instrumento_despesa_titulo = "Dados do Contrato";
            	$('#titulo_contrato').html('Contrato de Despesa:');
            }else if(instrumento_despesa == 2){
            	$().getSemContrato({'por':'credor_cc','id':id,'destino':'#constratos',})
            	$('#contratos-content').show();
            	var instrumento_despesa_titulo = "Dados da Despesa Sem Contrato";
            	$('#titulo_contrato').html('Despesa sem Contrato:');
            }else {
            	$().getConvenios({'por':'credor_cc_despesa','id':id,'destino':'#constratos',})
            	var instrumento_despesa_titulo = "Dados do Convênio";
            	$('#titulo_contrato').html('Convênio de Despesa:');
            }
            $('#contratos-content').show();
			$('#instrumento_despesa_titulo').html(instrumento_despesa_titulo);
		}else{
        	$('#instrumento_despesa').val(null);
            $('#contratos-content').hide();
            $().limpaOptions('#cod_reduzido_dotacao, #item_despesa, #constratos');
            $().soComContratoSelecionado();
        }
	}

	$.fn.instrumentoDesSelecionado = function(){
		var instrumento_receita = $('#instrumento_receita').val();
		var num_conta_controle = $('#conta_controle_ano').val();
		var credor = $('#credor').val();
		var id = credor + '|' + num_conta_controle;
		if (instrumento_receita != '') {
            if(instrumento_receita == 1){
				console.log(instrumento_receita);
            	$().getContratos({'por':'credor_cc_receita','id':id,'destino':'#cod_instrumento_receita',})
            	$('#content-cod_instrumento_receita').show();
            	var instrumento_despesa_titulo = "Contratos";
            }else if(instrumento_receita == 2){
            	$().getSemContrato({'por':'credor_cc_receita','id':id,'destino':'#cod_instrumento_receita',})
            	$('#content-cod_instrumento_receita').show();
            	var instrumento_despesa_titulo = "Convênio";
            }else {
            	$('#instrumento_receita').val(null);
	            $('#content-cod_instrumento_receita').hide();
	            $().limpaOptions('#cod_instrumento_receita');
	            $().soComContratoSelecionado();
            }
            $('#content-cod_instrumento_receita').show();
			$('#titulo_instrumento_receita').html(instrumento_despesa_titulo);
		}else{
        	$('#instrumento_receita').val(null);
            $('#content-cod_instrumento_receita').hide();
            $().limpaOptions('#cod_instrumento_receita');
            $().soComContratoSelecionado();
        }
	}

	$.fn.selecionaContaControle = function(cca){
		$('.contrato-dados input').val('');	
		$('#instrumento_despesa').val('');
		$('#constratos option').remove();
		$('#constratos').val('');
		$().contaControleID({id:$(this).val(),destino:'#cc-instrumento_despesa'});
		$().limpaOptions('#cod_reduzido_dotacao');
		$().limpaOptions('#item_despesa');
		$('#num_conta_controle').ajustaMotivos();
		var d = new Date();
		var n = d.getFullYear();
		var url = '/contas-de-controle/json/cca/cc/' + cca + '/';
		$.ajax({
        	type: "GET",
            url: url
        }).done(function(json) {
        	var verificador = json[0].fields.instrumento_despesa;
            if(verificador != true){
            	$('#num_conta_controle').getDotacaoContrato({tipo:'proposta_empenho',destino:'#cod_reduzido_dotacao',id:cca, intencao:$('#codigo_id').val(),ano:n});
            }
        });
	}

	$.fn.mostraContratos = function(par){
		$('#constratos').val('');
		$('.contrato-dados input').val('');	
		var id = $('#credor').val() + "|" + $('#num_conta_controle').val(), valor = $(this).val();
		if( valor == 'S'){
			if(typeof(par) != "undefined"){
				$().getContratos({id:id,por:'credor_cc',destino: '#constratos',documento:par.documento});
			}else{
				$().getContratos({id:id,por:'credor_cc',destino: '#constratos'});
			}
			$('#contratos-content').show('fast');
			$('#titulo_contrato').html('Contratos :');
			$(this).val('S');
		}else if(valor == 'N'){
			if(typeof(par) != "undefined"){
				$().getSemContrato({id:id,por:'credor_cc',destino: '#constratos',documento:par.documento});
			}else{
				$().getSemContrato({id:id,por:'credor_cc',destino: '#constratos'});
			}
			$('#contratos-content').show('fast');
			$('#titulo_contrato').html('Despesa sem contrato :');
			$(this).val('N');
		
		}else {
			$('#constratos option').remove();
			$('#contratos-content').hide('fast');
			$().limpaOptions('#constratos');
		}
			$().limpaOptions('#cod_reduzido_dotacao');
			$().limpaOptions('#item_despesa');

	}
	

	$.fn.contratoSelecionado = function(par){
		$('.contrato-dados input').val('');	
		resultado = null;
		if($(this).val() == null ){
			var id = par.id;
		}else{
			var id = $(this).val();
		}
		if(id != ''){
			
			var contrato = $('#instrumento_despesa').val();
			if(contrato == 1){
				var tipo = 'contrato';
				$().getdetalhesContrato({id : id });

			}else if(contrato == 2){
				var tipo = 'sem_contrato';
				$().getdetalhesSemContrato({id : id });
			}else if(contrato == 3){
				var tipo = 'convenio';
				$().getdetalhesConvenios({id : id });
			}else{
				return false;
			}
			
			if(typeof(par) == "undefined"){
				setTimeout(function(){$().getDotacaoContrato({tipo:tipo,destino:'#cod_reduzido_dotacao',id:id}); }, 400);
			}else{
				setTimeout(function(){$().getDotacaoContrato({tipo:tipo,destino:'#cod_reduzido_dotacao',id:id,dotacao:par.dotacao,item:par.item,ano:par.abi}); }, 400);			
			}
			
		}else{
			$('.so-com-contrato-selecionado').hide();
			$('input[name="modalidade_licitacao"]').val('');
			$('input[name="modalidade_sem_licitacao"]').val('');
			$('input[name="num_licitacao"]').val('');
			$('input[name="num_dispensa"]').val('');
			$('input[name="cod_dispositivo_legal"]').val('');
			$('#contrato-total_valor').val('');
			$('#contrato-saldo').val('');
			$('#contrato-data_termino').val('');
			$('#contrato-valor_empenhado').val('');
			$('input[name="possui_licitacao"]').val('');
			$('.contrato-modalidade').val('');
			$('#contrato-num_licitacao').val('');
			$('.contrato-modalidade').val('');
			$('#contrato-dispositivo_legal').val('')
			$('#contrato-contrato-num_dispensa').val('')
		}
		setTimeout(function(){ $().propostaEmpenhoSetaValoresContratos(resultado); }, 1000);
		$().limpaOptions("#cod_reduzido_dotacao,#item_despesa")
		
	}

	$.fn.empenhoSelecionado = function(){
		if($(this).val() != ''){
			resultado = null
			$().getdetalhesEmpenho({id : $(this).val()});
			setTimeout(function(){ $().propostaEmpenhoSetaValoresEmpenho(resultado) }, 1000);
		}else{
			$('#valor_ordinario').val('');
			$('#valor_anulado').val('');
			$('#valor_liquidado').val('');
			$('#valor_empenhado').val('');
			$('#valor_suplementado').val('');
			$('#valor_pago').val('');
		}
	}

	$.fn.empenhoSelecionadoNumero = function(){
		if($(this).val() != ''){
			resultado = null
			$().getdetalhesEmpenhoNumero({numero : $(this).val(), ano : $('#ano').val(), unidade : $('[name="cod_unidade_executora"]').val()});
			setTimeout(function(){ $().propostaEmpenhoSetaValoresEmpenho(resultado) }, 1000);
		}else{
			$('#valor_ordinario').val('');
			$('#valor_anulado').val('');
			$('#valor_liquidado').val('');
			$('#valor_empenhado').val('');
			$('#valor_suplementado').val('');
			$('#valor_pago').val('');
		}
	}

	$.fn.propostaEmpenhoSetaValoresEmpenho = function(resultado){
			$('#valor_ordinario').val(number_format(resultado.valor_ordinario,2,',','.'));
			$('#valor_anulado').val(number_format(resultado.valor_anulado,2,',','.'));
			$('#valor_liquidado').val(number_format(resultado.valor_liquidado,2,',','.'));
			$('#valor_empenhado').val(number_format(resultado.valor_empenhado,2,',','.'));
			$('#valor_suplementado').val(number_format(resultado.valor_suplementado,2,',','.'));
			$('#valor_pago').val(number_format(resultado.valor_pago,2,',','.'));	
	}


	$.fn.selecionaNaturezaEmpenho = function(){
		valor = $(this).val();
		$('.empenho-anterior-val').val('');
		if (valor == 'Suplementação' || valor == 'Anulação'){
			$('.empenho-anterior').show();
		}else{
			$('.empenho-anterior').hide();
		}
	}

	$.fn.propostaEmpenhoSetaValoresContratos = function (contrato){
		if(contrato != null){
			console.log(contrato);
			if(typeof(contrato.valor_total) == 'undefined'){
				contrato.valor_total = contrato.valor_inicial;
			}
			$('#contrato-total_valor').val(number_format(contrato.valor_total,2,',','.'));
			$('#contrato-saldo').val(number_format((contrato.valor_total - contrato.valor_empenhado) ,2,',','.'));
			$('#contrato-data_termino').val(timezonaData(contrato.data_termino));
			$('#contrato-valor_empenhado').val(number_format(contrato.valor_empenhado,2,',','.'));
			if(contrato.licitacao == true){
				$('input[name="cod_dispositivo_legal"]').val(contrato.dispositivo_legal);
				$('input[name="num_licitacao"]').val(contrato.num_licitacao);
				$('input[name="num_dispensa"]').val(contrato.num_dispensa);
				$('input[name="modalidade_licitacao"]').val(contrato.modalidade_licitacao);
				$('input[name="possui_licitacao"]').val('True');
				$('.contrato-modalidade').val(contrato.modalidade_licitacao);
				$('#contrato-numero-licitacao').val(contrato.num_licitacao);
				$('.dispensa').hide();
			}else{
				$('.licitacao').hide();
				$('#contrato-saldo').val(number_format((contrato.valor_inicial - contrato.valor_empenhado) ,2,',','.'));
				$('#contrato-total_valor').val(number_format(contrato.valor_inicial,2,',','.'));
				$('input[name="modalidade_sem_licitacao"]').val(contrato.modalidade_dispensa);
				$('#contrato-num_dispensa').val(contrato.num_dispensa);
				$('.contrato-modalidade').val(contrato.modalidade_dispensa);
				$('#contrato-dispositivo_legal').val(contrato.dispositivo_legal);
				$($('#contrato-dispositivo_legal')).getDispositivoLegal();
				$('#contrato-contrato-num_dispensa').val(contrato.num_dispensa);
				$('input[name="possui_licitacao"]').val('False');
				if(contrato.modalidade_dispensa == 'dispensa'){
					$('.contrato-dispensa-label').html('Número da Dispensa');
				}else if(contrato.modalidade_dispensa == 'NÂO SE APLICA'){
					$('.nao-se-aplica').hide('fast');
				}
			}

		}else{
			$($('#constratos')).contratoSelecionado();
		}
	}

	$.fn.ajustaMotivos = function(id){
		var url = '/contas-de-controle/json/cca/cc/' + id + '/';
       	$.ajax({
       		type: "GET",
        	url: url
		}).done(function(json) {
			var tipo = json[0].fields.tipo;
			console.log(tipo)
			$('#motivo option').removeAttr('selected');
			if(tipo == 'FOL'){
				$('#motivo option').hide();
				$('#motivo option[value="FOL"]').show();
				$('#motivo option[value="FOL"]').attr('selected','selected');
				$('#motivo').val('FOL');
			}else if(tipo == 'SUP'){
				$('#motivo option').hide();
				$('#motivo option[value="SUP"]').show();
				$('#motivo option[value="SUP"]').attr('selected','selected');
				$('#motivo').val('SUP');
			}else if(tipo == 'PAG'){
				$('#motivo option').hide();
				$('#motivo option[value=""]').hide();
				$('#motivo option[value="AQU"]').hide();
				$('#motivo option[value="OUT"]').hide();
				$('#motivo option[value="SUP"]').hide();
				$('#motivo option[value="FOL"]').hide();
				$('#motivo option[value="PAG"]').show();
				$('#motivo option[value="PAG"]').attr('selected','selected');
				$('#motivo').val('PAG');
			}else if(tipo == 'OUT'){
				$('#motivo option').hide();
				$('#motivo option[value=""]').show();
				$('#motivo option[value=""]').attr('selected','selected');
				$('#motivo option[value="AQU"]').show();
				$('#motivo option[value="OUT"]').show();
			}else{
				$('#motivo option').removeAttr('selected');
				$('#motivo option').show();
			}
		});
		
	}



	$.fn.iniciaProposta = function(json){
		var documento = json;
		var natureza = $('#natureza'), motivo = $('#motivo'), instrumento_despesa = $('#instrumento_despesa'), intrumento = $('#constratos');
		var url = '/contas-de-controle/json/cca/cc/' + documento[0].fields.conta_controle_ano + '/';
       	$.ajax({
       		type: "GET",
        	url: url
		}).done(function(json) {
			var verificador = json[0].fields.instrumento_despesa;
            if(verificador != true){
            	$('.contrato-dados').hide('fast');
            }
		});
		$(natureza).selecionaNaturezaEmpenho();
		$(motivo).ajustaMotivos();
		
		if(documento[0].fields.cod_instrumento_despesa > 0){
			setTimeout(function(){$(intrumento).contratoSelecionado({id:documento[0].fields.cod_instrumento_despesa,dotacao:documento[0].fields.cod_reduzido_dotacao,item:documento[0].fields.item_despesa})},530);
		}
		$().instrumentoSelecionado();
		// setTimeout(function(){$(instrumento_despesa).mostraContratos({documento:documento[0].fields.cod_instrumento_despesa});},411);
		setTimeout(function(){$().setValores(documento[0].fields);},300);
		setTimeout(function(){$().setValores(documento[0].fields);},2000);
		setTimeout(function(){$($('#contrato-dispositivo_legal')).getDispositivoLegal();},2100);
		setTimeout(function(){$($('#cod_reduzido_dotacao')).getItens({destino:'#item_despesa',item:documento[0].fields.item_despesa,ano:documento[0].fields.ano_exercicio});},2100);
		var d = new Date();
		var n = d.getFullYear();
		setTimeout(function(){$("#ano").val(n);},2200);

	}

    
    $.fn.getDispositivoLegal = function(){
        var url = '/core/json/dispositivoslegais/' + $(this).val() + '/';
       	$.ajax({
       		type: "GET",
        	url: url
		}).done(function(json) {
			$('#contrato-dispositivo_legal').val(json[0].fields.titulo);
		});
    };

    $.fn.modalVerificacoesRegras = function(par){        
        var proposta = par;
        $.ajax({
            type: "GET",
            url: "/propostas-de-empenho/verificacoes/",
            data: {'id': proposta}
        }).done(function(json) {
        	var dados_proposta = json.dados_proposta
        	var dados_contrato = json.dados_contrato
        	var dados_dsc = json.dados_dsc
        	var dados_intencao = json.dados_intencao
        	var dados_conta = json.dados_conta
        	var validador = json.validador
        	var error = json.error
            if (!!dados_proposta && !!dados_proposta.regras) {
                populaRegras('#pnlPropostaEmpenho', ".title-proposta", "#listaRegrasProposta", "Proposta de Empenho", dados_proposta);    
            }else{
            	$('#pnlPropostaEmpenho').hide()
            }
        	if (!!dados_contrato && !!dados_contrato.regras) {
                populaRegras('#pnlContrato', ".title-contrato", "#listaRegrasContrato", "Contrato", dados_contrato);    
            }else{
            	$('#pnlContrato').hide()
            };
            if (!!dados_dsc && !!dados_dsc.regras) {
                populaRegras('#pnlDespesa', ".title-despesa", "#listaRegrasDespesa", "Despesa sem Contrato", dados_dsc);    
            }else{
            	$('#pnlDespesa').hide()
            }       	
        	if (!!dados_conta && !!dados_conta.regras) {
                populaRegras('#pnlConta', ".title-conta", "#listaRegrasConta", "Conta de Controle", dados_conta);    
            }else{
            	$('#pnlConta').hide()
            }
            if (!!dados_intencao && !!dados_intencao.regras) {
                populaRegras('#pnlIntencao', ".title-intencao", "#listaRegrasIntencao", "Intenção de Despesa", dados_intencao);    
            }else{
            	$('#pnlConta').hide()
            }
        });
    };

    $.fn.soComContratoSelecionado = function(){
    	$('.so-com-contrato-selecionado').hide();
    	$('.so-com-contrato-selecionado input').val('');
    }

})(jQuery)

function populaRegras (pnl, title, list, text, dados){
    if (dados){
		$(pnl).show()
		$(title).text( text+' ( Número: '+ dados.id +' )')
		$(list+" tr").remove(); 
		lstRegras = dados.regras
        for (regra in lstRegras) {
            var badge = ''
            var valor = ''
            if (lstRegras[regra]){
                badge = 'check-sucesso'
                valor = 'Sim'
            }else {
                badge = 'check-danger'
                valor = 'Não'   
            }
            $(list).append('<tr><td>'+ regra +'</td><td><span class="check '+ badge +'">'+valor+'</span></td></tr');   
        }   
	}else{
		$(pnl).hide()
	}
}
