(function( $ ){
    $.fn.alteraiconesdalistagem = function(par){
       $('#tbContas tbody tr').each(function(){
        var contaId = $(this).find('#id_conta').val();
        $.ajax({
            type: "GET",
            url: "/contas-de-controle/verificacoes/",
            data: {'id': contaId}
        }).done(function(json) {
            var result = json.validador;
            var icon = '#btnverificacao-' + contaId + ' i';
            if(result){
                $(icon).addClass('fa fa-check fa-1g');
            }else{
                $(icon).addClass('fa fa-exclamation fa-1g');
            }
        });
    });
    };

    $.fn.contaControleID = function(par){        
        var url = '/contas-de-controle/json/detalhes/' + par.id;
        $.ajax({
            type: "GET",
            url: url
        }).done(function(json) {
            $(par.destino).val(json[0].fields.instrumento_despesa);
        });
    };

    $.fn.modalVerificacoesRegras = function(par){        
        var conta = par;
        $.ajax({
            type: "GET",
            url: "/contas-de-controle/verificacoes/",
            data: {'id': conta}
        }).done(function(json) {
           $("#listaRegras tr").remove();
           lstRegras = json.regras;
            for (regra in lstRegras) {
                var badge = ''
                var valor = ''
                if (lstRegras[regra]){
                    badge = 'bg-green'
                    valor = 'Sim'
                }else {
                    badge = 'bg-red'
                    valor = 'Não'   
                }

                $('#listaRegras').append('<tr><td>'+ regra +'</td><td><span class="badge '+ badge +'">'+valor+'</span></td></tr');   
            };
        });
    };
})( jQuery );