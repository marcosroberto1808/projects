$(document).ready(function() {
	$.ajax({
		type: "POST",
		url: "/pesquisar_requisicao",
		data: { entrada_id: ($("#entrada_id").val()), numero_requisicao: ($("#numero_requisicao").val()), }
	});
});