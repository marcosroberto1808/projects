$(document).ready(function(){
	$(".campo_data").each(function (){
		var theDate;
 
	  if ($(this).val() != "" && $(this).val() != null) {
	      theDate = $(this).val();
	  }

	  $( this ).datepicker();
		$( this ).datepicker("option", "dateFormat", "dd/mm/yy");
		$( this ).datepicker("setDate", theDate);
	});
});
