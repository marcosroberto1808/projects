$(function() {
	$( "#material" ).focusout(function() {
		$.ajax({
			type: "POST",
			url: "/show_material_info",
			data: { material_descricao: $("#material").val() }
		})
	});
});