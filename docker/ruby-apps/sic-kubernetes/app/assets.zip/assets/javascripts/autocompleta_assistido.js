$(function() {
	$( "#assistido" ).focusin(function() {
		$("#assistido").autocomplete({
			source: "/json_autocomplete_assistido",
			minLength: 2
		});
	});

	$( "#assistido_notificacao" ).focusin(function() {
		$("#assistido_notificacao").autocomplete({
			source: "/json_autocomplete_assistido_notificacao",
			minLength: 2
		});
	});	
});