$(function() {
	$( "#material:visible" ).focusin(function() {
		$("#material").autocomplete({
			source: "/json_autocomplete_material",
			minLength: 2
		});

		$("#adicionar_material_submit").prop('disabled', true);
		$("#adicionar_material_submit").attr('class', 'btn-disabled');
	});

	$( "#material:visible" ).focusout(function() {
		$.ajax({
			type: "POST",
			url: "/autocomplete_material_check",
			data: { material_descricao: $("#material").val() }
		})

		.done(function( msg ) {
			if(msg == 'true'){
				
				$.ajax({
					type: "POST",
					url: "/valor_medio_material_check",
					data: { material_descricao: $("#material").val() }
				})

				.done(function( msg ) {
					if(msg == 'true'){
						$("#field_valor_medio:visible").hide();		
						$("#valor_medio").val('');		
						$("#adicionar_material_submit").prop('disabled', false);				
						$("#adicionar_material_submit").attr('class', 'btn');
					}else{
						$("#field_valor_medio").show();
					}			
				});
			
			}else{
				$("#adicionar_material_submit").prop('disabled', true);
				$("#adicionar_material_submit").attr('class', 'btn-disabled');
				if ($("#material").val() != "") {
					alert("Material não encontrado, favor verificar.");
				}	
			}			
		});
	});

	$( "#valor_medio" ).keyup(function() {
		if ($("#valor_medio").val() == "") {
			$("#adicionar_material_submit").prop('disabled', true);
			$("#adicionar_material_submit").attr('class', 'btn-disabled');
		}else{
			$("#adicionar_material_submit").prop('disabled', false);				
			$("#adicionar_material_submit").attr('class', 'btn');
		}
	});
});