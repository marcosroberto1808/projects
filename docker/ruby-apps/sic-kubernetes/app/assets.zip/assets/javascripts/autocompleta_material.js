$(function() {
	$( "#material" ).focusin(function() {
		$("#material").autocomplete({
			source: "/json_autocomplete_material",
			minLength: 2
		});

		$("#adicionar_material_submit").prop('disabled', true);
		$("#adicionar_material_submit").attr('class', 'btn-disabled');
	});

	$( "#material" ).focusout(function() {
		$.ajax({
			type: "POST",
			url: "/autocomplete_material_check",
			data: { material_descricao: $("#material").val() }
		})

		.done(function( msg ) {
			if(msg == 'true'){
				$("#adicionar_material_submit").prop('disabled', false);				
				$("#adicionar_material_submit").attr('class', 'btn');
				//Relatórios
				$("#btn_relatorio").prop('disabled', false);				
				$("#btn_relatorio").attr('class', 'btn');				
			}else{
				$("#adicionar_material_submit").prop('disabled', true);
				$("#adicionar_material_submit").attr('class', 'btn-disabled');
				//Relatórios
				$("#btn_relatorio").prop('disabled', true);
				$("#btn_relatorio").attr('class', 'btn-disabled');
				if ($("#material").val() == "") {
					$("#btn_relatorio").prop('disabled', false);				
					$("#btn_relatorio").attr('class', 'btn');
				}
				if ($("#material").val() != "") {
					alert("Material não encontrado, favor verificar.");
				}	
			}			
		});
	});
});