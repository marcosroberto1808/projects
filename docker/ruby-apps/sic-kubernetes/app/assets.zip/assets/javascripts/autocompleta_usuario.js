$(function() {
	$( "#usuario" ).focusin(function() {
		$("#usuario").autocomplete({
			source: "/json_autocomplete_usuario",
			minLength: 2
		});
	});
});
