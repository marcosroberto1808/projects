	var f = jQuery.noConflict();
		f(function() {
			 f('#flash').delay(500).fadeIn('normal', function() {
				  f(this).delay(2500).fadeOut();
			 });
		});
