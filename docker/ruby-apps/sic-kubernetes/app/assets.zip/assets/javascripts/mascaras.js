//Exemplo de criação de máscaras
/*
    $('.date').mask('11/11/1111');
    $('.time').mask('00:00:00');
    $('.date_time').mask('00/00/0000 00:00:00');
    $('.cep').mask('00000-000');
    $('.phone').mask('0000-0000');
    $('.phone_with_ddd').mask('(00) 0000-0000');
    $('.phone_us').mask('(000) 000-0000');
    $('.mixed').mask('AAA 000-S0S');
    $('.cpf').mask('000.000.000-00', {reverse: true});
    $('.money').mask('000.000.000.000.000,00', {reverse: true});


$(document).ready(function(){
    $('.inteiro').mask('##', {reverse: true, maxlength: false});
    $('.monetario').mask('##.00', {reverse: true, maxlength: false});
    $('.decimal').mask('##.0000', {reverse: true, maxlength: false});
    $('.cnpj').mask('99.999.999/9999-99')
    $('.cep').mask('00000-000');
    $('.telefone').mask('(00) 0000-0000');
    $('.cpf').mask('000.000.000-00', {reverse: true});
    $('.campo_data').mask('00/00/0000');
});
*/
// Modal Panel

function modalPanel(comp,url)
{
    $(comp).colorbox({width:"80%", height:"80%", iframe:true,href:url})
}

function modalPanel(comp,url,largura,altura)
{
    $(comp).colorbox({width:largura+"%", height:altura+"%", iframe:true,href:url})
}

// Máscaras

function mascara(o,f)
{
    v_obj=o;
    v_fun=f;
    setTimeout("execmascara()",1)
}

function execmascara()
{
    v_obj.value=v_fun(v_obj.value)
}

function formatacaoData(v) {
    v=v.replace(/\D/g,"")
    v=v.replace(/(\d{2})(\d)/,"$1/$2")
    v=v.replace(/(\d{2})(\d)/,"$1/$2")
    return v
}

function formatacaoHora(v) {
    v=v.replace(/\D/g,"")
    v=v.replace(/(\d{2})(\d)/,"$1:$2")
    //v=v.replace(/(\d{2})(\d)/,"$1$2")
    return v
}

function formatacaoTelefone(v)
{
    v=v.replace(/\D/g,"")                   // Remove tudo o que não é dígito
    v=v.replace(/^(\d\d)(\d)/g,"($1) $2")   // Coloca parênteses em volta dos dois primeiros dígitos
    v=v.replace(/(\d{4})(\d)/,"$1-$2")      // Coloca hífen entre o quarto e o quinto dígitos
    return v
}

// Com formatação para a casa de milhar, somente números inteiros
function formatacaoQuantidadeComMilhar(v)
{
    v=v.replace(/\D/g,"")           // Permite digitar apenas números
    v=v.replace(/(\d{1})(\d{9})$/,"$1.$2")      // Coloca ponto antes dos últimos 9 digitos
    v=v.replace(/(\d{1})(\d{6})$/,"$1.$2")      // Coloca ponto antes dos últimos 6 digitos
    v=v.replace(/(\d{1})(\d{3})$/,"$1.$2")      // Coloca ponto antes dos últimos 3 digitos
    return v
}

// Sem formatação para a casa de milhar
function formatacaoQuantidade(v)
{
    v=v.replace(/\D/g,"")           // Permite digitar apenas números
    v=v.replace(/(\d{1})(\d{1,4})$/,"$1.$2")    // Coloca virgula antes dos últimos 4 digitos
    return v
}

// Sem formatação para a casa de milhar
function formatacaoQuantidade2CasasDecimais(v)
{
    v=v.replace(/\D/g,"")           // Permite digitar apenas números
    v=v.replace(/(\d{1})(\d{1,2})$/,"$1.$2")    // Coloca virgula antes dos últimos 2 digitos
    return v
}

function formatacaoMonetaria(v)
{
    v=v.replace(/\D/g,"")           // Permite digitar apenas números
    v=v.replace(/[0-9]{12}/,"inválido")     // Limita pra máximo 999.999.999,99
    v=v.replace(/(\d{1})(\d{8})$/,"$1.$2")      // Coloca ponto antes dos últimos 8 digitos
    v=v.replace(/(\d{1})(\d{5})$/,"$1.$2")      // Coloca ponto antes dos últimos 5 digitos
    v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2")    // Coloca virgula antes dos últimos 2 digitos
    return v
}

//Autor: Edivan
function limpaCampo(v)
{
    return v = ""
}

//Autor: Edivan
function somenteDigitos(v)
{
    return v.replace(/\D/g,"") //Remove tudo o que não é dígito
}

function somenteLetras(v)
{
    return v.replace(/\d/g,"") //Remove tudo o que não é dígito
}

function formatacaoCNPJ(v){
    v=v.replace(/\D/g,"")                           //Remove tudo o que não é dígito
    v=v.replace(/^(\d{2})(\d)/,"$1.$2")             //Coloca ponto entre o segundo e o terceiro dígitos
    v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3") //Coloca ponto entre o quinto e o sexto dígitos
    v=v.replace(/\.(\d{3})(\d)/,".$1/$2")           //Coloca uma barra entre o oitavo e o nono dígitos
    v=v.replace(/(\d{4})(\d)/,"$1-$2")              //Coloca um hífen depois do bloco de quatro dígitos
    return v
}

function formatacaoCPF(v)
{
   v=v.replace(/\D/g,"")                                       //Remove tudo o que não é dígito
   v=v.replace(/^(\d{3})(\d)/,"$1.$2")                         //Coloca ponto entre o terceiro e o quarto dígitos
   v=v.replace(/^(\d{3})\.(\d{3})(\d)/,"$1.$2.$3")             //Coloca ponto entre o sexto e o sétimo dígitos
   v=v.replace(/^(\d{3})\.(\d{3}).(\d{3})(\d)/,"$1.$2.$3-$4")  //Coloca um hífen depois dos 3 blocos de 3 dígitos
   return v
}

function formatacaoMATRIC(v)
{
   v=v.replace(/\D/g,"")                                       //Remove tudo o que não é dígito
   v=v.replace(/^(\d{3})(\d)/,"$1.$2")                         //Coloca ponto entre o terceiro e o quarto dígitos
   v=v.replace(/^(\d{3})\.(\d{3})(\d)/,"$1.$2-$3")             //Coloca um hífen entre o sexto e o sétimo dígitos
   v=v.replace(/^(\d{3})\.(\d{3})\-(\d{1})(\d)/,"$1.$2-$3-$4") //Coloca um hífen depois do bloco de quatro dígitos
   return v
}

function formatacaoCep(v)
{
   v=v.replace(/\D/g,"")                                       //Remove tudo o que não é dígito
   v=v.replace(/^(\d{5})(\d)/,"$1-$2")                         //Coloca hífen entre o quinto e o sexto dígitos
   return v
}

function formatacaoMoeda(v) {
    v=v.replace(/\D/g,"")  //permite digitar apenas números
    v=v.replace(/[0-9]{12}/,"inválido")   //limita pra máximo 999999999.99
    v=v.replace(/(\d{1})(\d{2})$/,"$1.$2")  //coloca ponto antes dos últimos 2 digitos
    //v=v.replace(/(\d{1})(\d{8})$/,"$1.$2")  //coloca ponto antes dos últimos 8 digitos
    //v=v.replace(/(\d{1})(\d{5})$/,"$1.$2")  //coloca ponto antes dos últimos 5 digitos
    //v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2")    //coloca virgula antes dos últimos 2 digitos
    //v= "R$ "+v
    return v
}

function formataCampoMoeda(evt, src, mascara)
{

    if(mascara != 'moeda')
    {
        var tecla = (window.event)?evt.keyCode:evt.which;
        var i = src.value.length;
        if(teclasAceitas.indexOf(tecla) == -1)
        {
                if(!VerificaTecla(tecla, mascara.charAt(i)) || i >= mascara.length)
                {
                        return false;
                }
                else if(separadores.indexOf(mascara.charAt(i)) > -1)
                {
                        if(!VerificaTecla(tecla, mascara.charAt(i+1)))
                        {
                            return false;
                        }
                        else
                        {
                            src.value += mascara.charAt(i);
                        }
                }
                src.value += String.fromCharCode(tecla);
                return false;
        }
        else
        {
            return true;
        }
    }
    else
    {

        var sep = 0;
        var decSep = ',';
        var milSep = '.';
        var key = '';
        var i = j = 0;
        var len = len2 = 0;
        var strCheck = '0123456789';
        var aux = aux2 = '';
        var whichCode = (window.Event) ? evt.which : evt.keyCode;

           if (whichCode == 13) return false;  // Enter
         // alert(wichCode);

        if (whichCode == 8)
        {
            key = src.value.substr(src.value.length-2, 1);
            //alert('key='+key);
            src.value = src.value.substr(0, src.value.length - 2);
        }
        else
        {
            key = String.fromCharCode(whichCode);  // Get key value fromkey code
            //alert('key='+key);
        }

        if (strCheck.indexOf(key) == -1) return false;  // Not a valid key
        len = src.value.length;
        for(i = 0; i < len; i++)
            if ((src.value.charAt(i) != '0') && (src.value.charAt(i) != decSep)) break;
        aux = '';
        for(; i < len; i++)
            if (strCheck.indexOf(src.value.charAt(i))!=-1) aux += src.value.charAt(i);
        aux += key;
        len = aux.length;

        //if (len == 0) src.value = '';
        //if (len == 1) src.value = '0'+ decSep + '0' +'0'+'0' + aux;
        //if (len == 2) src.value = '0'+ decSep + '0' +'0'+ aux;
        //if (len == 3) src.value = '0'+ decSep + '0' + aux;
        //if (len == 4) src.value = '0'+ decSep + aux;

        //if (len > 4)
        //{
        //    aux2 = '';
        //    for (j = 0, i = len - 5; i >= 0; i--)
        //    {
        //        if (j == 3)
        //        {
        //            aux2 += milSep;
        //           j = 0;
        //        }
        //        aux2 += aux.charAt(i);
        //        j++;
        //    }
        //    src.value = '';
        //    len2 = aux2.length;
        //    for (i = len2 - 1; i >= 0; i--)
        //       src.value += aux2.charAt(i);
        //    src.value += decSep + aux.substr(len - 4, len);
        //}
        
        //if (len == 0) src.value = '';
        //if (len == 1) src.value = '0'+ decSep + '0' +'0'+'0' + aux;
        //if (len == 2) src.value = '0'+ decSep + '0' +'0'+ aux;
        //if (len == 3) src.value = '0'+ decSep + '0' + aux;
        //if (len == 4) src.value = '0'+ decSep + aux;

                if (len == 1) src.value = '0'+ decSep + '0' + aux;
        if (len == 2) src.value = '0'+ decSep + aux;

        if (len > 2)
        {
            aux2 = '';
            for (j = 0, i = len - 3; i >= 0; i--)
            {
                if (j == 3)
                {
                    aux2 += milSep;
                    j = 0;
                }
                aux2 += aux.charAt(i);
                j++;
            }
            src.value = '';
            len2 = aux2.length;
            for (i = len2 - 1; i >= 0; i--)
               src.value += aux2.charAt(i);
            src.value += decSep + aux.substr(len - 2, len);
        }

        return false;
    }
}

function arredonda( valor , casas ){
   var novo = Math.round( valor * Math.pow( 10 , casas ) ) / Math.pow(
10 , casas );
   return( novo );
}

function float2moeda(num) {

   var separacaoPonto = num.toString().split(".");
   var cents = separacaoPonto[1];
   var centsTam = 0;

   if(typeof cents == 'undefined' || cents == 0)
   {
           cents = "0000";
   }
   else
   {
           centsTam = cents.toString().length;
           if(centsTam != 4)
           {
               if(centsTam == 1)
                   cents+="000";
               if(centsTam == 2)
                   cents+="00";
               if(centsTam == 3)
                   cents+="0";
           }
   }


   var reais = separacaoPonto[0];
   var tamanho = reais.toString().length-1;
   var contador = 0;
   var numeroinicial = "";

   for(var i=tamanho;i>=0;i--)
   {

           if(contador==3)
           {
               numeroinicial +='.';
               contador = 0;
           }
           numeroinicial += reais.substring(i+1,i);
           contador++;
   }
   var tamanhoNumeroFinal = numeroinicial.toString().length;
   var numerofinal = "";


   for(var i=tamanhoNumeroFinal; i>=0;i--)
   {
           numerofinal += numeroinicial.substring(i+1,i);
   }

    numerofinal+=','+cents;

    if(num==0)
           numerofinal = '0,0000';

    return numerofinal;
}

function replaceAllFormatoAmericano(valor){
    if(valor != '') {
        while(valor.lastIndexOf('.') != -1){
            valor =  valor.replace('.','');
        }
        valor = valor.replace(',','.');
    }
    return valor;
}

// função utilizada do site http://www.htmlstaff.org/ver.php?id=7836
// função genérica utilizada para mascara
// o formato é declarado na view  com ":onkeypress=>"formatar_mascara(this, '#######-##.####.#.##.####')"
// ex :onkeypress=>"formatar_mascara(this, '###.###.###-##')

function formatar_mascara(src, mascara) {
    var campo = src.value.length;
    var saida = mascara.substring(0,1);
    var texto = mascara.substring(campo);
    if(texto.substring(0,1) != saida) {
        src.value += texto.substring(0,1);
    }
}




(function($){
    $('.inteiro').mask('##', {reverse: true, maxlength: false});
    $('.monetario').mask('##.00', {reverse: true, maxlength: false});
    $('.decimal').mask('##.0000', {reverse: true, maxlength: false});
    $('.cnpj').mask('99.999.999/9999-99')
    $('.cep').mask('00000-000');
    $('.telefone').mask('(00) 0000-0000');
    $('.cpf').mask('000.000.000-00', {reverse: true});
    $('.campo_data').mask('00/00/0000');
})(jQuery);