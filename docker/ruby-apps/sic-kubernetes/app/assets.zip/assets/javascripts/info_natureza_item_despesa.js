$(function() {
	$( "#material_codigo" ).focusout(function() {
		$.ajax({
			type: "POST",
			url: "/show_natureza_item_despesa",
			data: { item_despesa_codigo: ($("#material_codigo").val()) }
		})	
	});
});
