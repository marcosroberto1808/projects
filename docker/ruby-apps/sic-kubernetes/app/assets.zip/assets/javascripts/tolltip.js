$(function() {
	$( document ).tooltip();
});