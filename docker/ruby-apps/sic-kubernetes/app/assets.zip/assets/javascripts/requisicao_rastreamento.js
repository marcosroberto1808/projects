$(document).ready(function(){
	$("#codigo_rastreamento").click(function (){
		var codigo = $("#codigo_rastreamento").attr("value");
		window.open("http://websro.correios.com.br/sro_bin/txect01$.Inexistente?P_LINGUA=001&P_TIPO=002&P_COD_LIS="+codigo,null, "height=200,width=400,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes");
	});
});