function editar_assistido(){
  $("#botao_editar").hide();
  $("#botao_editar_concluir").css("display", "inline-block");
  $("#excluir").css("display", "inline-block");
  $("#avatar").show();
  $('[id="btn_exluir_doc_pes"]').show();     
  $('[id="btn_exluir_doc_extra"]').show();     
  $('[id="minimizar"]').hide();
  $('[id="editar"]').show();
  $('[id="processo_judicial_item"]').addClass("processo_judicial_item");
  $('[id="processo_judicial_item"]').css("pointer-events", "auto");
  $('[id="inquerito_policial_item"]').addClass("inquerito_policial_item");
  $('[id="inquerito_policial_item"]').css("pointer-events", "auto");    
}

function editar_assistido_concluir(){
  $("#botao_editar_concluir").hide();
  $("#botao_editar").show();
  $('[id="minimizar"]').show();
  $('[id="editar"]').hide();
  $("#excluir").hide();
  $("#avatar").hide();
  $('[id="btn_exluir_doc_pes"]').hide();     
  $('[id="btn_exluir_doc_extra"]').hide();  
  $('[id="processo_judicial_item"]').removeClass("processo_judicial_item");
  $('[id="processo_judicial_item"]').css("pointer-events", "none");
  $('[id="inquerito_policial_item"]').removeClass("inquerito_policial_item");
  $('[id="inquerito_policial_item"]').css("pointer-events", "none");
  $("#painel_situacao").show();

  if ($("#painel_resumo").attr('class') == "panel panel-info")
  {
    $("#painel_resumo").removeClass("panel panel-info");
    $("#painel_resumo").addClass("panel panel-success");
    $("#painel_resumo").show();
    $("#resumo_form").hide(); 
    $("#resumo").show();
  }

  {
    $("#bloco_situacao").show();
    $("#situacao_form").hide();   
  } 

  if ($("#painel_socioeconomicas").attr('class') == "panel panel-info")
  {
    $("#painel_socioeconomicas").removeClass("panel panel-info");
    $("#painel_socioeconomicas").addClass("panel panel-success");
    $("#painel_socioeconomicas").show();
    $("#socioeconomicas_form").hide(); 
    $("#socioeconomicas").show();
  }  

  if ($("#painel_dados_pessoais").attr('class') == "panel panel-info")
  {
    $("#painel_dados_pessoais").removeClass("panel panel-info");
    $("#painel_dados_pessoais").addClass("panel panel-success");
    $("#painel_dados_pessoais").show();
    $("#dados_pessoais_form").hide(); 
    $("#dados_pessoais").show();
  }      
}

function minimizar_bloco(bloco,img){
  if ($("#"+bloco).css('display') == "block")
  {
    $(img).attr("src","/assets/glyphicons/glyphicons_367_expand.png");
    $("#"+bloco).hide();
  } else {
    $(img).attr("src","/assets/glyphicons/glyphicons_369_collapse_top.png");            
    $("#"+bloco).show();
  }
}

function editar_bloco(bloco){
  if ($("#painel_"+bloco).attr('class') == "panel panel-success")
  {
    $("#painel_"+bloco).removeClass("panel panel-success");
    $("#painel_"+bloco).addClass("panel panel-info");
    $("#"+bloco).hide();
    $("#"+bloco+"_form").show();
  } else {
    $("#painel_"+bloco).removeClass("panel panel-info");
    $("#painel_"+bloco).addClass("panel panel-success");
    $("#painel_"+bloco).show();
    $("#"+bloco+"_form").hide();      
  }
}

function editar_situacao(){
  if ($("#bloco_situacao").is(":visible") == true)
  {
    $("#bloco_situacao").hide();
    $("#situacao_form").show();
  } else {
    $("#bloco_situacao").show();
    $("#situacao_form").hide();   
  }
}

function maximizar_bloco(bloco){
  bloco.show();
}

function editar_processo_judicial(id){
  window.location.href = "/processo_judiciais/"+id+"/edit";
}

function editar_inquerito_policial(id){
  window.location.href = "/inquerito_policiais/"+id+"/edit";
}
