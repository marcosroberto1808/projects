$(document).ready(function(){
    checkDrogas();
    checkTratamento();
    checkSaude();
    checkAtividades();
    checkEmpregado();
});

function checkDrogas(){
  $('input[id="drogas"]').change(function() {
    if($(this).is(":checked")) {
      $("#hiden_drogas").show();
    } 
    else{
      $("#hiden_drogas").hide();
    }
  }).trigger('change');
}

function checkTratamento(){
  $('input[id="tratamento"]').change(function() {
    if($(this).is(":checked")) {
      $("#hiden_tratamento").show();
    } 
    else{
      $("#hiden_tratamento").hide();
    }
  }).trigger('change');
}

function checkSaude(){
  $('input[id="saude"]').change(function() {
    if($(this).is(":checked")) {
      $("#hiden_saude").show();
    } 
    else{
      $("#hiden_saude").hide();
    }
  }).trigger('change');
}

function checkAtividades(){
  $('input[id="atividades"]').change(function() {
    if($(this).is(":checked")) {
      $("#hiden_atividades").show();
    } 
    else{
      $("#hiden_atividades").hide();
    }
  }).trigger('change');
}

function checkEmpregado(){
  $('input[id="empregado"]').change(function() {
    if($(this).is(":checked")) {
      $("#hiden_empregado").show();
    } 
    else{
      $("#hiden_empregado").hide();
    }
  }).trigger('change');
}