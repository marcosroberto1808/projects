$(document).ready(function(){
  checkAcompanhar();
  natureza = $("input[name='processo_judicial[natureza]']:checked").val()
  if (natureza == "Ação Penal"){
    $("#div_tipo").hide();
    $("#div_tipo2").hide();    
    $("#acao_penal").show();      
  }else if (natureza == "Execução Penal"){
    $("#div_tipo").show();
    $("#div_tipo2").show();    
    $("#acao_penal").hide();
  }
});

function checkNatureza(){
  natureza = $("input[name='processo_judicial[natureza]']:checked").val();
  if (natureza == "Ação Penal"){
    $("#div_tipo").hide();
    $("#div_tipo2").hide();    
    $("#acao_penal").show();      
  } else {
    $("#div_tipo").show();
    $("#div_tipo2").show();    
    $("#acao_penal").hide();  
  }
}

function checkAcompanhar(){
  $('#acompanhar_processo').change(function() {
    if($(this).is(":checked")) {
      $("#lotacao").show();
    } 
    else{
      $("#lotacao").hide();
    }
  });
}