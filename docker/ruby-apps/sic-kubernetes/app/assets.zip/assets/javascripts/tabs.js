$(document).ready( $(function() {
	$( "#tabs" ).tabs({
		beforeLoad: function( event, ui ) {
			ui.jqXHR.error(function() {
				ui.panel.html(
				"Ocorreu algum problema, por favor recarregue a página." );
			});
		},
		activate: function(event, ui) {
      ui.oldPanel.empty();
    }
	});
}));