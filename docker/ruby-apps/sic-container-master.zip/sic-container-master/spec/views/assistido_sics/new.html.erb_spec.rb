require 'rails_helper'

RSpec.describe "assistido_sics/new", type: :view do
  before(:each) do
    assign(:assistido_sic, AssistidoSic.new(
      :nome => "MyString",
      :cpf => "MyString",
      :estado_civil => "MyString",
      :cep => "MyString",
      :logradouro => "MyString",
      :numero => "MyString",
      :complemento => "MyString",
      :bairro => "MyString",
      :cidade => "MyString",
      :uf => "MyString",
      :profissao => "MyString",
      :nome_social => "MyString",
      :rg => "MyString",
      :orgao_emissor => "MyString",
      :nome_pai => "MyString",
      :nome_mae => "MyString",
      :nacionalidade => "MyString",
      :telefone => "MyString",
      :telefone => "",
      :telefone_tres => "MyString",
      :observacao => "MyText",
      :contato_nome => "MyString",
      :contato_telefone => "MyString",
      :contato_tipo_vinculo => "MyString",
      :contato_email => "MyString",
      :resumo => "MyText",
      :sexo => "MyString",
      :imagem_url => "MyString",
      :historico_delito_atual => "MyText",
      :antecedentes_criminais => "MyText",
      :pretensoes_futuras => "MyText",
      :observacoes_complementares => "MyText",
      :id_importacao_sejus => 1,
      :ativo => false
    ))
  end

  it "renders new assistido_sic form" do
    render

    assert_select "form[action=?][method=?]", assistido_sics_path, "post" do

      assert_select "input#assistido_sic_nome[name=?]", "assistido_sic[nome]"

      assert_select "input#assistido_sic_cpf[name=?]", "assistido_sic[cpf]"

      assert_select "input#assistido_sic_estado_civil[name=?]", "assistido_sic[estado_civil]"

      assert_select "input#assistido_sic_cep[name=?]", "assistido_sic[cep]"

      assert_select "input#assistido_sic_logradouro[name=?]", "assistido_sic[logradouro]"

      assert_select "input#assistido_sic_numero[name=?]", "assistido_sic[numero]"

      assert_select "input#assistido_sic_complemento[name=?]", "assistido_sic[complemento]"

      assert_select "input#assistido_sic_bairro[name=?]", "assistido_sic[bairro]"

      assert_select "input#assistido_sic_cidade[name=?]", "assistido_sic[cidade]"

      assert_select "input#assistido_sic_uf[name=?]", "assistido_sic[uf]"

      assert_select "input#assistido_sic_profissao[name=?]", "assistido_sic[profissao]"

      assert_select "input#assistido_sic_nome_social[name=?]", "assistido_sic[nome_social]"

      assert_select "input#assistido_sic_rg[name=?]", "assistido_sic[rg]"

      assert_select "input#assistido_sic_orgao_emissor[name=?]", "assistido_sic[orgao_emissor]"

      assert_select "input#assistido_sic_nome_pai[name=?]", "assistido_sic[nome_pai]"

      assert_select "input#assistido_sic_nome_mae[name=?]", "assistido_sic[nome_mae]"

      assert_select "input#assistido_sic_nacionalidade[name=?]", "assistido_sic[nacionalidade]"

      assert_select "input#assistido_sic_telefone[name=?]", "assistido_sic[telefone]"

      assert_select "input#assistido_sic_telefone[name=?]", "assistido_sic[telefone]"

      assert_select "input#assistido_sic_telefone_tres[name=?]", "assistido_sic[telefone_tres]"

      assert_select "textarea#assistido_sic_observacao[name=?]", "assistido_sic[observacao]"

      assert_select "input#assistido_sic_contato_nome[name=?]", "assistido_sic[contato_nome]"

      assert_select "input#assistido_sic_contato_telefone[name=?]", "assistido_sic[contato_telefone]"

      assert_select "input#assistido_sic_contato_tipo_vinculo[name=?]", "assistido_sic[contato_tipo_vinculo]"

      assert_select "input#assistido_sic_contato_email[name=?]", "assistido_sic[contato_email]"

      assert_select "textarea#assistido_sic_resumo[name=?]", "assistido_sic[resumo]"

      assert_select "input#assistido_sic_sexo[name=?]", "assistido_sic[sexo]"

      assert_select "input#assistido_sic_imagem_url[name=?]", "assistido_sic[imagem_url]"

      assert_select "textarea#assistido_sic_historico_delito_atual[name=?]", "assistido_sic[historico_delito_atual]"

      assert_select "textarea#assistido_sic_antecedentes_criminais[name=?]", "assistido_sic[antecedentes_criminais]"

      assert_select "textarea#assistido_sic_pretensoes_futuras[name=?]", "assistido_sic[pretensoes_futuras]"

      assert_select "textarea#assistido_sic_observacoes_complementares[name=?]", "assistido_sic[observacoes_complementares]"

      assert_select "input#assistido_sic_id_importacao_sejus[name=?]", "assistido_sic[id_importacao_sejus]"

      assert_select "input#assistido_sic_ativo[name=?]", "assistido_sic[ativo]"
    end
  end
end
