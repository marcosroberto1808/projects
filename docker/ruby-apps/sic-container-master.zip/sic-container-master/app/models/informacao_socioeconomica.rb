class InformacaoSocioeconomica < ActiveRecord::Base
  belongs_to :assistido
end
