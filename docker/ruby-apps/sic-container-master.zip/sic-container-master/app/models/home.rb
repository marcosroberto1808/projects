class Home < ActiveRecord::Base
end
