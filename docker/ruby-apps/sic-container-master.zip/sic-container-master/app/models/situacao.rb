class Situacao < ActiveRecord::Base
  belongs_to :assistido
  belongs_to :inquerito_policial
end
