class HomeController < ApplicationController
    #CONFIGURAÇÕES DO CANCAN
    skip_authorization_check    #Ignorando Autorizações do cancan
end
