class AssistidoSicsController < ApplicationController
  before_action :set_assistido_sic, only: [:show, :edit, :update, :destroy]

  respond_to :html

  def index
    @assistido_sics = AssistidoSic.all
    respond_with(@assistido_sics)
  end

  def show
    respond_with(@assistido_sic)
  end

  def new
    @assistido = Assistido.new
    @cidades = Cidade.where(uf: "CE")
    @uf = Cidade.find_by_nome("Fortaleza").id if Cidade.find_by_nome("Fortaleza").present?
  end

  def edit
  end

  def create
    @assistido = AssistidoSic.new(assistido_sic_params)
    @assistido.save

    ActiveRecord::Base.transaction do
    if @assistido.save

        @situacao = Situacao.new
        @situacao["situacao_estado"] = "Não Informado"
        @situacao["assistido_id"] = @assistido.id
        @situacao.save
        @informacoes_socioeconomicas = AssistidoSic.generate_inforacoes_socioeconomicas(@assistido.id, params)

        if @informacoes_socioeconomicas.save
          redirect_to assistido_url(@assistido), notice: 'O Perfil foi cadastrado com sucesso.'
        else
          redirect_to new_assistido_sic_path
          format.json { render json: @assistido.errors, status: :unprocessable_entity }
        end
      end
    end
  end

  def update
    @assistido_sic.update(assistido_sic_params)
    respond_with(@assistido_sic)
  end

  def destroy
    @assistido_sic.destroy
    respond_with(@assistido_sic)
  end

  private
  def set_assistido_sic
    @assistido_sic = AssistidoSic.find(params[:id])
  end

  def assistido_sic_params
    params[:assistido_sic] = params[:assistido]
    params.require(:assistido_sic).permit(:nome, :cpf, :estado_civil, :cep, :logradouro, :numero, :complemento, :bairro, :cidade, :uf, :profissao, :nome_social, :rg, :orgao_emissor, :data_nascimento, :nome_pai, :nome_mae, :nacionalidade, :telefone, :telefone, :telefone_tres, :observacao, :contato_nome, :contato_telefone, :contato_tipo_vinculo, :contato_email, :resumo, :sexo, :imagem_url, :historico_delito_atual, :antecedentes_criminais, :pretensoes_futuras, :observacoes_complementares, :id_importacao_sejus, :ativo)
  end
end
