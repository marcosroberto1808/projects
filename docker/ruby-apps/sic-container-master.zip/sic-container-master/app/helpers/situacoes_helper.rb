module SituacoesHelper
end
