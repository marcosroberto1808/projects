module VarasHelper
end
