#!/bin/bash
# Iniciar o passenger
/bin/bash -l -c "bundle exec passenger start -p 3000 -e $RAILS_ENV --pid-file /tmp/passenger.3000.pid"
