# Remove all containers and all images from local repositories (OPTIONAL)
docker rm @(docker ps -aq) ; docker rmi @(docker images -aq) --force  # WINDOWS POWERSHELL
docker rm $(docker ps -aq) ; docker rmi $(docker images -aq) --force  # LINUX TERMINAL

# Starting all services in daemon mode:
docker-compose up -d

# Copy database dumps to folder "database_dumps" in uper_level of the project.
# Restore database dumps after 1st docker-compose start with the commands below:
docker-compose exec sic-database pg_restore -U postgres -d sic /database_dumps/sic_full.backup
docker-compose exec sic-database pg_restore -U postgres -d db_portal_digital /database_dumps/db_portal_digital_SIC_SCHEMAS.backup