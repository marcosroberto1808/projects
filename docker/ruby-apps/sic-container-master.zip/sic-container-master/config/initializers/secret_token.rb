# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Sic::Application.config.secret_key_base = '20d86281a32ce3c30935c562ffc22ec4be13dcc26ba85ef38c57604ace36e94e77291ebcf067bc02289f229d35bb43c114552b82a0fc48ec3e5f8dc9c0cf0d28'
