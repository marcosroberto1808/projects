class CreateAssinaturaVirtuais < ActiveRecord::Migration
  def change
    create_table :assinatura_virtuais do |t|
      t.string :assistido
      t.string :url

      t.timestamps
    end
  end
end
