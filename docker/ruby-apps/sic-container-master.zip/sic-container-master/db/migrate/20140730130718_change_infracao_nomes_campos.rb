class ChangeInfracaoNomesCampos < ActiveRecord::Migration
  def change
		rename_column :inquerito_policiais, :logradouro, :infracao_logradouro  	
		rename_column :inquerito_policiais, :complemento, :infracao_complemento  	
		rename_column :inquerito_policiais, :bairro, :infracao_bairro  	
  end
end
