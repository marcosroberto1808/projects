class RemoveCamposDocumento < ActiveRecord::Migration
  def change
		remove_column :documentos, :resposta_necessidade
		remove_column :documentos, :resposta
		remove_column :documentos, :data_resposta
		remove_column :documentos, :data_verificar_resposta
		remove_column :documentos, :resultado
		remove_column :documentos, :numero_processual
  end
end
