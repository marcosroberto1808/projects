class AdChangeCamposNotificacao < ActiveRecord::Migration
  def change
		rename_column :notificacoes, :motivo, :descricao
		rename_column :notificacoes, :data_prisao, :data
  end
end
