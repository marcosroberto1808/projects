class KeyTipoDocuClassiDocu < ActiveRecord::Migration
  def change
    add_foreign_key "classificacao_documentos", "tipo_documentos", name: "tipos_classificao_id_fk"  	
  end
end