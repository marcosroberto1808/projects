class AddNumeroInquerito < ActiveRecord::Migration
  def change
  	add_column :situacoes, :inquerito_policial_id, :integer
  end
end
