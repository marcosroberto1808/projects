class AddCamposEvento < ActiveRecord::Migration
  def change
  	add_column :eventos, :situacao, :string
  	add_column :eventos, :cidade, :string
  	add_column :eventos, :uf, :string
  	add_column :eventos, :instituicao, :string
  end
end
