class AddCampoEvento < ActiveRecord::Migration
  def change
  	add_column :notificacoes, :evento_id, :integer	
  end
end
