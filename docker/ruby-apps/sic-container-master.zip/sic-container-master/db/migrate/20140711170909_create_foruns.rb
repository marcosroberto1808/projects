class CreateForuns < ActiveRecord::Migration
  def change
    create_table :foruns do |t|
      t.string :nome

      t.timestamps
    end
  end
end
