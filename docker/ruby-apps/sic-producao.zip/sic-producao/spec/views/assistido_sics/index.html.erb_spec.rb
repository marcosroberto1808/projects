require 'rails_helper'

RSpec.describe "assistido_sics/index", type: :view do
  before(:each) do
    assign(:assistido_sics, [
      AssistidoSic.create!(
        :nome => "Nome",
        :cpf => "Cpf",
        :estado_civil => "Estado Civil",
        :cep => "Cep",
        :logradouro => "Logradouro",
        :numero => "Numero",
        :complemento => "Complemento",
        :bairro => "Bairro",
        :cidade => "Cidade",
        :uf => "Uf",
        :profissao => "Profissao",
        :nome_social => "Nome Social",
        :rg => "Rg",
        :orgao_emissor => "Orgao Emissor",
        :nome_pai => "Nome Pai",
        :nome_mae => "Nome Mae",
        :nacionalidade => "Nacionalidade",
        :telefone => "Telefone",
        :telefone => "",
        :telefone_tres => "Telefone Tres",
        :observacao => "MyText",
        :contato_nome => "Contato Nome",
        :contato_telefone => "Contato Telefone",
        :contato_tipo_vinculo => "Contato Tipo Vinculo",
        :contato_email => "Contato Email",
        :resumo => "MyText",
        :sexo => "Sexo",
        :imagem_url => "Imagem Url",
        :historico_delito_atual => "MyText",
        :antecedentes_criminais => "MyText",
        :pretensoes_futuras => "MyText",
        :observacoes_complementares => "MyText",
        :id_importacao_sejus => 1,
        :ativo => false
      ),
      AssistidoSic.create!(
        :nome => "Nome",
        :cpf => "Cpf",
        :estado_civil => "Estado Civil",
        :cep => "Cep",
        :logradouro => "Logradouro",
        :numero => "Numero",
        :complemento => "Complemento",
        :bairro => "Bairro",
        :cidade => "Cidade",
        :uf => "Uf",
        :profissao => "Profissao",
        :nome_social => "Nome Social",
        :rg => "Rg",
        :orgao_emissor => "Orgao Emissor",
        :nome_pai => "Nome Pai",
        :nome_mae => "Nome Mae",
        :nacionalidade => "Nacionalidade",
        :telefone => "Telefone",
        :telefone => "",
        :telefone_tres => "Telefone Tres",
        :observacao => "MyText",
        :contato_nome => "Contato Nome",
        :contato_telefone => "Contato Telefone",
        :contato_tipo_vinculo => "Contato Tipo Vinculo",
        :contato_email => "Contato Email",
        :resumo => "MyText",
        :sexo => "Sexo",
        :imagem_url => "Imagem Url",
        :historico_delito_atual => "MyText",
        :antecedentes_criminais => "MyText",
        :pretensoes_futuras => "MyText",
        :observacoes_complementares => "MyText",
        :id_importacao_sejus => 1,
        :ativo => false
      )
    ])
  end

  it "renders a list of assistido_sics" do
    render
    assert_select "tr>td", :text => "Nome".to_s, :count => 2
    assert_select "tr>td", :text => "Cpf".to_s, :count => 2
    assert_select "tr>td", :text => "Estado Civil".to_s, :count => 2
    assert_select "tr>td", :text => "Cep".to_s, :count => 2
    assert_select "tr>td", :text => "Logradouro".to_s, :count => 2
    assert_select "tr>td", :text => "Numero".to_s, :count => 2
    assert_select "tr>td", :text => "Complemento".to_s, :count => 2
    assert_select "tr>td", :text => "Bairro".to_s, :count => 2
    assert_select "tr>td", :text => "Cidade".to_s, :count => 2
    assert_select "tr>td", :text => "Uf".to_s, :count => 2
    assert_select "tr>td", :text => "Profissao".to_s, :count => 2
    assert_select "tr>td", :text => "Nome Social".to_s, :count => 2
    assert_select "tr>td", :text => "Rg".to_s, :count => 2
    assert_select "tr>td", :text => "Orgao Emissor".to_s, :count => 2
    assert_select "tr>td", :text => "Nome Pai".to_s, :count => 2
    assert_select "tr>td", :text => "Nome Mae".to_s, :count => 2
    assert_select "tr>td", :text => "Nacionalidade".to_s, :count => 2
    assert_select "tr>td", :text => "Telefone".to_s, :count => 2
    assert_select "tr>td", :text => "".to_s, :count => 2
    assert_select "tr>td", :text => "Telefone Tres".to_s, :count => 2
    assert_select "tr>td", :text => "MyText".to_s, :count => 2
    assert_select "tr>td", :text => "Contato Nome".to_s, :count => 2
    assert_select "tr>td", :text => "Contato Telefone".to_s, :count => 2
    assert_select "tr>td", :text => "Contato Tipo Vinculo".to_s, :count => 2
    assert_select "tr>td", :text => "Contato Email".to_s, :count => 2
    assert_select "tr>td", :text => "MyText".to_s, :count => 2
    assert_select "tr>td", :text => "Sexo".to_s, :count => 2
    assert_select "tr>td", :text => "Imagem Url".to_s, :count => 2
    assert_select "tr>td", :text => "MyText".to_s, :count => 2
    assert_select "tr>td", :text => "MyText".to_s, :count => 2
    assert_select "tr>td", :text => "MyText".to_s, :count => 2
    assert_select "tr>td", :text => "MyText".to_s, :count => 2
    assert_select "tr>td", :text => 1.to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
  end
end
