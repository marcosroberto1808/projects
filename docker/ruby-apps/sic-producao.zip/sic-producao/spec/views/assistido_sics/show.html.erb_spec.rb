require 'rails_helper'

RSpec.describe "assistido_sics/show", type: :view do
  before(:each) do
    @assistido_sic = assign(:assistido_sic, AssistidoSic.create!(
      :nome => "Nome",
      :cpf => "Cpf",
      :estado_civil => "Estado Civil",
      :cep => "Cep",
      :logradouro => "Logradouro",
      :numero => "Numero",
      :complemento => "Complemento",
      :bairro => "Bairro",
      :cidade => "Cidade",
      :uf => "Uf",
      :profissao => "Profissao",
      :nome_social => "Nome Social",
      :rg => "Rg",
      :orgao_emissor => "Orgao Emissor",
      :nome_pai => "Nome Pai",
      :nome_mae => "Nome Mae",
      :nacionalidade => "Nacionalidade",
      :telefone => "Telefone",
      :telefone => "",
      :telefone_tres => "Telefone Tres",
      :observacao => "MyText",
      :contato_nome => "Contato Nome",
      :contato_telefone => "Contato Telefone",
      :contato_tipo_vinculo => "Contato Tipo Vinculo",
      :contato_email => "Contato Email",
      :resumo => "MyText",
      :sexo => "Sexo",
      :imagem_url => "Imagem Url",
      :historico_delito_atual => "MyText",
      :antecedentes_criminais => "MyText",
      :pretensoes_futuras => "MyText",
      :observacoes_complementares => "MyText",
      :id_importacao_sejus => 1,
      :ativo => false
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Nome/)
    expect(rendered).to match(/Cpf/)
    expect(rendered).to match(/Estado Civil/)
    expect(rendered).to match(/Cep/)
    expect(rendered).to match(/Logradouro/)
    expect(rendered).to match(/Numero/)
    expect(rendered).to match(/Complemento/)
    expect(rendered).to match(/Bairro/)
    expect(rendered).to match(/Cidade/)
    expect(rendered).to match(/Uf/)
    expect(rendered).to match(/Profissao/)
    expect(rendered).to match(/Nome Social/)
    expect(rendered).to match(/Rg/)
    expect(rendered).to match(/Orgao Emissor/)
    expect(rendered).to match(/Nome Pai/)
    expect(rendered).to match(/Nome Mae/)
    expect(rendered).to match(/Nacionalidade/)
    expect(rendered).to match(/Telefone/)
    expect(rendered).to match(//)
    expect(rendered).to match(/Telefone Tres/)
    expect(rendered).to match(/MyText/)
    expect(rendered).to match(/Contato Nome/)
    expect(rendered).to match(/Contato Telefone/)
    expect(rendered).to match(/Contato Tipo Vinculo/)
    expect(rendered).to match(/Contato Email/)
    expect(rendered).to match(/MyText/)
    expect(rendered).to match(/Sexo/)
    expect(rendered).to match(/Imagem Url/)
    expect(rendered).to match(/MyText/)
    expect(rendered).to match(/MyText/)
    expect(rendered).to match(/MyText/)
    expect(rendered).to match(/MyText/)
    expect(rendered).to match(/1/)
    expect(rendered).to match(/false/)
  end
end
