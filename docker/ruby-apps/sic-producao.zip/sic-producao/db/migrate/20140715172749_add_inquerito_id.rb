class AddInqueritoId < ActiveRecord::Migration
  def change
		add_column :processo_judiciais, :inquerito_policial_id, :integer
  end
end
