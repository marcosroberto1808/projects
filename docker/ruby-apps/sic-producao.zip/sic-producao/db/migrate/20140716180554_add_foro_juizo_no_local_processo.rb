class AddForoJuizoNoLocalProcesso < ActiveRecord::Migration
  def change
		add_column :local_atuacao_processos, :foro, :string
		add_column :local_atuacao_processos, :juizo, :string  	
  end
end
