class RemoveForumIdProcesso < ActiveRecord::Migration
  def change
		remove_column :processo_judiciais, :forum_id
		remove_column :processo_judiciais, :juizo		
  end
end
