class AddInfracaoNumeroInqueritoPolicial < ActiveRecord::Migration
  def change
		add_column :inquerito_policiais, :infracao_numero, :string  	  	
  end
end
