class AddEstadoProcessoJudicial < ActiveRecord::Migration
  def change
		add_column :processo_judiciais, :estado, :string
  end
end
