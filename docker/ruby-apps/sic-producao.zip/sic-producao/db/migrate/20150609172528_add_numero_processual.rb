class AddNumeroProcessual < ActiveRecord::Migration
  def change
  	add_column :documentos, :numero_processual, :string  	
  end
end
