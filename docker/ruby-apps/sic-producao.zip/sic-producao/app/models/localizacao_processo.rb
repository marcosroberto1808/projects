class LocalizacaoProcesso < ActiveRecord::Base
  belongs_to :processo_judicial
end
