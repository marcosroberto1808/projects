module InqueritoPoliciaisHelper
end
