# Be sure to restart your server when you modify this file.

Sic::Application.config.session_store :cookie_store, key: '_sic_session'
