#!/bin/bash
# Iniciar o primeiro migrate
/bin/bash -l -c "python migrate_all_apps.py"