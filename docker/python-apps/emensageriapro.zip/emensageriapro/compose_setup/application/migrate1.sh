#!/bin/bash
# Iniciar o primeiro migrate
/bin/bash -l -c "source /home/AppEnv/bin/activate ; cd /home/AppCode/emensageriapro ; python migrate_all_apps.py"