#!/bin/bash
# Iniciar o uwsgi
/bin/bash -l -c "source /home/AppEnv/bin/activate ; uwsgi --ini /home/AppConfig/uwsgi.ini"