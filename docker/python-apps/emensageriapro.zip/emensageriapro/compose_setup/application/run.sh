#!/bin/bash
# Iniciar o uwsgi
/bin/bash -l -c "uwsgi --ini /home/AppConfig/uwsgi.ini"